:HL["/_next/static/css/d61a10ebe8f22b3d.css","style"]
:HL["/_next/static/css/e83a17a6a1401baf.css","style"]
:HL["/_next/static/css/c1ff9006d0297a69.css","style"]
0:{"tree":{"name":"","param":null,"prefetchHints":4176,"slots":{"children":{"name":"baixar-app","param":null,"prefetchHints":4192,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":4256,"slots":null}}}}},"staleTime":300,"buildId":"0GzpHuCUyeouyYrtsemH0"}
