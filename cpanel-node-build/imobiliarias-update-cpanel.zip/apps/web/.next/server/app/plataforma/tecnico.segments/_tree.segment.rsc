:HL["/_next/static/css/0a53a4db7160589f.css","style"]
:HL["/_next/static/css/09450e63557adb07.css","style"]
:HL["/_next/static/css/99a5aa8332ae5a4c.css","style"]
:HL["/_next/static/css/6c17a62a483beecd.css","style"]
:HL["https://lenoy.com.br/wp-content/uploads/2026/08/hh.png","image"]
0:{"tree":{"name":"","param":null,"prefetchHints":4112,"slots":{"children":{"name":"plataforma","param":null,"prefetchHints":4160,"slots":{"children":{"name":"tecnico","param":null,"prefetchHints":4192,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":4256,"slots":null}}}}}}},"staleTime":300,"buildId":"0VUIdAZel8KdDmJxTp1BZ"}
