(()=>{var a={};a.id=370,a.ids=[370],a.modules={3295:a=>{"use strict";a.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},8128:a=>{"use strict";a.exports=require("next/dist/server/runtime-reacts.external.js")},10846:a=>{"use strict";a.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},17640:(a,b,c)=>{"use strict";c.d(b,{default:()=>n});var d=c(14007),e=c(64898),f=c(22744);function g(a){return null!=a&&Number.isFinite(Number(a))?new Intl.NumberFormat("pt-BR",{style:"currency",currency:"BRL"}).format(Number(a)):"—"}function h(a){if(!a)return"—";let b=new Date(a);return Number.isNaN(b.getTime())?"—":b.toLocaleDateString("pt-BR")}function i(a){if(!a)return"";let b=new Date(a);return Number.isNaN(b.getTime())?"":`${b.getFullYear()}-${String(b.getMonth()+1).padStart(2,"0")}-${String(b.getDate()).padStart(2,"0")}`}function j(a){return a?new Date(`${a}T12:00:00`).toISOString():null}function k(a,b,c){return Math.min(c,Math.max(b,a))}function l(a){return a?"paid"===a?"Pagamento confirmado":"created"===a||"pending"===a?"Aguardando pagamento":"failed"===a?"N\xe3o conclu\xeddo":"expired"===a?"Expirado":"cancelled"===a?"Cancelado":a:"Sem cobran\xe7a"}function m({agency:a,profile:b,subscription:c,plans:n,latestCheckout:o,discount:p,onSaved:q}){var r,s;let t=n.find(a=>a.id===c?.plan_id)||null,u=n.filter(a=>"homologacao"!==a.code&&a.active),[v,w]=(0,e.useState)(a.name),[x,y]=(0,e.useState)(i(a.created_at)),[z,A]=(0,e.useState)(a.status||"pending_payment"),[B,C]=(0,e.useState)(c?.plan_id||u[0]?.id||""),[D,E]=(0,e.useState)(c?.status||"none"),[F,G]=(0,e.useState)(c?.billing_cycle||b?.billing_cycle||"monthly"),[H,I]=(0,e.useState)(b?.implementation_status||"pending"),[J,K]=(0,e.useState)(i(c?.renews_at)),[L,M]=(0,e.useState)(i(c?.ends_at)),[N,O]=(0,e.useState)(""),[P,Q]=(0,e.useState)("0.00"),[R,S]=(0,e.useState)(!1),[T,U]=(0,e.useState)(""),V=n.find(a=>a.id===B)||null,W=V?Number("annual"===F?V.annual_price||0:V.monthly_price||0):0;async function X(){if(!f.L)return;if(!v.trim())return U("Informe o nome do cliente.");if("none"!==D&&!B)return U("Selecione um plano.");S(!0),U("");let b=await f.L.rpc("platform_update_agency_commercial",{p_agency_id:a.id,p_name:v.trim(),p_created_at:j(x),p_agency_status:z,p_plan_id:B||null,p_subscription_status:D,p_billing_cycle:F,p_implementation_status:H,p_renews_at:j(J),p_ends_at:j(L)});if(b.error)return S(!1),U(b.error.message);if(B&&W>0&&"none"!==D){let b=Number(N.replace(",","."));if(!Number.isFinite(b)||b<=0||b>W)return S(!1),U("Dados principais salvos. Corrija o valor da pr\xf3xima cobran\xe7a.");let c=b<W?await f.L.rpc("platform_set_agency_billing_discount",{p_agency_id:a.id,p_plan_id:B,p_billing_cycle:F,p_final_amount:b}):await f.L.rpc("platform_clear_agency_billing_discount",{p_agency_id:a.id,p_plan_id:B,p_billing_cycle:F});if(c.error)return S(!1),U(`Dados do cliente salvos, mas o desconto n\xe3o foi alterado: ${c.error.message}`)}S(!1),U("Cliente atualizado."),await q()}return p&&p.plan_id===B&&p.billing_cycle,(0,d.jsxs)("div",{className:"commercialClientEditor",children:[(0,d.jsxs)("div",{className:"commercialEditorGrid two",children:[(0,d.jsxs)("label",{children:["Nome do cliente",(0,d.jsx)("input",{value:v,onChange:a=>w(a.target.value)})]}),(0,d.jsxs)("label",{children:["Data do cadastro",(0,d.jsx)("input",{type:"date",value:x,onChange:a=>y(a.target.value)})]})]}),(0,d.jsxs)("div",{className:"commercialEditorGrid three",children:[(0,d.jsxs)("label",{children:["Plano",(0,d.jsxs)("select",{value:B,onChange:a=>C(a.target.value),children:[B?null:(0,d.jsx)("option",{value:"",children:"Selecione"}),t?.code==="homologacao"?(0,d.jsx)("option",{value:t.id,children:"Conta interna atual"}):null,u.map(a=>(0,d.jsx)("option",{value:a.id,children:a.name},a.id))]})]}),(0,d.jsxs)("label",{children:["Cobran\xe7a",(0,d.jsxs)("select",{value:F,onChange:a=>G(a.target.value),children:[(0,d.jsx)("option",{value:"monthly",children:"Mensal"}),(0,d.jsx)("option",{value:"annual",children:"Anual"})]})]}),(0,d.jsxs)("label",{children:["Implanta\xe7\xe3o",(0,d.jsxs)("select",{value:H,onChange:a=>I(a.target.value),children:[(0,d.jsx)("option",{value:"pending",children:"Pendente"}),(0,d.jsx)("option",{value:"paid",children:"Paga"}),(0,d.jsx)("option",{value:"waived",children:"Gr\xe1tis / dispensada"})]})]})]}),(0,d.jsxs)("div",{className:"commercialEditorGrid three",children:[(0,d.jsxs)("label",{children:["Assinatura",(0,d.jsxs)("select",{value:D,onChange:a=>E(a.target.value),children:[(0,d.jsx)("option",{value:"none",children:"Sem assinatura"}),(0,d.jsx)("option",{value:"active",children:"Ativa"}),(0,d.jsx)("option",{value:"past_due",children:"Pagamento atrasado"}),(0,d.jsx)("option",{value:"cancelled",children:"Cancelada"}),(0,d.jsx)("option",{value:"expired",children:"Encerrada"}),(0,d.jsx)("option",{value:"trial",children:"Conta interna / teste"})]})]}),(0,d.jsxs)("label",{children:["Acesso",(0,d.jsxs)("select",{value:z,onChange:a=>A(a.target.value),children:[(0,d.jsx)("option",{value:"pending_payment",children:"Aguardando pagamento"}),(0,d.jsx)("option",{value:"active",children:"Liberado"}),(0,d.jsx)("option",{value:"past_due",children:"Pagamento atrasado"}),(0,d.jsx)("option",{value:"suspended",children:"Suspenso"}),(0,d.jsx)("option",{value:"cancelled",children:"Cancelado"}),(0,d.jsx)("option",{value:"trial",children:"Conta interna / teste"})]})]}),(0,d.jsxs)("label",{children:["Pre\xe7o normal",(0,d.jsx)("input",{value:g(W),readOnly:!0})]})]}),(0,d.jsxs)("div",{className:"commercialEditorGrid two",children:[(0,d.jsxs)("label",{children:["Pr\xf3ximo vencimento",(0,d.jsx)("input",{type:"date",value:J,onChange:a=>K(a.target.value)})]}),(0,d.jsxs)("label",{children:["Fim do acesso / assinatura",(0,d.jsx)("input",{type:"date",value:L,onChange:a=>M(a.target.value)})]})]}),(0,d.jsxs)("div",{className:"commercialDiscountInline",children:[(0,d.jsxs)("div",{children:[(0,d.jsx)("strong",{children:"Valor da pr\xf3xima cobran\xe7a"}),(0,d.jsx)("small",{children:"Altere o valor ou a porcentagem; um campo recalcula o outro."})]}),(0,d.jsxs)("label",{children:["Valor (R$)",(0,d.jsx)("input",{type:"number",min:"0.01",step:"0.01",value:N,onChange:a=>(function(a){O(a);let b=Number(a.replace(",","."));if(!W||!Number.isFinite(b))return Q("0.00");Q(k((W-b)/W*100,0,99.99).toFixed(2))})(a.target.value)})]}),(0,d.jsxs)("label",{children:["Desconto (%)",(0,d.jsx)("input",{type:"number",min:"0",max:"99.99",step:"0.01",value:P,onChange:a=>{var b;let c;return Q(b=a.target.value),c=Number(b.replace(",",".")),void(!W||!Number.isFinite(c)||O((W*(1-k(c,0,99.99)/100)).toFixed(2)))}})]})]}),(0,d.jsxs)("div",{className:"commercialBillingSnapshot",children:[(0,d.jsx)("strong",{children:"Dados da cobran\xe7a mais recente"}),o?(0,d.jsxs)("div",{className:"commercialBillingSnapshotGrid",children:[(0,d.jsxs)("span",{children:[(0,d.jsx)("small",{children:"Tipo"}),(0,d.jsx)("b",{children:(r=o.charge_type,s=o.billing_cycle,"implementation"===r?"Implanta\xe7\xe3o":"annual"===s?"Plano anual":"Mensalidade")})]}),(0,d.jsxs)("span",{children:[(0,d.jsx)("small",{children:"Status"}),(0,d.jsx)("b",{children:l(o.status)})]}),(0,d.jsxs)("span",{children:[(0,d.jsx)("small",{children:"Valor normal"}),(0,d.jsx)("b",{children:g(o.base_amount??o.amount)})]}),(0,d.jsxs)("span",{children:[(0,d.jsx)("small",{children:"Valor cobrado"}),(0,d.jsx)("b",{children:g(o.paid_amount??o.amount)})]}),(0,d.jsxs)("span",{children:[(0,d.jsx)("small",{children:"Data"}),(0,d.jsx)("b",{children:h(o.completed_at||o.created_at)})]})]}):(0,d.jsx)("small",{children:"Nenhuma cobran\xe7a registrada para este cliente."})]}),(0,d.jsx)("div",{className:"commercialEditorActions",children:(0,d.jsx)("button",{className:"button primary",type:"button",disabled:R,onClick:()=>void X(),children:R?"Salvando...":"Salvar altera\xe7\xf5es"})}),T?(0,d.jsx)("div",{className:"formMessage",children:T}):null]})}function n(){let[a,b]=(0,e.useState)([]),[c,i]=(0,e.useState)([]),[j,k]=(0,e.useState)([]),[n,o]=(0,e.useState)([]),[p,q]=(0,e.useState)([]),[r,s]=(0,e.useState)([]),[t,u]=(0,e.useState)(""),[v,w]=(0,e.useState)(null);async function x(){if(!f.L||!f.$)return;let[a,c,d,e,g,h]=await Promise.all([f.L.from("agencies").select("id,name,slug,email,status,created_at").order("created_at",{ascending:!1}),f.L.from("agency_billing_profiles").select("agency_id,implementation_status,billing_cycle"),f.L.from("agency_subscriptions").select("id,agency_id,plan_id,status,starts_at,renews_at,ends_at,billing_cycle").order("starts_at",{ascending:!1}),f.L.from("subscription_plans").select("id,name,code,monthly_price,annual_price,implementation_fee,active").order("display_order"),f.L.from("billing_checkout_sessions").select("id,agency_id,plan_id,status,amount,paid_amount,base_amount,discount_percent,billing_cycle,charge_type,created_at,completed_at").order("created_at",{ascending:!1}).limit(300),f.L.from("agency_billing_discounts").select("id,agency_id,plan_id,billing_cycle,base_amount,final_amount,discount_percent,status").eq("status","active")]),j=a.error||c.error||d.error||e.error||g.error||h.error;if(j)return u(j.message);b(a.data||[]),i(c.data||[]),k(d.data||[]),o(e.data||[]),q(g.data||[]),s(h.data||[])}let y=(0,e.useMemo)(()=>new Map(n.map(a=>[a.id,a])),[n]),z=(0,e.useMemo)(()=>new Map(c.map(a=>[a.agency_id,a])),[c]),A=(0,e.useMemo)(()=>{let a=new Map;return j.forEach(b=>{a.has(b.agency_id)||a.set(b.agency_id,b)}),a},[j]),B=(0,e.useMemo)(()=>{let a=new Map;return p.forEach(b=>{a.has(b.agency_id)||a.set(b.agency_id,b)}),a},[p]),C=a.filter(a=>"active"===a.status).length,D=a.filter(a=>"pending_payment"===a.status).length,E=a.filter(a=>["past_due","suspended"].includes(a.status)).length,F=a.filter(a=>{let b=A.get(a.id);return b?.status==="active"&&"monthly"===(b.billing_cycle||z.get(a.id)?.billing_cycle)}).length,G=a.filter(a=>{let b=A.get(a.id);return b?.status==="active"&&"annual"===(b.billing_cycle||z.get(a.id)?.billing_cycle)}).length,H=new Date,I=new Date(H.getFullYear(),H.getMonth(),1).getTime(),J=new Date(H.getFullYear(),H.getMonth()+1,1).getTime(),K=p.filter(a=>"paid"===a.status&&new Date(a.completed_at||a.created_at).getTime()>=I&&new Date(a.completed_at||a.created_at).getTime()<J),L=K.reduce((a,b)=>a+Number(b.paid_amount??b.amount??0),0),M=p.filter(a=>["created","pending"].includes(a.status)).length;return(0,d.jsxs)(d.Fragment,{children:[(0,d.jsxs)("section",{className:"commercialSummary",id:"resumo-comercial",children:[(0,d.jsxs)("article",{children:[(0,d.jsx)("span",{children:"Clientes"}),(0,d.jsx)("strong",{children:a.length}),(0,d.jsx)("small",{children:"cadastrados"})]}),(0,d.jsxs)("article",{children:[(0,d.jsx)("span",{children:"Ativos"}),(0,d.jsx)("strong",{children:C}),(0,d.jsx)("small",{children:"acesso liberado"})]}),(0,d.jsxs)("article",{className:D?"attention":"",children:[(0,d.jsx)("span",{children:"Aguardando"}),(0,d.jsx)("strong",{children:D}),(0,d.jsx)("small",{children:"pagamento"})]}),(0,d.jsxs)("article",{children:[(0,d.jsx)("span",{children:"Mensalistas"}),(0,d.jsx)("strong",{children:F}),(0,d.jsx)("small",{children:"assinaturas ativas"})]}),(0,d.jsxs)("article",{children:[(0,d.jsx)("span",{children:"Anuais"}),(0,d.jsx)("strong",{children:G}),(0,d.jsx)("small",{children:"assinaturas ativas"})]}),(0,d.jsxs)("article",{className:E?"danger":"",children:[(0,d.jsx)("span",{children:"Inadimplentes"}),(0,d.jsx)("strong",{children:E}),(0,d.jsx)("small",{children:"ou suspensos"})]}),(0,d.jsxs)("article",{children:[(0,d.jsx)("span",{children:"Recebido no m\xeas"}),(0,d.jsx)("strong",{children:g(L)}),(0,d.jsxs)("small",{children:[K.length," pagamento(s)"]})]}),(0,d.jsxs)("article",{className:M?"attention":"",children:[(0,d.jsx)("span",{children:"Pendentes"}),(0,d.jsx)("strong",{children:M}),(0,d.jsx)("small",{children:"cobran\xe7as abertas"})]})]}),t?(0,d.jsxs)("div",{className:"formMessage",children:["N\xe3o foi poss\xedvel carregar todos os dados comerciais: ",t]}):null,(0,d.jsxs)("section",{className:"adminPanel commercialClientsPanel",id:"clientes-comerciais",children:[(0,d.jsxs)("div",{className:"adminPanelHeader",children:[(0,d.jsxs)("div",{children:[(0,d.jsx)("span",{className:"eyebrow",children:"CLIENTES"}),(0,d.jsx)("h2",{children:"Cadastros, compras e acesso"}),(0,d.jsx)("p",{children:"Abra um cliente para alterar plano, cobran\xe7a, implanta\xe7\xe3o, vencimento, acesso e desconto."})]}),(0,d.jsxs)("span",{className:"statusPill",children:[a.length," cliente(s)"]})]}),(0,d.jsxs)("div",{className:"commercialClientGrid",children:[a.map(a=>{var b,c,e;let f=z.get(a.id),i=A.get(a.id),j=i?y.get(i.plan_id):null,k=i?.billing_cycle||f?.billing_cycle,o=B.get(a.id),p=r.find(b=>b.agency_id===a.id&&b.plan_id===i?.plan_id&&b.billing_cycle===k),q=j?.code==="homologacao"?"Conta interna":j?.name||"Ainda n\xe3o escolhido";return(0,d.jsxs)("article",{className:`commercialClientCard ${v===a.id?"isEditing":""}`,children:[(0,d.jsxs)("header",{className:"commercialClientHeader",children:[(0,d.jsxs)("div",{children:[(0,d.jsx)("strong",{children:a.name}),(0,d.jsx)("span",{children:a.email||"Sem e-mail"}),(0,d.jsxs)("small",{children:[a.slug,".imoveis.lenoy.com.br"]})]}),(0,d.jsx)("span",{className:`commercialStatus agency-${a.status}`,children:"active"===(b=a.status)?"Ativo":"pending_payment"===b?"Aguardando pagamento":"trial"===b?"Conta interna":"past_due"===b?"Pagamento atrasado":"suspended"===b?"Suspenso":"cancelled"===b?"Cancelado":b||"—"})]}),(0,d.jsxs)("div",{className:"commercialClientFacts",children:[(0,d.jsxs)("span",{children:[(0,d.jsx)("small",{children:"Cadastro"}),(0,d.jsx)("b",{children:h(a.created_at)})]}),(0,d.jsxs)("span",{children:[(0,d.jsx)("small",{children:"Plano"}),(0,d.jsx)("b",{children:q})]}),(0,d.jsxs)("span",{children:[(0,d.jsx)("small",{children:"Cobran\xe7a"}),(0,d.jsx)("b",{children:"annual"===k?"Anual":"monthly"===k?"Mensal":"—"})]}),(0,d.jsxs)("span",{children:[(0,d.jsx)("small",{children:"Implanta\xe7\xe3o"}),(0,d.jsx)("b",{children:(c=f?.implementation_status,"annual"===k&&"waived"===c?"Gr\xe1tis no anual":"paid"===c?"Paga":"waived"===c?"Gr\xe1tis":"pending"===c?"Pendente":"—")})]}),(0,d.jsxs)("span",{children:[(0,d.jsx)("small",{children:"Assinatura"}),(0,d.jsx)("b",{children:(e=i?.status)?"active"===e?"Ativa":"trial"===e?"Conta interna":"past_due"===e?"Pagamento atrasado":"cancelled"===e?"Cancelada":"expired"===e?"Encerrada":e:"Sem assinatura"})]}),(0,d.jsxs)("span",{children:[(0,d.jsx)("small",{children:"Vencimento"}),(0,d.jsx)("b",{children:h(i?.renews_at||i?.ends_at)})]}),(0,d.jsxs)("span",{children:[(0,d.jsx)("small",{children:"\xdaltima cobran\xe7a"}),(0,d.jsx)("b",{children:o?g(o.paid_amount??o.amount):"—"})]}),(0,d.jsxs)("span",{children:[(0,d.jsx)("small",{children:"Situa\xe7\xe3o financeira"}),(0,d.jsx)("b",{children:l(o?.status)})]})]}),(0,d.jsx)("button",{className:"commercialEditClientButton",type:"button",onClick:()=>w(b=>b===a.id?null:a.id),children:v===a.id?"Fechar edi\xe7\xe3o":"Editar cliente"}),v===a.id?(0,d.jsx)(m,{agency:a,profile:f,subscription:i,plans:n,latestCheckout:o,discount:p,onSaved:x}):null]},a.id)}),a.length?null:(0,d.jsx)("div",{className:"formNotice",children:"Nenhum cliente cadastrado."})]})]})]})}},19055:(a,b,c)=>{"use strict";c.r(b),c.d(b,{default:()=>l});var d=c(89385),e=c(50020),f=c(76696),g=c(85246),h=c(29965),i=c(98666),j=c(96300);let k=`
.platformCommercialPage{
  min-height:100vh!important;
  background:#f4f6f8!important;
  color:#15293d!important;
}
.platformCommercialPage .commercialTopbar{
  position:sticky!important;
  top:0!important;
  z-index:100!important;
  min-height:76px!important;
  background:#0b2946!important;
  border:0!important;
  border-bottom:1px solid rgba(255,255,255,.1)!important;
  box-shadow:0 8px 24px rgba(9,31,52,.12)!important;
}
.platformCommercialPage .commercialAdminNav{
  width:min(1540px,calc(100% - 40px))!important;
  max-width:1540px!important;
  min-height:76px!important;
  margin:0 auto!important;
  padding:8px 0!important;
  display:grid!important;
  grid-template-columns:auto 1fr auto!important;
  align-items:center!important;
  gap:16px!important;
}
.platformCommercialPage .commercialAdminNav .brand{
  display:flex!important;
  align-items:center!important;
  justify-content:center!important;
  width:58px!important;
  min-width:58px!important;
  height:58px!important;
}
.platformCommercialPage .commercialAdminNav .brand img{
  width:58px!important;
  max-width:58px!important;
  max-height:58px!important;
  object-fit:contain!important;
}
.platformCommercialPage .commercialHeaderTitle{
  display:flex!important;
  flex-direction:column!important;
  gap:3px!important;
  color:#fff!important;
}
.platformCommercialPage .commercialHeaderTitle strong{
  font-size:18px!important;
  line-height:1.15!important;
  letter-spacing:-.01em!important;
}
.platformCommercialPage .commercialHeaderTitle span{
  font-size:12px!important;
  color:#b9c9d7!important;
}
.platformCommercialPage .commercialMenuButton{
  min-height:44px!important;
  padding:0 16px!important;
  border-radius:12px!important;
  font-size:13px!important;
}
.platformCommercialPage .commercialMenuPanel{
  top:86px!important;
  right:20px!important;
  width:min(1000px,calc(100vw - 40px))!important;
  padding:18px!important;
  border-radius:18px!important;
  box-shadow:0 28px 70px rgba(7,23,43,.24)!important;
}
.platformCommercialPage .commercialMenuGrid{
  grid-template-columns:repeat(4,minmax(0,1fr))!important;
  gap:12px!important;
}
.platformCommercialPage .commercialMenuCard{
  min-height:122px!important;
  padding:16px!important;
  border-radius:14px!important;
}
.platformCommercialPage .commercialMenuIcon{
  width:36px!important;
  height:36px!important;
  border-radius:10px!important;
  font-size:15px!important;
}
.platformCommercialPage .commercialMenuCard strong{
  font-size:14px!important;
}
.platformCommercialPage .commercialMenuCard small{
  font-size:12px!important;
  line-height:1.35!important;
}
.platformCommercialPage .platformCommercialShell{
  box-sizing:border-box!important;
  width:min(1540px,calc(100% - 40px))!important;
  max-width:1540px!important;
  margin:0 auto!important;
  padding:30px 0 56px!important;
}
.platformCommercialPage .commercialAdminContent{
  width:100%!important;
  max-width:none!important;
  margin:0!important;
  padding:0!important;
}
.platformCommercialPage .commercialPageIntro{
  display:flex!important;
  align-items:flex-end!important;
  justify-content:space-between!important;
  gap:24px!important;
  margin:0 0 24px!important;
  padding:4px 2px!important;
}
.platformCommercialPage .commercialPageIntroCopy{
  max-width:760px!important;
}
.platformCommercialPage .commercialPageIntro .eyebrow{
  display:block!important;
  margin-bottom:7px!important;
  color:#a77b25!important;
  font-size:11px!important;
  font-weight:900!important;
  letter-spacing:.12em!important;
}
.platformCommercialPage .commercialPageIntro h1{
  margin:0!important;
  color:#10263d!important;
  font-size:32px!important;
  line-height:1.08!important;
  letter-spacing:-.035em!important;
}
.platformCommercialPage .commercialPageIntro p{
  max-width:700px!important;
  margin:9px 0 0!important;
  color:#637384!important;
  font-size:15px!important;
  line-height:1.5!important;
}
.platformCommercialPage .commercialPageIntroBadge{
  display:inline-flex!important;
  align-items:center!important;
  gap:8px!important;
  min-height:38px!important;
  padding:0 14px!important;
  border:1px solid #d9e1e7!important;
  border-radius:999px!important;
  background:#fff!important;
  color:#43596e!important;
  font-size:12px!important;
  font-weight:800!important;
  white-space:nowrap!important;
  box-shadow:0 5px 16px rgba(16,36,58,.04)!important;
}
.platformCommercialPage .commercialPageIntroBadge:before{
  content:''!important;
  width:8px!important;
  height:8px!important;
  border-radius:999px!important;
  background:#2d9b65!important;
  box-shadow:0 0 0 4px #e6f5ed!important;
}
.platformCommercialPage .commercialSummary{
  display:grid!important;
  grid-template-columns:repeat(4,minmax(0,1fr))!important;
  gap:14px!important;
  margin:0 0 24px!important;
}
.platformCommercialPage .commercialSummary article,
.platformCommercialPage .commercialPaymentMetrics article{
  position:relative!important;
  box-sizing:border-box!important;
  min-width:0!important;
  min-height:112px!important;
  padding:18px 20px!important;
  overflow:hidden!important;
  border:1px solid #e0e6eb!important;
  border-radius:17px!important;
  background:#fff!important;
  box-shadow:0 8px 24px rgba(16,36,58,.055)!important;
}
.platformCommercialPage .commercialSummary article:before{
  content:''!important;
  position:absolute!important;
  top:0!important;
  left:0!important;
  width:4px!important;
  height:100%!important;
  background:#143c61!important;
  opacity:.9!important;
}
.platformCommercialPage .commercialSummary article.attention,
.platformCommercialPage .commercialPaymentMetrics article.attention{
  border-color:#ead29d!important;
  background:#fffdf8!important;
}
.platformCommercialPage .commercialSummary article.attention:before{background:#d5a33b!important}
.platformCommercialPage .commercialSummary article.danger,
.platformCommercialPage .commercialPaymentMetrics article.danger{
  border-color:#e8b8b2!important;
  background:#fffafa!important;
}
.platformCommercialPage .commercialSummary article.danger:before{background:#c85b50!important}
.platformCommercialPage .commercialSummary span,
.platformCommercialPage .commercialPaymentMetrics span{
  display:block!important;
  color:#6f7f8d!important;
  font-size:11px!important;
  font-weight:900!important;
  letter-spacing:.07em!important;
  text-transform:uppercase!important;
}
.platformCommercialPage .commercialSummary strong,
.platformCommercialPage .commercialPaymentMetrics strong{
  display:block!important;
  margin-top:8px!important;
  color:#10263d!important;
  font-size:29px!important;
  line-height:1!important;
  letter-spacing:-.035em!important;
}
.platformCommercialPage .commercialSummary small,
.platformCommercialPage .commercialPaymentMetrics small{
  display:block!important;
  margin-top:7px!important;
  color:#83909b!important;
  font-size:12px!important;
  line-height:1.3!important;
}
.platformCommercialPage .commercialClientsPanel{
  width:100%!important;
  margin:0 0 24px!important;
  padding:26px!important;
  border:1px solid #e0e6eb!important;
  border-radius:22px!important;
  background:#fff!important;
  box-shadow:0 10px 32px rgba(16,36,58,.06)!important;
}
.platformCommercialPage .commercialClientsPanel .adminPanelHeader{
  display:flex!important;
  align-items:flex-start!important;
  justify-content:space-between!important;
  gap:20px!important;
  margin:0 0 22px!important;
  padding:0 0 20px!important;
  border-bottom:1px solid #edf1f4!important;
}
.platformCommercialPage .commercialClientsPanel .eyebrow{
  color:#a77b25!important;
  font-size:11px!important;
  font-weight:900!important;
  letter-spacing:.12em!important;
}
.platformCommercialPage .commercialClientsPanel .adminPanelHeader h2{
  margin:5px 0 0!important;
  color:#10263d!important;
  font-size:28px!important;
  line-height:1.1!important;
  letter-spacing:-.025em!important;
}
.platformCommercialPage .commercialClientsPanel .adminPanelHeader p{
  max-width:760px!important;
  margin:8px 0 0!important;
  color:#6b7a88!important;
  font-size:14px!important;
  line-height:1.5!important;
}
.platformCommercialPage .commercialClientsPanel .statusPill{
  min-height:34px!important;
  padding:7px 12px!important;
  border-radius:999px!important;
  background:#eef6f1!important;
  color:#2f6e4c!important;
  font-size:12px!important;
  font-weight:850!important;
}
.platformCommercialPage .commercialClientGrid{
  display:grid!important;
  grid-template-columns:1fr!important;
  gap:16px!important;
  width:100%!important;
}
.platformCommercialPage .commercialClientCard{
  box-sizing:border-box!important;
  width:100%!important;
  min-width:0!important;
  padding:20px!important;
  border:1px solid #dfe5ea!important;
  border-radius:18px!important;
  background:#fff!important;
  box-shadow:0 5px 18px rgba(14,34,53,.035)!important;
  transition:border-color .18s ease,box-shadow .18s ease,transform .18s ease!important;
}
.platformCommercialPage .commercialClientCard:hover{
  border-color:#cbd6df!important;
  box-shadow:0 10px 26px rgba(14,34,53,.07)!important;
}
.platformCommercialPage .commercialClientCard.isEditing{
  grid-column:auto!important;
  border-color:#d1ad61!important;
  box-shadow:0 14px 34px rgba(14,34,53,.09)!important;
}
.platformCommercialPage .commercialClientHeader{
  display:flex!important;
  align-items:flex-start!important;
  justify-content:space-between!important;
  gap:18px!important;
  padding:0 0 16px!important;
  border-bottom:1px solid #edf1f4!important;
}
.platformCommercialPage .commercialClientHeader>div{
  display:grid!important;
  gap:4px!important;
  min-width:0!important;
}
.platformCommercialPage .commercialClientHeader strong{
  color:#10263d!important;
  font-size:19px!important;
  line-height:1.2!important;
  letter-spacing:-.015em!important;
}
.platformCommercialPage .commercialClientHeader span:not(.commercialStatus){
  color:#5f7181!important;
  font-size:13px!important;
}
.platformCommercialPage .commercialClientHeader small{
  color:#909aa3!important;
  font-size:11px!important;
}
.platformCommercialPage .commercialStatus{
  min-height:30px!important;
  padding:5px 10px!important;
  border-radius:999px!important;
  font-size:11px!important;
  font-weight:850!important;
}
.platformCommercialPage .commercialClientFacts{
  display:grid!important;
  grid-template-columns:repeat(4,minmax(0,1fr))!important;
  gap:10px!important;
  margin:16px 0!important;
}
.platformCommercialPage .commercialClientFacts>span{
  min-width:0!important;
  min-height:68px!important;
  padding:12px 13px!important;
  border:1px solid #edf1f4!important;
  border-radius:12px!important;
  background:#f8fafb!important;
}
.platformCommercialPage .commercialClientFacts small{
  display:block!important;
  color:#7c8995!important;
  font-size:10px!important;
  font-weight:850!important;
  letter-spacing:.045em!important;
  text-transform:uppercase!important;
}
.platformCommercialPage .commercialClientFacts b{
  display:block!important;
  margin-top:6px!important;
  color:#21384d!important;
  font-size:13px!important;
  line-height:1.3!important;
  overflow-wrap:anywhere!important;
}
.platformCommercialPage .commercialEditClientButton{
  display:flex!important;
  align-items:center!important;
  justify-content:center!important;
  width:190px!important;
  min-height:44px!important;
  margin-left:auto!important;
  padding:0 16px!important;
  border:1px solid #cfd9e1!important;
  border-radius:11px!important;
  background:#f7f9fb!important;
  color:#183149!important;
  font-size:13px!important;
  font-weight:850!important;
  cursor:pointer!important;
}
.platformCommercialPage .commercialEditClientButton:hover,
.platformCommercialPage .commercialClientCard.isEditing .commercialEditClientButton{
  border-color:#102a45!important;
  background:#102a45!important;
  color:#fff!important;
}
.platformCommercialPage .commercialClientEditor{
  margin-top:18px!important;
  padding:22px!important;
  border:1px solid #e4e9ed!important;
  border-radius:15px!important;
  background:#f8fafb!important;
}
.platformCommercialPage .commercialEditorGrid{
  gap:14px!important;
  margin-bottom:14px!important;
}
.platformCommercialPage .commercialClientEditor label,
.platformCommercialPage .planEditorChooser label{
  gap:7px!important;
  color:#506275!important;
  font-size:12px!important;
  font-weight:800!important;
}
.platformCommercialPage .commercialClientEditor input,
.platformCommercialPage .commercialClientEditor select,
.platformCommercialPage .planEditorChooser select{
  min-height:44px!important;
  padding:9px 11px!important;
  border:1px solid #ced8e0!important;
  border-radius:10px!important;
  background:#fff!important;
  color:#152b40!important;
  font-size:13px!important;
}
.platformCommercialPage .commercialDiscountInline{
  gap:14px!important;
  margin:16px 0!important;
  padding:16px!important;
  border-radius:14px!important;
}
.platformCommercialPage .commercialDiscountInline>div strong{
  font-size:14px!important;
}
.platformCommercialPage .commercialDiscountInline>div small{
  font-size:11px!important;
}
.platformCommercialPage .commercialBillingSnapshot{
  margin:15px 0!important;
  padding:16px!important;
  border-radius:14px!important;
}
.platformCommercialPage .commercialBillingSnapshot>strong{
  font-size:13px!important;
}
.platformCommercialPage .commercialBillingSnapshotGrid{
  gap:10px!important;
}
.platformCommercialPage .commercialBillingSnapshotGrid small{
  font-size:9px!important;
}
.platformCommercialPage .commercialBillingSnapshotGrid b{
  margin-top:5px!important;
  font-size:12px!important;
}
.platformCommercialPage .commercialEditorActions .button{
  min-height:44px!important;
  padding:0 18px!important;
  border-radius:10px!important;
  font-size:13px!important;
}
.platformCommercialPage .commercialToolsGrid{
  display:grid!important;
  grid-template-columns:repeat(3,minmax(0,1fr))!important;
  gap:14px!important;
  width:100%!important;
}
.platformCommercialPage .commercialToolCard{
  margin:0!important;
  padding:0!important;
  overflow:hidden!important;
  border:1px solid #dfe5ea!important;
  border-radius:18px!important;
  background:#fff!important;
  box-shadow:0 8px 24px rgba(14,34,53,.045)!important;
}
.platformCommercialPage .commercialToolCard[open]{
  grid-column:1/-1!important;
}
.platformCommercialPage .commercialToolSummary{
  min-height:132px!important;
  padding:20px!important;
  gap:7px!important;
}
.platformCommercialPage .commercialToolSummary:after{
  right:18px!important;
  top:18px!important;
  width:30px!important;
  height:30px!important;
  border-radius:9px!important;
}
.platformCommercialPage .commercialToolSummary>span{
  color:#a47a2d!important;
  font-size:10px!important;
}
.platformCommercialPage .commercialToolSummary>strong{
  color:#10263d!important;
  font-size:17px!important;
}
.platformCommercialPage .commercialToolSummary>small{
  max-width:85%!important;
  color:#778795!important;
  font-size:12px!important;
  line-height:1.4!important;
}
.platformCommercialPage .commercialToolBody{
  padding:0 22px 22px!important;
}
.platformCommercialPage .commercialToolBody label{
  font-size:12px!important;
}
.platformCommercialPage .commercialToolBody input,
.platformCommercialPage .commercialToolBody select{
  min-height:42px!important;
  font-size:13px!important;
}
.platformCommercialPage .commercialPaymentMetrics{
  grid-template-columns:repeat(4,minmax(0,1fr))!important;
  gap:12px!important;
}
.platformCommercialPage .commercialTable th{
  padding:12px!important;
  font-size:10px!important;
}
.platformCommercialPage .commercialTable td{
  padding:12px!important;
  font-size:12px!important;
}
.platformCommercialPage .commercialTable .tableSub{
  font-size:10px!important;
}
@media(max-width:1100px){
  .platformCommercialPage .commercialSummary{grid-template-columns:repeat(2,minmax(0,1fr))!important}
  .platformCommercialPage .commercialClientFacts{grid-template-columns:repeat(2,minmax(0,1fr))!important}
  .platformCommercialPage .commercialToolsGrid{grid-template-columns:1fr!important}
  .platformCommercialPage .commercialToolCard[open]{grid-column:auto!important}
  .platformCommercialPage .commercialMenuGrid{grid-template-columns:repeat(2,minmax(0,1fr))!important}
}
@media(max-width:720px){
  .platformCommercialPage .commercialAdminNav,
  .platformCommercialPage .platformCommercialShell{width:calc(100% - 24px)!important}
  .platformCommercialPage .commercialAdminNav{grid-template-columns:auto 1fr auto!important;gap:10px!important}
  .platformCommercialPage .commercialAdminNav .brand{width:46px!important;min-width:46px!important;height:46px!important}
  .platformCommercialPage .commercialAdminNav .brand img{width:46px!important;max-width:46px!important;max-height:46px!important}
  .platformCommercialPage .commercialHeaderTitle strong{font-size:15px!important}
  .platformCommercialPage .commercialHeaderTitle span{font-size:10px!important}
  .platformCommercialPage .commercialMenuButton{width:44px!important;padding:0!important;font-size:0!important}
  .platformCommercialPage .commercialMenuButton .commercialHamburger{margin:0!important}
  .platformCommercialPage .commercialPageIntro{align-items:flex-start!important;flex-direction:column!important;gap:12px!important}
  .platformCommercialPage .commercialPageIntro h1{font-size:27px!important}
  .platformCommercialPage .commercialPageIntro p{font-size:14px!important}
  .platformCommercialPage .commercialSummary{grid-template-columns:1fr!important}
  .platformCommercialPage .commercialClientsPanel{padding:18px!important;border-radius:17px!important}
  .platformCommercialPage .commercialClientsPanel .adminPanelHeader{flex-direction:column!important}
  .platformCommercialPage .commercialClientsPanel .adminPanelHeader h2{font-size:23px!important}
  .platformCommercialPage .commercialClientCard{padding:16px!important}
  .platformCommercialPage .commercialClientHeader{flex-direction:column!important}
  .platformCommercialPage .commercialClientFacts{grid-template-columns:1fr!important}
  .platformCommercialPage .commercialEditClientButton{width:100%!important;margin:0!important}
  .platformCommercialPage .commercialClientEditor{padding:15px!important}
  .platformCommercialPage .commercialEditorGrid.two,
  .platformCommercialPage .commercialEditorGrid.three,
  .platformCommercialPage .commercialDiscountInline,
  .platformCommercialPage .commercialBillingSnapshotGrid,
  .platformCommercialPage .commercialPaymentMetrics{grid-template-columns:1fr!important}
  .platformCommercialPage .commercialMenuPanel{right:12px!important;width:calc(100vw - 24px)!important}
  .platformCommercialPage .commercialMenuGrid{grid-template-columns:1fr!important}
}
`;function l(){return(0,d.jsx)(e.default,{children:(0,d.jsxs)("main",{className:"adminPage platformAdminPage platformCommercialPage",children:[(0,d.jsx)("style",{dangerouslySetInnerHTML:{__html:k}}),(0,d.jsx)("header",{className:"adminTopbar commercialTopbar",children:(0,d.jsxs)("div",{className:"container adminNav commercialAdminNav",children:[(0,d.jsx)("a",{className:"brand",href:"../",children:(0,d.jsx)("img",{src:"https://lenoy.com.br/wp-content/uploads/2026/08/hh.png",alt:"LENOY IMOBILI\xc1RIAS"})}),(0,d.jsxs)("div",{className:"commercialHeaderTitle",children:[(0,d.jsx)("strong",{children:"Administra\xe7\xe3o LENOY"}),(0,d.jsx)("span",{children:"Clientes, assinaturas e financeiro"})]}),(0,d.jsx)(h.default,{})]})}),(0,d.jsx)("div",{className:"container platformAdminShell platformCommercialShell",children:(0,d.jsxs)("section",{className:"adminContent commercialAdminContent",children:[(0,d.jsxs)("section",{className:"commercialPageIntro","aria-label":"Vis\xe3o geral da administra\xe7\xe3o",children:[(0,d.jsxs)("div",{className:"commercialPageIntroCopy",children:[(0,d.jsx)("span",{className:"eyebrow",children:"CENTRAL ADMINISTRATIVA"}),(0,d.jsx)("h1",{children:"Gest\xe3o da plataforma"}),(0,d.jsx)("p",{children:"Clientes, acessos, planos e cobran\xe7as em uma vis\xe3o mais clara, com informa\xe7\xf5es maiores e a\xe7\xf5es f\xe1ceis de localizar."})]}),(0,d.jsx)("span",{className:"commercialPageIntroBadge",children:"Sistema operacional"})]}),(0,d.jsx)(g.default,{}),(0,d.jsxs)("section",{className:"commercialToolsGrid","aria-label":"Ferramentas comerciais",children:[(0,d.jsx)(j.default,{}),(0,d.jsx)(i.default,{}),(0,d.jsx)(f.default,{})]})]})})]})})}},19121:a=>{"use strict";a.exports=require("next/dist/server/app-render/action-async-storage.external.js")},21183:(a,b,c)=>{"use strict";c.d(b,{default:()=>g});var d=c(14007),e=c(64898);let f=[{href:"#resumo-comercial",icon:"▦",title:"Resumo",text:"N\xfameros principais"},{href:"#clientes-comerciais",icon:"\uD83D\uDC65",title:"Clientes",text:"Cadastros e acesso"},{href:"#assinaturas-plataforma",icon:"◫",title:"Assinaturas",text:"Planos e descontos"},{href:"#planos-plataforma",icon:"R$",title:"Planos",text:"Pre\xe7os e recursos"},{href:"./cupons/",icon:"%",title:"Cupons",text:"Descontos por plano e cobran\xe7a"},{href:"#cobranca-plataforma",icon:"✓",title:"Pagamentos",text:"Hist\xf3rico financeiro"},{href:"./tecnico/",icon:"⚙",title:"\xc1rea t\xe9cnica",text:"Manuten\xe7\xe3o e seguran\xe7a"},{href:"../admin/",icon:"⌂",title:"Painel imobili\xe1ria",text:"Abrir painel operacional"},{href:"../",icon:"↗",title:"Ver plataforma",text:"Abrir p\xe1gina p\xfablica"}];function g(){let[a,b]=(0,e.useState)(!1),c=(0,e.useRef)(null);return(0,d.jsxs)("div",{className:"commercialMenuRoot",ref:c,children:[(0,d.jsxs)("button",{className:"commercialMenuButton",type:"button","aria-expanded":a,"aria-controls":"commercial-menu-grid",onClick:()=>b(a=>!a),children:[(0,d.jsxs)("span",{className:"commercialHamburger","aria-hidden":"true",children:[(0,d.jsx)("i",{}),(0,d.jsx)("i",{}),(0,d.jsx)("i",{})]}),(0,d.jsx)("span",{children:"Menu"})]}),a?(0,d.jsx)("div",{className:"commercialMenuPanel",id:"commercial-menu-grid",children:(0,d.jsx)("div",{className:"commercialMenuGrid",children:f.map(a=>(0,d.jsxs)("a",{className:"commercialMenuCard",href:a.href,onClick:()=>b(!1),children:[(0,d.jsx)("span",{className:"commercialMenuIcon","aria-hidden":"true",children:a.icon}),(0,d.jsx)("strong",{children:a.title}),(0,d.jsx)("small",{children:a.text})]},a.href))})}):null]})}},28354:a=>{"use strict";a.exports=require("util")},29294:a=>{"use strict";a.exports=require("next/dist/server/app-render/work-async-storage.external.js")},29965:(a,b,c)=>{"use strict";c.d(b,{default:()=>d});let d=(0,c(93661).registerClientReference)(function(){throw Error("Attempted to call the default export of \"/home/runner/work/IMOBILIARIAS/IMOBILIARIAS/apps/web/components/PlatformCommercialMenu.tsx\" from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"/home/runner/work/IMOBILIARIAS/IMOBILIARIAS/apps/web/components/PlatformCommercialMenu.tsx","default")},33873:a=>{"use strict";a.exports=require("path")},38522:a=>{"use strict";a.exports=require("node:zlib")},41025:a=>{"use strict";a.exports=require("next/dist/server/app-render/dynamic-access-async-storage.external.js")},45346:(a,b,c)=>{"use strict";c.d(b,{default:()=>h});var d=c(14007),e=c(64898),f=c(22744);function g(a,b="BRL"){return null!=a&&Number.isFinite(Number(a))?new Intl.NumberFormat("pt-BR",{style:"currency",currency:b||"BRL"}).format(Number(a)):"—"}function h(){let[a,b]=(0,e.useState)([]),[c,h]=(0,e.useState)([]),[i,j]=(0,e.useState)([]),[k,l]=(0,e.useState)(""),m=(0,e.useMemo)(()=>new Map(c.map(a=>[a.id,a.name])),[c]),n=(0,e.useMemo)(()=>new Map(i.map(a=>[a.id,a.name])),[i]),o=a.filter(a=>"paid"===a.status),p=a.filter(a=>"created"===a.status||"pending"===a.status),q=a.filter(a=>"failed"===a.status||"expired"===a.status),r=o.reduce((a,b)=>a+Number(b.paid_amount??b.amount??0),0);return(0,d.jsxs)("details",{className:"adminPanel commercialToolCard",id:"cobranca-plataforma",children:[(0,d.jsxs)("summary",{className:"commercialToolSummary",children:[(0,d.jsx)("span",{children:"PAGAMENTOS"}),(0,d.jsx)("strong",{children:"Hist\xf3rico financeiro"}),(0,d.jsx)("small",{children:"Toque para consultar"})]}),(0,d.jsx)("div",{className:"commercialToolBody commercialPaymentsPanel",children:f.$?(0,d.jsxs)(d.Fragment,{children:[(0,d.jsxs)("div",{className:"commercialPaymentMetrics",children:[(0,d.jsxs)("article",{children:[(0,d.jsx)("span",{children:"Recebido"}),(0,d.jsx)("strong",{children:g(r)}),(0,d.jsx)("small",{children:"nas cobran\xe7as listadas"})]}),(0,d.jsxs)("article",{children:[(0,d.jsx)("span",{children:"Confirmados"}),(0,d.jsx)("strong",{children:o.length}),(0,d.jsx)("small",{children:"pagamentos processados"})]}),(0,d.jsxs)("article",{className:p.length?"attention":"",children:[(0,d.jsx)("span",{children:"Aguardando"}),(0,d.jsx)("strong",{children:p.length}),(0,d.jsx)("small",{children:"pagamento"})]}),(0,d.jsxs)("article",{className:q.length?"danger":"",children:[(0,d.jsx)("span",{children:"N\xe3o conclu\xeddos"}),(0,d.jsx)("strong",{children:q.length}),(0,d.jsx)("small",{children:"falha ou expira\xe7\xe3o"})]})]}),k?(0,d.jsx)("div",{className:"formMessage",children:k}):null,(0,d.jsx)("div",{className:"adminTableWrap commercialTableWrap",children:(0,d.jsxs)("table",{className:"adminTable commercialTable",children:[(0,d.jsx)("thead",{children:(0,d.jsxs)("tr",{children:[(0,d.jsx)("th",{children:"Cliente"}),(0,d.jsx)("th",{children:"Plano"}),(0,d.jsx)("th",{children:"Cobran\xe7a"}),(0,d.jsx)("th",{children:"Valor normal"}),(0,d.jsx)("th",{children:"Desconto"}),(0,d.jsx)("th",{children:"Valor cobrado"}),(0,d.jsx)("th",{children:"Status"}),(0,d.jsx)("th",{children:"Data"}),(0,d.jsx)("th",{children:"Comprovante"})]})}),(0,d.jsxs)("tbody",{children:[a.map(a=>{var b,c,e,f,h;let i=a.base_amount??a.amount,j=a.paid_amount??a.amount;return(0,d.jsxs)("tr",{children:[(0,d.jsx)("td",{"data-label":"Cliente",children:(0,d.jsx)("strong",{children:m.get(a.agency_id)||"—"})}),(0,d.jsx)("td",{"data-label":"Plano",children:n.get(a.plan_id)||"—"}),(0,d.jsx)("td",{"data-label":"Cobran\xe7a",children:(b=a.charge_type,c=a.billing_cycle,e=a.implementation_waived,"implementation"===b?"Implanta\xe7\xe3o":"annual"===c?e?"Plano anual \xb7 implanta\xe7\xe3o gr\xe1tis":"Plano anual":"Mensalidade")}),(0,d.jsx)("td",{"data-label":"Valor normal",children:g(i,a.currency)}),(0,d.jsxs)("td",{"data-label":"Desconto",children:[Number(a.discount_percent||0).toLocaleString("pt-BR",{maximumFractionDigits:2}),"%"]}),(0,d.jsx)("td",{"data-label":"Valor cobrado",children:(0,d.jsx)("strong",{children:g(j,a.currency)})}),(0,d.jsx)("td",{"data-label":"Status",children:(0,d.jsx)("span",{className:`commercialStatus payment-${"paid"===(f=a.status)?"paid":"pending"===f||"created"===f?"pending":"failed"===f||"expired"===f?"failed":"neutral"}`,children:"paid"===(h=a.status)?"Pagamento confirmado":"pending"===h||"created"===h?"Aguardando pagamento":"failed"===h?"Pagamento n\xe3o conclu\xeddo":"expired"===h?"Cobran\xe7a expirada":"cancelled"===h?"Cancelado":h})}),(0,d.jsx)("td",{"data-label":"Data",children:new Date(a.completed_at||a.created_at).toLocaleString("pt-BR")}),(0,d.jsx)("td",{"data-label":"Comprovante",children:a.receipt_url?(0,d.jsx)("a",{className:"miniButton",href:a.receipt_url,target:"_blank",rel:"noreferrer",children:"Abrir"}):"—"})]},a.id)}),a.length?null:(0,d.jsx)("tr",{children:(0,d.jsx)("td",{colSpan:9,children:"Nenhuma cobran\xe7a registrada ainda."})})]})]})})]}):(0,d.jsx)("div",{className:"formNotice",children:"A cobran\xe7a ainda n\xe3o est\xe1 conectada ao ambiente de produ\xe7\xe3o."})})]})}},45598:(a,b,c)=>{"use strict";c.d(b,{default:()=>k});var d=c(14007),e=c(64898),f=c(22744);let g=[["trial","Conta interna / teste"],["active","Ativa"],["past_due","Pagamento atrasado"],["cancelled","Cancelada"],["expired","Encerrada"]];function h(a){return a?new Date(`${a}T12:00:00`).toISOString():null}function i(a){return null==a?"—":new Intl.NumberFormat("pt-BR",{style:"currency",currency:"BRL"}).format(Number(a))}function j(a,b,c){return Math.min(c,Math.max(b,a))}function k(){let[a,b]=(0,e.useState)([]),[c,k]=(0,e.useState)([]),[l,m]=(0,e.useState)([]),[n,o]=(0,e.useState)([]),[p,q]=(0,e.useState)(""),[r,s]=(0,e.useState)(""),[t,u]=(0,e.useState)("active"),[v,w]=(0,e.useState)(""),[x,y]=(0,e.useState)(""),[z,A]=(0,e.useState)("monthly"),[B,C]=(0,e.useState)(""),[D,E]=(0,e.useState)("0.00"),[F,G]=(0,e.useState)(""),[H,I]=(0,e.useState)(!1);async function J(){if(!f.L||!f.$)return;let[a,c,d,e]=await Promise.all([f.L.from("agencies").select("id,name,slug,status").order("name"),f.L.from("subscription_plans").select("id,name,code,active,monthly_price,annual_price,implementation_fee").order("display_order"),f.L.from("agency_subscriptions").select("id,agency_id,plan_id,status,starts_at,renews_at,ends_at").order("starts_at",{ascending:!1}),f.L.from("agency_billing_discounts").select("id,agency_id,plan_id,billing_cycle,base_amount,final_amount,discount_percent,status,created_at").eq("status","active").order("created_at",{ascending:!1})]),g=a.error||c.error||d.error||e.error;if(g)return G(g.message);b(a.data||[]),k(c.data||[]),m(d.data||[]),o(e.data||[]),q(b=>b||String(a.data?.[0]?.id||""))}let K=c.filter(a=>"homologacao"!==a.code&&a.active),L=(0,e.useMemo)(()=>l.find(a=>a.agency_id===p&&["trial","active","past_due"].includes(a.status))||null,[l,p]),M=c.find(a=>a.id===L?.plan_id)||null,N=c.find(a=>a.id===r)||null,O=N?Number("annual"===z?N.annual_price||0:N.monthly_price||0):0;async function P(){if(!f.L||!p||!r)return G("Selecione cliente e plano.");I(!0),G("");let{error:a}=await f.L.rpc("platform_set_agency_subscription",{p_agency_id:p,p_plan_id:r,p_status:t,p_renews_at:h(v),p_ends_at:h(x)});if(I(!1),a)return G(a.message);G("Assinatura atualizada."),await J()}async function Q(){if(!f.L||!p||!r||!O)return G("Selecione cliente, plano e cobran\xe7a.");let a=Number(B.replace(",","."));if(!Number.isFinite(a)||a<=0||a>O)return G("Informe um valor v\xe1lido.");I(!0),G("");let b=a<O?await f.L.rpc("platform_set_agency_billing_discount",{p_agency_id:p,p_plan_id:r,p_billing_cycle:z,p_final_amount:a}):await f.L.rpc("platform_clear_agency_billing_discount",{p_agency_id:p,p_plan_id:r,p_billing_cycle:z});if(I(!1),b.error)return G(b.error.message);G(a<O?`Desconto salvo: ${D}%.`:"Valor normal restaurado."),await J()}return n.find(a=>a.agency_id===p&&a.plan_id===r&&a.billing_cycle===z),f.$?(0,d.jsxs)("details",{className:"adminPanel commercialToolCard",id:"assinaturas-plataforma",children:[(0,d.jsxs)("summary",{className:"commercialToolSummary",children:[(0,d.jsx)("span",{children:"ASSINATURAS"}),(0,d.jsx)("strong",{children:"Plano, cobran\xe7a e desconto por cliente"}),(0,d.jsx)("small",{children:"Toque para administrar"})]}),(0,d.jsxs)("div",{className:"commercialToolBody",children:[(0,d.jsxs)("div",{className:"propertyForm",children:[(0,d.jsxs)("div",{className:"formGrid",children:[(0,d.jsxs)("label",{children:["Cliente",(0,d.jsx)("select",{value:p,onChange:a=>q(a.target.value),children:a.map(a=>(0,d.jsxs)("option",{value:a.id,children:[a.name," \xb7 ",a.slug]},a.id))})]}),(0,d.jsxs)("label",{children:["Plano",(0,d.jsxs)("select",{value:r,onChange:a=>s(a.target.value),children:[M?.code==="homologacao"?(0,d.jsx)("option",{value:M.id,children:"Conta interna atual"}):null,K.map(a=>(0,d.jsx)("option",{value:a.id,children:a.name},a.id))]})]})]}),(0,d.jsxs)("div",{className:"formGrid three",children:[(0,d.jsxs)("label",{children:["Status da assinatura",(0,d.jsx)("select",{value:t,onChange:a=>u(a.target.value),children:g.map(([a,b])=>(0,d.jsx)("option",{value:a,children:b},a))})]}),(0,d.jsxs)("label",{children:["Pr\xf3ximo vencimento",(0,d.jsx)("input",{type:"date",value:v,onChange:a=>w(a.target.value)})]}),(0,d.jsxs)("label",{children:["T\xe9rmino",(0,d.jsx)("input",{type:"date",value:x,onChange:a=>y(a.target.value)})]})]}),(0,d.jsx)("div",{className:"formActions",children:(0,d.jsx)("button",{className:"button primary",type:"button",disabled:H,onClick:()=>void P(),children:H?"Salvando...":"Salvar assinatura"})})]}),(0,d.jsxs)("div",{className:"platformDiscountEditor compactDiscountEditor",children:[(0,d.jsx)("h3",{children:"Desconto da pr\xf3xima cobran\xe7a"}),(0,d.jsxs)("div",{className:"formGrid three",children:[(0,d.jsxs)("label",{children:["Cobran\xe7a",(0,d.jsxs)("select",{value:z,onChange:a=>A(a.target.value),children:[(0,d.jsx)("option",{value:"monthly",children:"Mensal"}),(0,d.jsx)("option",{value:"annual",children:"Anual \xb7 25% padr\xe3o"})]})]}),(0,d.jsxs)("label",{children:["Valor normal",(0,d.jsx)("input",{value:i(O),readOnly:!0})]}),(0,d.jsxs)("label",{children:["Implanta\xe7\xe3o",(0,d.jsx)("input",{value:"annual"===z?"Gr\xe1tis no anual":N?i(N.implementation_fee):"—",readOnly:!0})]})]}),(0,d.jsxs)("div",{className:"formGrid",children:[(0,d.jsxs)("label",{children:["Valor a cobrar (R$)",(0,d.jsx)("input",{type:"number",min:"0.01",step:"0.01",value:B,onChange:a=>{var b;let c;return C(b=a.target.value),c=Number(b.replace(",",".")),void(O&&Number.isFinite(c)&&E(j((O-c)/O*100,0,99.99).toFixed(2)))}})]}),(0,d.jsxs)("label",{children:["Desconto (%)",(0,d.jsx)("input",{type:"number",min:"0",max:"99.99",step:"0.01",value:D,onChange:a=>{var b;let c;return E(b=a.target.value),c=Number(b.replace(",",".")),void(O&&Number.isFinite(c)&&C((O*(1-j(c,0,99.99)/100)).toFixed(2)))}})]})]}),(0,d.jsx)("div",{className:"formActions",children:(0,d.jsx)("button",{className:"button primary",type:"button",disabled:H,onClick:()=>void Q(),children:"Salvar valor / desconto"})})]}),F?(0,d.jsx)("div",{className:"formMessage",children:F}):null]})]}):(0,d.jsxs)("details",{className:"adminPanel commercialToolCard",id:"assinaturas-plataforma",children:[(0,d.jsxs)("summary",{children:[(0,d.jsx)("span",{children:"Assinaturas"}),(0,d.jsx)("strong",{children:"Plano, cobran\xe7a e desconto"})]}),(0,d.jsx)("div",{className:"formNotice",children:"Cobran\xe7a n\xe3o conectada."})]})}},46060:a=>{"use strict";a.exports=require("next/dist/shared/lib/no-fallback-error.external.js")},50152:(a,b,c)=>{"use strict";c.r(b),c.d(b,{__next_app__:()=>r,handler:()=>t,routeModule:()=>s});var d=c(10001),e=c(87517),f=c(14418),g=c(64073),h={};for(let a in g)0>["default","__next_app__","routeModule","handler"].indexOf(a)&&(h[a]=()=>g[a]);c.d(b,h);let i=(0,d.p)(()=>Promise.resolve().then(c.bind(c,96312))),j=(0,d.p)(()=>Promise.resolve().then(c.t.bind(c,66673,23))),k=(0,d.p)(()=>Promise.resolve().then(c.t.bind(c,26069,23))),l=(0,d.p)(()=>Promise.resolve().then(c.t.bind(c,98232,23))),m=(0,d.p)(()=>Promise.resolve().then(c.t.bind(c,69259,23))),n=(0,d.p)(()=>Promise.resolve().then(c.bind(c,42152))),o=(0,d.p)(()=>Promise.resolve().then(c.t.bind(c,66673,23))),p={children:["",{children:["plataforma",{children:["__PAGE__",{},{page:[(0,d.p)(()=>Promise.resolve().then(c.bind(c,19055))),"/home/runner/work/IMOBILIARIAS/IMOBILIARIAS/apps/web/app/plataforma/page.tsx"]}]},{layout:[n,"/home/runner/work/IMOBILIARIAS/IMOBILIARIAS/apps/web/app/plataforma/layout.tsx"],"global-error":[o,"next/dist/client/components/builtin/global-error.js"]},[]]},{layout:[i,"/home/runner/work/IMOBILIARIAS/IMOBILIARIAS/apps/web/app/layout.tsx"],"global-error":[j,"next/dist/client/components/builtin/global-error.js"],"not-found":[k,"next/dist/client/components/builtin/not-found.js"],forbidden:[l,"next/dist/client/components/builtin/forbidden.js"],unauthorized:[m,"next/dist/client/components/builtin/unauthorized.js"]},[]]}.children,q=(0,e.H)({tree:p,page:"/plataforma/page",pathname:"/plataforma",require:c,loadChunk:()=>Promise.resolve(),interopDefault:f.T}),r=q.__next_app__,s=q.routeModule,t=q.handler},61220:(a,b,c)=>{Promise.resolve().then(c.bind(c,50020)),Promise.resolve().then(c.bind(c,76696)),Promise.resolve().then(c.bind(c,85246)),Promise.resolve().then(c.bind(c,29965)),Promise.resolve().then(c.bind(c,98666)),Promise.resolve().then(c.bind(c,96300))},63033:a=>{"use strict";a.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},76696:(a,b,c)=>{"use strict";c.d(b,{default:()=>d});let d=(0,c(93661).registerClientReference)(function(){throw Error("Attempted to call the default export of \"/home/runner/work/IMOBILIARIAS/IMOBILIARIAS/apps/web/components/PlatformBillingOverview.tsx\" from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"/home/runner/work/IMOBILIARIAS/IMOBILIARIAS/apps/web/components/PlatformBillingOverview.tsx","default")},80964:(a,b,c)=>{"use strict";c.d(b,{default:()=>j});var d=c(14007),e=c(64898),f=c(22744);function g(a){let b=String(a||"").trim().replace(",",".");if(!b)return null;let c=Number(b);return Number.isFinite(c)?c:null}let h=[["exclusive_site","Site exclusivo"],["property_catalog","Cat\xe1logo de im\xf3veis"],["full_management","Gest\xe3o completa"],["broker_app","Aplicativo do corretor"],["crm_real_estate","CRM imobili\xe1rio"],["documents","Central de documentos"],["ai_buyer_outreach","IA de oportunidades"],["buyer_property_matching","Matching comprador \xd7 im\xf3vel"],["consented_auto_outreach","Contato autom\xe1tico com consentimento"],["property_portals","Portais imobili\xe1rios"],["facebook_lead_ads","Facebook Lead Ads"],["whatsapp_site","WhatsApp no site"],["seo_site","Site otimizado para SEO"],["key_control","Controle de chaves"],["proposal_control","Controle de propostas"],["inspections","Vistorias"],["visit_agenda","Agenda e visitas"],["customer_management","Gest\xe3o de clientes"],["sales_management","Gest\xe3o de vendas"],["advanced_lead_reservation","Reserva avan\xe7ada de leads"],["user_permissions","Permiss\xf5es por usu\xe1rio"],["strategic_reports","Relat\xf3rios estrat\xe9gicos"],["multi_team","Gest\xe3o multi-equipe"],["custom_domain","Dom\xednio pr\xf3prio"],["priority_operations","Prioridade operacional"],["advanced_automation","Automa\xe7\xf5es avan\xe7adas"],["push_notifications","Push no aplicativo"],["email_leads","Contatos por e-mail"],["ai_descriptions","Descri\xe7\xf5es com IA"]];function i(a,b){let c=a[b];return null==c?"":String(Number(c))}function j(){let a,[b,c]=(0,e.useState)([]),[j,k]=(0,e.useState)(""),[l,m]=(0,e.useState)(!1),[n,o]=(0,e.useState)(null),[p,q]=(0,e.useState)(!1);async function r(){if(!f.L)return;let{data:a,error:b}=await f.L.from("subscription_plans").select("id,code,name,description,monthly_price,annual_price,implementation_fee,annual_discount_percent,monthly_validity_days,annual_validity_days,max_properties,max_users,max_ai_descriptions,features,active,display_order").neq("code","homologacao").order("display_order").order("name");if(b)return k(b.message);let d=a||[];c(d),o(a=>a?d.find(b=>b.id===a.id)||d[0]||null:d[0]||null)}async function s(a){if(a.preventDefault(),!f.L)return;let b=new FormData(a.currentTarget),c=String(b.get("name")||"").trim(),d=String(b.get("code")||c).toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g,"").replace(/[^a-z0-9]+/g,"-").replace(/^-|-$/g,"").slice(0,40);if(!c||!d)return k("Informe nome e c\xf3digo do plano.");let e={...n?.features||{},commercial:!0,internal_only:!1,default_trial:!1};h.forEach(([a])=>{e[a]="on"===b.get(a)}),e.max_buyer_outreach_per_month=g(b.get("max_buyer_outreach_per_month")),e.max_documents=g(b.get("max_documents")),e.max_document_uploads=g(b.get("max_document_uploads")),e.max_concurrent_accesses=g(b.get("max_concurrent_accesses")),e.max_professional_emails=g(b.get("max_professional_emails")),e.max_photos_per_property=g(b.get("max_photos_per_property")),e.featured="on"===b.get("featured"),e.public_benefits=String(b.get("public_benefits")||"").split(/\r?\n/).map(a=>a.trim()).filter(Boolean);let i={code:d,name:c,description:String(b.get("description")||"").trim()||null,monthly_price:g(b.get("monthly_price")),annual_price:g(b.get("annual_price")),implementation_fee:g(b.get("implementation_fee"))||0,annual_discount_percent:g(b.get("annual_discount_percent"))??25,monthly_validity_days:Number(b.get("monthly_validity_days")||30),annual_validity_days:Number(b.get("annual_validity_days")||365),max_properties:g(b.get("max_properties")),max_users:g(b.get("max_users")),max_ai_descriptions:g(b.get("max_ai_descriptions")),features:e,active:"on"===b.get("active"),display_order:Number(b.get("display_order")||0),updated_at:new Date().toISOString()};m(!0),k("");let j=n&&!p?await f.L.from("subscription_plans").update(i).eq("id",n.id):await f.L.from("subscription_plans").insert(i);if(m(!1),j.error)return k(j.error.message);k(n&&!p?"Plano atualizado. Site, comparativo e checkout usar\xe3o os novos dados.":"Plano criado."),q(!1),await r()}let t=p?{}:n?.features||{},u=p?"new":n?.id||"none";return(0,d.jsxs)("details",{className:"adminPanel commercialToolCard",id:"planos-plataforma",children:[(0,d.jsxs)("summary",{className:"commercialToolSummary",children:[(0,d.jsx)("span",{children:"PLANOS"}),(0,d.jsx)("strong",{children:"Planos, pre\xe7os e benef\xedcios"}),(0,d.jsx)("small",{children:"Toque para editar"})]}),(0,d.jsxs)("div",{className:"commercialToolBody",children:[(0,d.jsxs)("div",{className:"planEditorChooser",children:[(0,d.jsxs)("label",{children:["Plano para editar",(0,d.jsxs)("select",{value:p?"new":n?.id||"",onChange:a=>{"new"===a.target.value?(q(!0),o(null)):(q(!1),o(b.find(b=>b.id===a.target.value)||null))},children:[(0,d.jsx)("option",{value:"new",children:"+ Criar novo plano"}),b.map(a=>(0,d.jsx)("option",{value:a.id,children:a.name},a.id))]})]}),(0,d.jsx)("span",{children:n&&!p?n.active?"Ativo":"Inativo":"Novo plano"})]}),(0,d.jsxs)("form",{className:"propertyForm compactPlanForm",onSubmit:s,children:[(0,d.jsxs)("div",{className:"formGrid three",children:[(0,d.jsxs)("label",{children:["Nome",(0,d.jsx)("input",{name:"name",defaultValue:p?"":n?.name||"",required:!0})]}),(0,d.jsxs)("label",{children:["C\xf3digo",(0,d.jsx)("input",{name:"code",defaultValue:p?"":n?.code||"",required:!0})]}),(0,d.jsxs)("label",{children:["Ordem",(0,d.jsx)("input",{name:"display_order",type:"number",defaultValue:p?10*b.length+10:n?.display_order||0})]})]}),(0,d.jsxs)("label",{children:["Descri\xe7\xe3o",(0,d.jsx)("input",{name:"description",defaultValue:p?"":n?.description||""})]}),(0,d.jsxs)("div",{className:"formGrid three",children:[(0,d.jsxs)("label",{children:["Pre\xe7o mensal (R$)",(0,d.jsx)("input",{name:"monthly_price",inputMode:"decimal",defaultValue:p?"":n?.monthly_price??""})]}),(0,d.jsxs)("label",{children:["Pre\xe7o anual (R$)",(0,d.jsx)("input",{name:"annual_price",inputMode:"decimal",defaultValue:p?"":n?.annual_price??""})]}),(0,d.jsxs)("label",{children:["Implanta\xe7\xe3o (R$)",(0,d.jsx)("input",{name:"implementation_fee",inputMode:"decimal",defaultValue:p?"":n?.implementation_fee??""})]})]}),(0,d.jsxs)("div",{className:"formGrid three",children:[(0,d.jsxs)("label",{children:["Desconto anual padr\xe3o (%)",(0,d.jsx)("input",{name:"annual_discount_percent",type:"number",min:"0",max:"99",step:"0.01",defaultValue:p?25:n?.annual_discount_percent??25})]}),(0,d.jsxs)("label",{children:["Validade mensal (dias)",(0,d.jsx)("input",{name:"monthly_validity_days",type:"number",min:"1",max:"3650",defaultValue:p?30:n?.monthly_validity_days??30})]}),(0,d.jsxs)("label",{children:["Validade anual (dias)",(0,d.jsx)("input",{name:"annual_validity_days",type:"number",min:"1",max:"3650",defaultValue:p?365:n?.annual_validity_days??365})]})]}),(0,d.jsxs)("div",{className:"formGrid three",children:[(0,d.jsxs)("label",{children:["M\xe1x. im\xf3veis",(0,d.jsx)("input",{name:"max_properties",type:"number",min:"1",defaultValue:p?"":n?.max_properties??""})]}),(0,d.jsxs)("label",{children:["M\xe1x. usu\xe1rios",(0,d.jsx)("input",{name:"max_users",type:"number",min:"1",defaultValue:p?"":n?.max_users??""})]}),(0,d.jsxs)("label",{children:["Descri\xe7\xf5es IA/m\xeas",(0,d.jsx)("input",{name:"max_ai_descriptions",type:"number",min:"0",defaultValue:p?"":n?.max_ai_descriptions??""})]})]}),(0,d.jsxs)("div",{className:"formGrid three",children:[(0,d.jsxs)("label",{children:["Acessos simult\xe2neos",(0,d.jsx)("input",{name:"max_concurrent_accesses",type:"number",min:"0",defaultValue:i(t,"max_concurrent_accesses")})]}),(0,d.jsxs)("label",{children:["E-mails profissionais",(0,d.jsx)("input",{name:"max_professional_emails",type:"number",min:"0",defaultValue:i(t,"max_professional_emails")})]}),(0,d.jsxs)("label",{children:["Fotos por im\xf3vel",(0,d.jsx)("input",{name:"max_photos_per_property",type:"number",min:"0",defaultValue:i(t,"max_photos_per_property")})]})]}),(0,d.jsxs)("fieldset",{className:"featurePicker compactFeaturePicker",children:[(0,d.jsx)("legend",{children:"Benef\xedcios e recursos do plano"}),(0,d.jsx)("div",{className:"commercialFeatureGrid",children:h.map(([a,b])=>(0,d.jsxs)("label",{className:"featureOption",children:[(0,d.jsx)("input",{type:"checkbox",name:a,defaultChecked:p?["exclusive_site","property_catalog","crm_real_estate"].includes(a):!!t[a]}),(0,d.jsx)("span",{children:b})]},a))})]}),(0,d.jsxs)("label",{children:["Benef\xedcios extras exibidos ao p\xfablico ",(0,d.jsx)("small",{children:"Um benef\xedcio por linha."}),(0,d.jsx)("textarea",{name:"public_benefits",rows:5,defaultValue:Array.isArray(a=t.public_benefits)?a.map(String).filter(Boolean).join("\n"):"",placeholder:"Ex.: Suporte priorit\xe1rio\nTreinamento de implanta\xe7\xe3o"})]}),(0,d.jsxs)("div",{className:"formGrid three",children:[(0,d.jsxs)("label",{children:["M\xe1x. contatos IA/m\xeas",(0,d.jsx)("input",{name:"max_buyer_outreach_per_month",type:"number",min:"0",defaultValue:i(t,"max_buyer_outreach_per_month"),placeholder:"Ilimitado"})]}),(0,d.jsxs)("label",{children:["M\xe1x. documentos ativos",(0,d.jsx)("input",{name:"max_documents",type:"number",min:"0",defaultValue:i(t,"max_documents"),placeholder:"Ilimitado"})]}),(0,d.jsxs)("label",{children:["M\xe1x. anexos privados",(0,d.jsx)("input",{name:"max_document_uploads",type:"number",min:"0",defaultValue:i(t,"max_document_uploads"),placeholder:"Ilimitado"})]})]}),(0,d.jsxs)("div",{className:"formGrid",children:[(0,d.jsxs)("label",{className:"compactActiveCheck",children:[(0,d.jsx)("input",{type:"checkbox",name:"active",defaultChecked:!!p||(n?.active??!0)}),(0,d.jsx)("span",{children:"Plano ativo para novas compras"})]}),(0,d.jsxs)("label",{className:"compactActiveCheck",children:[(0,d.jsx)("input",{type:"checkbox",name:"featured",defaultChecked:!!t.featured}),(0,d.jsx)("span",{children:"Destacar como “Mais escolhido”"})]})]}),(0,d.jsx)("div",{className:"formActions",children:(0,d.jsx)("button",{className:"button primary",disabled:l,children:l?"Salvando...":p?"Criar plano":"Salvar altera\xe7\xf5es"})})]},u),j?(0,d.jsx)("div",{className:"formMessage",children:j}):null]})]})}},85246:(a,b,c)=>{"use strict";c.d(b,{default:()=>d});let d=(0,c(93661).registerClientReference)(function(){throw Error("Attempted to call the default export of \"/home/runner/work/IMOBILIARIAS/IMOBILIARIAS/apps/web/components/PlatformCommercialDashboard.tsx\" from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"/home/runner/work/IMOBILIARIAS/IMOBILIARIAS/apps/web/components/PlatformCommercialDashboard.tsx","default")},96300:(a,b,c)=>{"use strict";c.d(b,{default:()=>d});let d=(0,c(93661).registerClientReference)(function(){throw Error("Attempted to call the default export of \"/home/runner/work/IMOBILIARIAS/IMOBILIARIAS/apps/web/components/PlatformSubscriptionManager.tsx\" from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"/home/runner/work/IMOBILIARIAS/IMOBILIARIAS/apps/web/components/PlatformSubscriptionManager.tsx","default")},98020:(a,b,c)=>{Promise.resolve().then(c.bind(c,8502)),Promise.resolve().then(c.bind(c,45346)),Promise.resolve().then(c.bind(c,17640)),Promise.resolve().then(c.bind(c,21183)),Promise.resolve().then(c.bind(c,80964)),Promise.resolve().then(c.bind(c,45598))},98666:(a,b,c)=>{"use strict";c.d(b,{default:()=>d});let d=(0,c(93661).registerClientReference)(function(){throw Error("Attempted to call the default export of \"/home/runner/work/IMOBILIARIAS/IMOBILIARIAS/apps/web/components/PlatformPlanManager.tsx\" from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"/home/runner/work/IMOBILIARIAS/IMOBILIARIAS/apps/web/components/PlatformPlanManager.tsx","default")}};var b=require("../../webpack-runtime.js");b.C(a);var c=b.X(0,[489,956,944,518,814],()=>b(b.s=50152));module.exports=c})();