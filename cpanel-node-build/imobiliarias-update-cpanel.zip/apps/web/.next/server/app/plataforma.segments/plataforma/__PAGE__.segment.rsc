1:"$Sreact.fragment"
2:I[2356,["2099","static/chunks/9e43655a-f7a66e860f4f65ab.js","6424","static/chunks/6424-d4ec3c90cc423455.js","370","static/chunks/app/plataforma/page-f71c08bb0188572b.js"],"default"]
3:T4933,
.platformCommercialPage{
  min-height:100vh!important;
  background:#f4f6f8!important;
  color:#15293d!important;
}
.platformCommercialPage .commercialTopbar{
  position:sticky!important;
  top:0!important;
  z-index:100!important;
  min-height:76px!important;
  background:#0b2946!important;
  border:0!important;
  border-bottom:1px solid rgba(255,255,255,.1)!important;
  box-shadow:0 8px 24px rgba(9,31,52,.12)!important;
}
.platformCommercialPage .commercialAdminNav{
  width:min(1540px,calc(100% - 40px))!important;
  max-width:1540px!important;
  min-height:76px!important;
  margin:0 auto!important;
  padding:8px 0!important;
  display:grid!important;
  grid-template-columns:auto 1fr auto!important;
  align-items:center!important;
  gap:16px!important;
}
.platformCommercialPage .commercialAdminNav .brand{
  display:flex!important;
  align-items:center!important;
  justify-content:center!important;
  width:58px!important;
  min-width:58px!important;
  height:58px!important;
}
.platformCommercialPage .commercialAdminNav .brand img{
  width:58px!important;
  max-width:58px!important;
  max-height:58px!important;
  object-fit:contain!important;
}
.platformCommercialPage .commercialHeaderTitle{
  display:flex!important;
  flex-direction:column!important;
  gap:3px!important;
  color:#fff!important;
}
.platformCommercialPage .commercialHeaderTitle strong{
  font-size:18px!important;
  line-height:1.15!important;
  letter-spacing:-.01em!important;
}
.platformCommercialPage .commercialHeaderTitle span{
  font-size:12px!important;
  color:#b9c9d7!important;
}
.platformCommercialPage .commercialMenuButton{
  min-height:44px!important;
  padding:0 16px!important;
  border-radius:12px!important;
  font-size:13px!important;
}
.platformCommercialPage .commercialMenuPanel{
  top:86px!important;
  right:20px!important;
  width:min(1000px,calc(100vw - 40px))!important;
  padding:18px!important;
  border-radius:18px!important;
  box-shadow:0 28px 70px rgba(7,23,43,.24)!important;
}
.platformCommercialPage .commercialMenuGrid{
  grid-template-columns:repeat(4,minmax(0,1fr))!important;
  gap:12px!important;
}
.platformCommercialPage .commercialMenuCard{
  min-height:122px!important;
  padding:16px!important;
  border-radius:14px!important;
}
.platformCommercialPage .commercialMenuIcon{
  width:36px!important;
  height:36px!important;
  border-radius:10px!important;
  font-size:15px!important;
}
.platformCommercialPage .commercialMenuCard strong{
  font-size:14px!important;
}
.platformCommercialPage .commercialMenuCard small{
  font-size:12px!important;
  line-height:1.35!important;
}
.platformCommercialPage .platformCommercialShell{
  box-sizing:border-box!important;
  width:min(1540px,calc(100% - 40px))!important;
  max-width:1540px!important;
  margin:0 auto!important;
  padding:30px 0 56px!important;
}
.platformCommercialPage .commercialAdminContent{
  width:100%!important;
  max-width:none!important;
  margin:0!important;
  padding:0!important;
}
.platformCommercialPage .commercialPageIntro{
  display:flex!important;
  align-items:flex-end!important;
  justify-content:space-between!important;
  gap:24px!important;
  margin:0 0 24px!important;
  padding:4px 2px!important;
}
.platformCommercialPage .commercialPageIntroCopy{
  max-width:760px!important;
}
.platformCommercialPage .commercialPageIntro .eyebrow{
  display:block!important;
  margin-bottom:7px!important;
  color:#a77b25!important;
  font-size:11px!important;
  font-weight:900!important;
  letter-spacing:.12em!important;
}
.platformCommercialPage .commercialPageIntro h1{
  margin:0!important;
  color:#10263d!important;
  font-size:32px!important;
  line-height:1.08!important;
  letter-spacing:-.035em!important;
}
.platformCommercialPage .commercialPageIntro p{
  max-width:700px!important;
  margin:9px 0 0!important;
  color:#637384!important;
  font-size:15px!important;
  line-height:1.5!important;
}
.platformCommercialPage .commercialPageIntroBadge{
  display:inline-flex!important;
  align-items:center!important;
  gap:8px!important;
  min-height:38px!important;
  padding:0 14px!important;
  border:1px solid #d9e1e7!important;
  border-radius:999px!important;
  background:#fff!important;
  color:#43596e!important;
  font-size:12px!important;
  font-weight:800!important;
  white-space:nowrap!important;
  box-shadow:0 5px 16px rgba(16,36,58,.04)!important;
}
.platformCommercialPage .commercialPageIntroBadge:before{
  content:''!important;
  width:8px!important;
  height:8px!important;
  border-radius:999px!important;
  background:#2d9b65!important;
  box-shadow:0 0 0 4px #e6f5ed!important;
}
.platformCommercialPage .commercialSummary{
  display:grid!important;
  grid-template-columns:repeat(4,minmax(0,1fr))!important;
  gap:14px!important;
  margin:0 0 24px!important;
}
.platformCommercialPage .commercialSummary article,
.platformCommercialPage .commercialPaymentMetrics article{
  position:relative!important;
  box-sizing:border-box!important;
  min-width:0!important;
  min-height:112px!important;
  padding:18px 20px!important;
  overflow:hidden!important;
  border:1px solid #e0e6eb!important;
  border-radius:17px!important;
  background:#fff!important;
  box-shadow:0 8px 24px rgba(16,36,58,.055)!important;
}
.platformCommercialPage .commercialSummary article:before{
  content:''!important;
  position:absolute!important;
  top:0!important;
  left:0!important;
  width:4px!important;
  height:100%!important;
  background:#143c61!important;
  opacity:.9!important;
}
.platformCommercialPage .commercialSummary article.attention,
.platformCommercialPage .commercialPaymentMetrics article.attention{
  border-color:#ead29d!important;
  background:#fffdf8!important;
}
.platformCommercialPage .commercialSummary article.attention:before{background:#d5a33b!important}
.platformCommercialPage .commercialSummary article.danger,
.platformCommercialPage .commercialPaymentMetrics article.danger{
  border-color:#e8b8b2!important;
  background:#fffafa!important;
}
.platformCommercialPage .commercialSummary article.danger:before{background:#c85b50!important}
.platformCommercialPage .commercialSummary span,
.platformCommercialPage .commercialPaymentMetrics span{
  display:block!important;
  color:#6f7f8d!important;
  font-size:11px!important;
  font-weight:900!important;
  letter-spacing:.07em!important;
  text-transform:uppercase!important;
}
.platformCommercialPage .commercialSummary strong,
.platformCommercialPage .commercialPaymentMetrics strong{
  display:block!important;
  margin-top:8px!important;
  color:#10263d!important;
  font-size:29px!important;
  line-height:1!important;
  letter-spacing:-.035em!important;
}
.platformCommercialPage .commercialSummary small,
.platformCommercialPage .commercialPaymentMetrics small{
  display:block!important;
  margin-top:7px!important;
  color:#83909b!important;
  font-size:12px!important;
  line-height:1.3!important;
}
.platformCommercialPage .commercialClientsPanel{
  width:100%!important;
  margin:0 0 24px!important;
  padding:26px!important;
  border:1px solid #e0e6eb!important;
  border-radius:22px!important;
  background:#fff!important;
  box-shadow:0 10px 32px rgba(16,36,58,.06)!important;
}
.platformCommercialPage .commercialClientsPanel .adminPanelHeader{
  display:flex!important;
  align-items:flex-start!important;
  justify-content:space-between!important;
  gap:20px!important;
  margin:0 0 22px!important;
  padding:0 0 20px!important;
  border-bottom:1px solid #edf1f4!important;
}
.platformCommercialPage .commercialClientsPanel .eyebrow{
  color:#a77b25!important;
  font-size:11px!important;
  font-weight:900!important;
  letter-spacing:.12em!important;
}
.platformCommercialPage .commercialClientsPanel .adminPanelHeader h2{
  margin:5px 0 0!important;
  color:#10263d!important;
  font-size:28px!important;
  line-height:1.1!important;
  letter-spacing:-.025em!important;
}
.platformCommercialPage .commercialClientsPanel .adminPanelHeader p{
  max-width:760px!important;
  margin:8px 0 0!important;
  color:#6b7a88!important;
  font-size:14px!important;
  line-height:1.5!important;
}
.platformCommercialPage .commercialClientsPanel .statusPill{
  min-height:34px!important;
  padding:7px 12px!important;
  border-radius:999px!important;
  background:#eef6f1!important;
  color:#2f6e4c!important;
  font-size:12px!important;
  font-weight:850!important;
}
.platformCommercialPage .commercialClientGrid{
  display:grid!important;
  grid-template-columns:1fr!important;
  gap:16px!important;
  width:100%!important;
}
.platformCommercialPage .commercialClientCard{
  box-sizing:border-box!important;
  width:100%!important;
  min-width:0!important;
  padding:20px!important;
  border:1px solid #dfe5ea!important;
  border-radius:18px!important;
  background:#fff!important;
  box-shadow:0 5px 18px rgba(14,34,53,.035)!important;
  transition:border-color .18s ease,box-shadow .18s ease,transform .18s ease!important;
}
.platformCommercialPage .commercialClientCard:hover{
  border-color:#cbd6df!important;
  box-shadow:0 10px 26px rgba(14,34,53,.07)!important;
}
.platformCommercialPage .commercialClientCard.isEditing{
  grid-column:auto!important;
  border-color:#d1ad61!important;
  box-shadow:0 14px 34px rgba(14,34,53,.09)!important;
}
.platformCommercialPage .commercialClientHeader{
  display:flex!important;
  align-items:flex-start!important;
  justify-content:space-between!important;
  gap:18px!important;
  padding:0 0 16px!important;
  border-bottom:1px solid #edf1f4!important;
}
.platformCommercialPage .commercialClientHeader>div{
  display:grid!important;
  gap:4px!important;
  min-width:0!important;
}
.platformCommercialPage .commercialClientHeader strong{
  color:#10263d!important;
  font-size:19px!important;
  line-height:1.2!important;
  letter-spacing:-.015em!important;
}
.platformCommercialPage .commercialClientHeader span:not(.commercialStatus){
  color:#5f7181!important;
  font-size:13px!important;
}
.platformCommercialPage .commercialClientHeader small{
  color:#909aa3!important;
  font-size:11px!important;
}
.platformCommercialPage .commercialStatus{
  min-height:30px!important;
  padding:5px 10px!important;
  border-radius:999px!important;
  font-size:11px!important;
  font-weight:850!important;
}
.platformCommercialPage .commercialClientFacts{
  display:grid!important;
  grid-template-columns:repeat(4,minmax(0,1fr))!important;
  gap:10px!important;
  margin:16px 0!important;
}
.platformCommercialPage .commercialClientFacts>span{
  min-width:0!important;
  min-height:68px!important;
  padding:12px 13px!important;
  border:1px solid #edf1f4!important;
  border-radius:12px!important;
  background:#f8fafb!important;
}
.platformCommercialPage .commercialClientFacts small{
  display:block!important;
  color:#7c8995!important;
  font-size:10px!important;
  font-weight:850!important;
  letter-spacing:.045em!important;
  text-transform:uppercase!important;
}
.platformCommercialPage .commercialClientFacts b{
  display:block!important;
  margin-top:6px!important;
  color:#21384d!important;
  font-size:13px!important;
  line-height:1.3!important;
  overflow-wrap:anywhere!important;
}
.platformCommercialPage .commercialEditClientButton{
  display:flex!important;
  align-items:center!important;
  justify-content:center!important;
  width:190px!important;
  min-height:44px!important;
  margin-left:auto!important;
  padding:0 16px!important;
  border:1px solid #cfd9e1!important;
  border-radius:11px!important;
  background:#f7f9fb!important;
  color:#183149!important;
  font-size:13px!important;
  font-weight:850!important;
  cursor:pointer!important;
}
.platformCommercialPage .commercialEditClientButton:hover,
.platformCommercialPage .commercialClientCard.isEditing .commercialEditClientButton{
  border-color:#102a45!important;
  background:#102a45!important;
  color:#fff!important;
}
.platformCommercialPage .commercialClientEditor{
  margin-top:18px!important;
  padding:22px!important;
  border:1px solid #e4e9ed!important;
  border-radius:15px!important;
  background:#f8fafb!important;
}
.platformCommercialPage .commercialEditorGrid{
  gap:14px!important;
  margin-bottom:14px!important;
}
.platformCommercialPage .commercialClientEditor label,
.platformCommercialPage .planEditorChooser label{
  gap:7px!important;
  color:#506275!important;
  font-size:12px!important;
  font-weight:800!important;
}
.platformCommercialPage .commercialClientEditor input,
.platformCommercialPage .commercialClientEditor select,
.platformCommercialPage .planEditorChooser select{
  min-height:44px!important;
  padding:9px 11px!important;
  border:1px solid #ced8e0!important;
  border-radius:10px!important;
  background:#fff!important;
  color:#152b40!important;
  font-size:13px!important;
}
.platformCommercialPage .commercialDiscountInline{
  gap:14px!important;
  margin:16px 0!important;
  padding:16px!important;
  border-radius:14px!important;
}
.platformCommercialPage .commercialDiscountInline>div strong{
  font-size:14px!important;
}
.platformCommercialPage .commercialDiscountInline>div small{
  font-size:11px!important;
}
.platformCommercialPage .commercialBillingSnapshot{
  margin:15px 0!important;
  padding:16px!important;
  border-radius:14px!important;
}
.platformCommercialPage .commercialBillingSnapshot>strong{
  font-size:13px!important;
}
.platformCommercialPage .commercialBillingSnapshotGrid{
  gap:10px!important;
}
.platformCommercialPage .commercialBillingSnapshotGrid small{
  font-size:9px!important;
}
.platformCommercialPage .commercialBillingSnapshotGrid b{
  margin-top:5px!important;
  font-size:12px!important;
}
.platformCommercialPage .commercialEditorActions .button{
  min-height:44px!important;
  padding:0 18px!important;
  border-radius:10px!important;
  font-size:13px!important;
}
.platformCommercialPage .commercialToolsGrid{
  display:grid!important;
  grid-template-columns:repeat(3,minmax(0,1fr))!important;
  gap:14px!important;
  width:100%!important;
}
.platformCommercialPage .commercialToolCard{
  margin:0!important;
  padding:0!important;
  overflow:hidden!important;
  border:1px solid #dfe5ea!important;
  border-radius:18px!important;
  background:#fff!important;
  box-shadow:0 8px 24px rgba(14,34,53,.045)!important;
}
.platformCommercialPage .commercialToolCard[open]{
  grid-column:1/-1!important;
}
.platformCommercialPage .commercialToolSummary{
  min-height:132px!important;
  padding:20px!important;
  gap:7px!important;
}
.platformCommercialPage .commercialToolSummary:after{
  right:18px!important;
  top:18px!important;
  width:30px!important;
  height:30px!important;
  border-radius:9px!important;
}
.platformCommercialPage .commercialToolSummary>span{
  color:#a47a2d!important;
  font-size:10px!important;
}
.platformCommercialPage .commercialToolSummary>strong{
  color:#10263d!important;
  font-size:17px!important;
}
.platformCommercialPage .commercialToolSummary>small{
  max-width:85%!important;
  color:#778795!important;
  font-size:12px!important;
  line-height:1.4!important;
}
.platformCommercialPage .commercialToolBody{
  padding:0 22px 22px!important;
}
.platformCommercialPage .commercialToolBody label{
  font-size:12px!important;
}
.platformCommercialPage .commercialToolBody input,
.platformCommercialPage .commercialToolBody select{
  min-height:42px!important;
  font-size:13px!important;
}
.platformCommercialPage .commercialPaymentMetrics{
  grid-template-columns:repeat(4,minmax(0,1fr))!important;
  gap:12px!important;
}
.platformCommercialPage .commercialTable th{
  padding:12px!important;
  font-size:10px!important;
}
.platformCommercialPage .commercialTable td{
  padding:12px!important;
  font-size:12px!important;
}
.platformCommercialPage .commercialTable .tableSub{
  font-size:10px!important;
}
@media(max-width:1100px){
  .platformCommercialPage .commercialSummary{grid-template-columns:repeat(2,minmax(0,1fr))!important}
  .platformCommercialPage .commercialClientFacts{grid-template-columns:repeat(2,minmax(0,1fr))!important}
  .platformCommercialPage .commercialToolsGrid{grid-template-columns:1fr!important}
  .platformCommercialPage .commercialToolCard[open]{grid-column:auto!important}
  .platformCommercialPage .commercialMenuGrid{grid-template-columns:repeat(2,minmax(0,1fr))!important}
}
@media(max-width:720px){
  .platformCommercialPage .commercialAdminNav,
  .platformCommercialPage .platformCommercialShell{width:calc(100% - 24px)!important}
  .platformCommercialPage .commercialAdminNav{grid-template-columns:auto 1fr auto!important;gap:10px!important}
  .platformCommercialPage .commercialAdminNav .brand{width:46px!important;min-width:46px!important;height:46px!important}
  .platformCommercialPage .commercialAdminNav .brand img{width:46px!important;max-width:46px!important;max-height:46px!important}
  .platformCommercialPage .commercialHeaderTitle strong{font-size:15px!important}
  .platformCommercialPage .commercialHeaderTitle span{font-size:10px!important}
  .platformCommercialPage .commercialMenuButton{width:44px!important;padding:0!important;font-size:0!important}
  .platformCommercialPage .commercialMenuButton .commercialHamburger{margin:0!important}
  .platformCommercialPage .commercialPageIntro{align-items:flex-start!important;flex-direction:column!important;gap:12px!important}
  .platformCommercialPage .commercialPageIntro h1{font-size:27px!important}
  .platformCommercialPage .commercialPageIntro p{font-size:14px!important}
  .platformCommercialPage .commercialSummary{grid-template-columns:1fr!important}
  .platformCommercialPage .commercialClientsPanel{padding:18px!important;border-radius:17px!important}
  .platformCommercialPage .commercialClientsPanel .adminPanelHeader{flex-direction:column!important}
  .platformCommercialPage .commercialClientsPanel .adminPanelHeader h2{font-size:23px!important}
  .platformCommercialPage .commercialClientCard{padding:16px!important}
  .platformCommercialPage .commercialClientHeader{flex-direction:column!important}
  .platformCommercialPage .commercialClientFacts{grid-template-columns:1fr!important}
  .platformCommercialPage .commercialEditClientButton{width:100%!important;margin:0!important}
  .platformCommercialPage .commercialClientEditor{padding:15px!important}
  .platformCommercialPage .commercialEditorGrid.two,
  .platformCommercialPage .commercialEditorGrid.three,
  .platformCommercialPage .commercialDiscountInline,
  .platformCommercialPage .commercialBillingSnapshotGrid,
  .platformCommercialPage .commercialPaymentMetrics{grid-template-columns:1fr!important}
  .platformCommercialPage .commercialMenuPanel{right:12px!important;width:calc(100vw - 24px)!important}
  .platformCommercialPage .commercialMenuGrid{grid-template-columns:1fr!important}
}
8:X
0:{"buildId":"qrpS0fLieExkswReUL4jb","data":[{"rsc":["$","$1","c",{"children":[["$","$L2",null,{"children":["$","main",null,{"className":"adminPage platformAdminPage platformCommercialPage","children":[["$","style",null,{"dangerouslySetInnerHTML":{"__html":"$3"}}],"$L4","$L5"]}]}],null,"$L6"]}],"isPartial":"$@7","staleTime":"$8","varyParams":null},{"rsc":"$L9","isPartial":"$@a","staleTime":"$8","varyParams":null},{"rsc":"$Lb","isPartial":"$@c","staleTime":"$8","varyParams":null},{"rsc":"$Ld","isPartial":"$@e","staleTime":"$8","varyParams":null}],"isUpgradeableISRFallback":false,"a":"$@f","rootVaryParams":null,"needsRuntimeRequest":"$@10"}
11:I[3631,["2099","static/chunks/9e43655a-f7a66e860f4f65ab.js","6424","static/chunks/6424-d4ec3c90cc423455.js","370","static/chunks/app/plataforma/page-f71c08bb0188572b.js"],"default"]
12:I[4690,["2099","static/chunks/9e43655a-f7a66e860f4f65ab.js","6424","static/chunks/6424-d4ec3c90cc423455.js","370","static/chunks/app/plataforma/page-f71c08bb0188572b.js"],"default"]
13:I[1692,["2099","static/chunks/9e43655a-f7a66e860f4f65ab.js","6424","static/chunks/6424-d4ec3c90cc423455.js","370","static/chunks/app/plataforma/page-f71c08bb0188572b.js"],"default"]
14:I[8930,["2099","static/chunks/9e43655a-f7a66e860f4f65ab.js","6424","static/chunks/6424-d4ec3c90cc423455.js","370","static/chunks/app/plataforma/page-f71c08bb0188572b.js"],"default"]
15:I[6248,["2099","static/chunks/9e43655a-f7a66e860f4f65ab.js","6424","static/chunks/6424-d4ec3c90cc423455.js","370","static/chunks/app/plataforma/page-f71c08bb0188572b.js"],"default"]
16:I[2642,[],"OutletBoundary"]
17:"$Sreact.suspense"
19:I[2642,[],"ViewportBoundary"]
1a:I[2642,[],"MetadataBoundary"]
1b:I[2183,[],"IconMark"]
1c:I[7147,[],""]
1d:I[5815,[],""]
1e:I[7524,["2099","static/chunks/9e43655a-f7a66e860f4f65ab.js","6424","static/chunks/6424-d4ec3c90cc423455.js","7177","static/chunks/app/layout-c8eadddf414f5901.js"],"default"]
1f:I[9297,["2099","static/chunks/9e43655a-f7a66e860f4f65ab.js","6424","static/chunks/6424-d4ec3c90cc423455.js","7177","static/chunks/app/layout-c8eadddf414f5901.js"],"default"]
20:I[6365,["2099","static/chunks/9e43655a-f7a66e860f4f65ab.js","6424","static/chunks/6424-d4ec3c90cc423455.js","7177","static/chunks/app/layout-c8eadddf414f5901.js"],"default"]
21:I[832,["2099","static/chunks/9e43655a-f7a66e860f4f65ab.js","6424","static/chunks/6424-d4ec3c90cc423455.js","7177","static/chunks/app/layout-c8eadddf414f5901.js"],"default"]
22:I[8971,["2099","static/chunks/9e43655a-f7a66e860f4f65ab.js","6424","static/chunks/6424-d4ec3c90cc423455.js","7177","static/chunks/app/layout-c8eadddf414f5901.js"],"default"]
23:I[5986,["2099","static/chunks/9e43655a-f7a66e860f4f65ab.js","6424","static/chunks/6424-d4ec3c90cc423455.js","7177","static/chunks/app/layout-c8eadddf414f5901.js"],"default"]
24:I[2038,["2099","static/chunks/9e43655a-f7a66e860f4f65ab.js","6424","static/chunks/6424-d4ec3c90cc423455.js","7177","static/chunks/app/layout-c8eadddf414f5901.js"],"default"]
25:I[9464,["2099","static/chunks/9e43655a-f7a66e860f4f65ab.js","6424","static/chunks/6424-d4ec3c90cc423455.js","7177","static/chunks/app/layout-c8eadddf414f5901.js"],"default"]
26:I[1129,["2099","static/chunks/9e43655a-f7a66e860f4f65ab.js","6424","static/chunks/6424-d4ec3c90cc423455.js","7177","static/chunks/app/layout-c8eadddf414f5901.js"],"default"]
27:I[8995,["2099","static/chunks/9e43655a-f7a66e860f4f65ab.js","6424","static/chunks/6424-d4ec3c90cc423455.js","7177","static/chunks/app/layout-c8eadddf414f5901.js"],"default"]
28:I[580,["2099","static/chunks/9e43655a-f7a66e860f4f65ab.js","6424","static/chunks/6424-d4ec3c90cc423455.js","7177","static/chunks/app/layout-c8eadddf414f5901.js"],"default"]
29:I[1285,["2099","static/chunks/9e43655a-f7a66e860f4f65ab.js","6424","static/chunks/6424-d4ec3c90cc423455.js","7177","static/chunks/app/layout-c8eadddf414f5901.js"],"default"]
2a:I[5335,["2099","static/chunks/9e43655a-f7a66e860f4f65ab.js","6424","static/chunks/6424-d4ec3c90cc423455.js","7177","static/chunks/app/layout-c8eadddf414f5901.js"],"default"]
2b:I[2784,["2099","static/chunks/9e43655a-f7a66e860f4f65ab.js","6424","static/chunks/6424-d4ec3c90cc423455.js","7177","static/chunks/app/layout-c8eadddf414f5901.js"],"default"]
2c:I[1242,["2099","static/chunks/9e43655a-f7a66e860f4f65ab.js","6424","static/chunks/6424-d4ec3c90cc423455.js","7177","static/chunks/app/layout-c8eadddf414f5901.js"],"default"]
2d:I[1887,["2099","static/chunks/9e43655a-f7a66e860f4f65ab.js","6424","static/chunks/6424-d4ec3c90cc423455.js","7177","static/chunks/app/layout-c8eadddf414f5901.js"],"default"]
2e:I[2293,["2099","static/chunks/9e43655a-f7a66e860f4f65ab.js","6424","static/chunks/6424-d4ec3c90cc423455.js","7177","static/chunks/app/layout-c8eadddf414f5901.js"],"default"]
2f:I[3780,["2099","static/chunks/9e43655a-f7a66e860f4f65ab.js","6424","static/chunks/6424-d4ec3c90cc423455.js","7177","static/chunks/app/layout-c8eadddf414f5901.js"],"default"]
30:I[620,["2099","static/chunks/9e43655a-f7a66e860f4f65ab.js","6424","static/chunks/6424-d4ec3c90cc423455.js","7177","static/chunks/app/layout-c8eadddf414f5901.js"],"default"]
31:I[2924,["2099","static/chunks/9e43655a-f7a66e860f4f65ab.js","6424","static/chunks/6424-d4ec3c90cc423455.js","7177","static/chunks/app/layout-c8eadddf414f5901.js"],"default"]
32:I[248,["2099","static/chunks/9e43655a-f7a66e860f4f65ab.js","6424","static/chunks/6424-d4ec3c90cc423455.js","7177","static/chunks/app/layout-c8eadddf414f5901.js"],"default"]
33:I[1039,["2099","static/chunks/9e43655a-f7a66e860f4f65ab.js","6424","static/chunks/6424-d4ec3c90cc423455.js","7177","static/chunks/app/layout-c8eadddf414f5901.js"],"default"]
34:I[2376,["2099","static/chunks/9e43655a-f7a66e860f4f65ab.js","6424","static/chunks/6424-d4ec3c90cc423455.js","7177","static/chunks/app/layout-c8eadddf414f5901.js"],"default"]
:HL["https://lenoy.com.br/wp-content/uploads/2026/08/hh.png","image"]
:HL["/_next/static/css/3a3177d525086632.css","style"]
:HL["/_next/static/css/2583ac8338333e88.css","style"]
:HL["/_next/static/css/3e1cffbc5183d123.css","style"]
:HL["/_next/static/css/f5c66b7ad61822d5.css","style"]
4:["$","header",null,{"className":"adminTopbar commercialTopbar","children":["$","div",null,{"className":"container adminNav commercialAdminNav","children":[["$","a",null,{"className":"brand","href":"../","children":["$","img",null,{"src":"https://lenoy.com.br/wp-content/uploads/2026/08/hh.png","alt":"LENOY IMOBILIÁRIAS"}]}],["$","div",null,{"className":"commercialHeaderTitle","children":[["$","strong",null,{"children":"Administração LENOY"}],["$","span",null,{"children":"Clientes, assinaturas e financeiro"}]]}],["$","$L11",null,{}]]}]}]
5:["$","div",null,{"className":"container platformAdminShell platformCommercialShell","children":["$","section",null,{"className":"adminContent commercialAdminContent","children":[["$","section",null,{"className":"commercialPageIntro","aria-label":"Visão geral da administração","children":[["$","div",null,{"className":"commercialPageIntroCopy","children":[["$","span",null,{"className":"eyebrow","children":"CENTRAL ADMINISTRATIVA"}],["$","h1",null,{"children":"Gestão da plataforma"}],["$","p",null,{"children":"Clientes, acessos, planos e cobranças em uma visão mais clara, com informações maiores e ações fáceis de localizar."}]]}],["$","span",null,{"className":"commercialPageIntroBadge","children":"Sistema operacional"}]]}],["$","$L12",null,{}],["$","section",null,{"className":"commercialToolsGrid","aria-label":"Ferramentas comerciais","children":[["$","$L13",null,{}],["$","$L14",null,{}],["$","$L15",null,{}]]}]]}]}]
6:["$","$L16",null,{"children":["$","$17",null,{"name":"Next.MetadataOutlet","children":"$@18"}]}]
9:["$","$1","h",{"children":[null,["$","$L19",null,{"children":[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]}],["$","div",null,{"hidden":true,"children":["$","$L1a",null,{"children":["$","$17",null,{"name":"Next.Metadata","children":[["$","title","0",{"children":"LENOY IMOBILIÁRIAS | Plataforma para imobiliárias"}],["$","meta","1",{"name":"description","content":"Plataforma SaaS para imobiliárias com site próprio, catálogo de imóveis, corretores, leads, domínio personalizado e recursos de inteligência artificial."}],["$","meta","2",{"name":"keywords","content":"imobiliária,site para imobiliária,sistema imobiliário,imóveis,corretores,leads,SaaS imobiliário"}],["$","meta","3",{"name":"robots","content":"index, follow"}],["$","link","4",{"rel":"canonical","href":"https://imoveis.lenoy.com.br"}],["$","meta","5",{"property":"og:title","content":"LENOY IMOBILIÁRIAS"}],["$","meta","6",{"property":"og:description","content":"Plataforma completa para imobiliárias criarem seu site, publicarem imóveis e gerenciarem equipe e contatos."}],["$","meta","7",{"property":"og:url","content":"https://imoveis.lenoy.com.br"}],["$","meta","8",{"property":"og:locale","content":"pt_BR"}],["$","meta","9",{"property":"og:image","content":"https://lenoy.com.br/wp-content/uploads/2026/08/hh.png"}],["$","meta","10",{"property":"og:image:width","content":"512"}],["$","meta","11",{"property":"og:image:height","content":"512"}],["$","meta","12",{"property":"og:image:alt","content":"LENOY IMOBILIÁRIAS"}],["$","meta","13",{"property":"og:type","content":"website"}],["$","meta","14",{"name":"twitter:card","content":"summary_large_image"}],["$","meta","15",{"name":"twitter:title","content":"LENOY IMOBILIÁRIAS"}],["$","meta","16",{"name":"twitter:description","content":"Plataforma completa para imobiliárias criarem seu site, publicarem imóveis e gerenciarem equipe e contatos."}],["$","meta","17",{"name":"twitter:image","content":"https://lenoy.com.br/wp-content/uploads/2026/08/hh.png"}],["$","meta","18",{"name":"twitter:image:alt","content":"LENOY IMOBILIÁRIAS"}],["$","meta","19",{"name":"twitter:image:width","content":"512"}],["$","meta","20",{"name":"twitter:image:height","content":"512"}],["$","link","21",{"rel":"shortcut icon","href":"https://lenoy.com.br/wp-content/uploads/2026/08/hh.png","type":"image/png"}],["$","link","22",{"rel":"icon","href":"https://lenoy.com.br/wp-content/uploads/2026/08/hh.png","type":"image/png"}],["$","link","23",{"rel":"apple-touch-icon","href":"https://lenoy.com.br/wp-content/uploads/2026/08/hh.png"}],["$","$L1b","24",{}]]}]}]}],null]}]
b:["$","$1","c",{"children":[null,[["$","$L1c",null,{"parallelRouterKey":"children","template":["$","$L1d",null,{}]}],["$","style",null,{"dangerouslySetInnerHTML":{"__html":"\n@media (min-width: 1101px) {\n  .platformCommercialPage .commercialClientGrid {\n    grid-template-columns: repeat(2, minmax(0, 1fr)) !important;\n  }\n\n  .platformCommercialPage .commercialClientCard.isEditing {\n    grid-column: 1 / -1 !important;\n  }\n}\n\n@media (max-width: 1100px) {\n  .platformCommercialPage .commercialClientGrid {\n    grid-template-columns: 1fr !important;\n  }\n\n  .platformCommercialPage .commercialClientCard.isEditing {\n    grid-column: auto !important;\n  }\n}\n"}}]]]}]
d:["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/css/3a3177d525086632.css","precedence":"next"}],["$","link","1",{"rel":"stylesheet","href":"/_next/static/css/2583ac8338333e88.css","precedence":"next"}],["$","link","2",{"rel":"stylesheet","href":"/_next/static/css/3e1cffbc5183d123.css","precedence":"next"}],["$","link","3",{"rel":"stylesheet","href":"/_next/static/css/f5c66b7ad61822d5.css","precedence":"next"}]],["$","html",null,{"lang":"pt-BR","children":["$","body",null,{"children":[["$","style",null,{"dangerouslySetInnerHTML":{"__html":"\n:root{\n  --lenoy-approved-platform-hero:url(\"https://lenoy.com.br/wp-content/uploads/2026/08/banner-imobi.jpg?v=20260830-hd-direct\");\n}\n@media (min-width:701px){\n  html body .platformLanding.platformLanding.platformLanding .platformHero.platformHero.platformHero{\n    background-color:#061322 !important;\n    background-image:var(--lenoy-approved-platform-hero) !important;\n    background-repeat:no-repeat !important;\n    background-position:center center !important;\n    background-size:cover !important;\n  }\n  html body .platformLanding.platformLanding.platformLanding .platformHero.platformHero.platformHero::before,\n  html body .platformLanding.platformLanding.platformLanding .platformHero.platformHero.platformHero::after{\n    content:none !important;\n    display:none !important;\n  }\n}\n@media (min-width:1100px){\n  html body .platformLanding.platformLanding.platformLanding .platformHero.platformHero.platformHero{\n    background-position:center center !important;\n    background-size:cover !important;\n  }\n}"}}],["$","$L1c",null,{"parallelRouterKey":"children","template":["$","$L1d",null,{}],"notFound":[[["$","title",null,{"children":"404: This page could not be found."}],["$","div",null,{"style":{"fontFamily":"system-ui,\"Segoe UI\",Roboto,Helvetica,Arial,sans-serif,\"Apple Color Emoji\",\"Segoe UI Emoji\"","height":"100vh","textAlign":"center","display":"flex","flexDirection":"column","alignItems":"center","justifyContent":"center"},"children":["$","div",null,{"children":[["$","style",null,{"dangerouslySetInnerHTML":{"__html":"body{color:#000;background:#fff;margin:0}.next-error-h1{border-right:1px solid rgba(0,0,0,.3)}@media (prefers-color-scheme:dark){body{color:#fff;background:#000}.next-error-h1{border-right:1px solid rgba(255,255,255,.3)}}"}}],["$","h1",null,{"className":"next-error-h1","style":{"display":"inline-block","margin":"0 20px 0 0","padding":"0 23px 0 0","fontSize":24,"fontWeight":500,"verticalAlign":"top","lineHeight":"49px"},"children":404}],["$","div",null,{"style":{"display":"inline-block"},"children":["$","h2",null,{"style":{"fontSize":14,"fontWeight":400,"lineHeight":"49px","margin":0},"children":"This page could not be found."}]}]]}]}]],[]]}],["$","$L1e",null,{}],["$","$L1f",null,{}],["$","$L20",null,{}],["$","$L21",null,{}],["$","$L22",null,{}],["$","$L23",null,{}],["$","$L24",null,{}],["$","$L25",null,{}],["$","$L26",null,{}],["$","$L27",null,{}],["$","$L28",null,{}],["$","$L29",null,{}],["$","$L2a",null,{}],["$","$L2b",null,{}],["$","$L2c",null,{}],["$","$L2d",null,{}],["$","$L2e",null,{}],["$","$L2f",null,{}],["$","$L30",null,{}],["$","$L31",null,{}],["$","$L32",null,{}],["$","$L33",null,{}],["$","$L34",null,{}]]}]}]]}]
18:null
10:true
8:300
8:C
f:0
a:"$undefined"
c:"$undefined"
e:"$undefined"
7:"$undefined"
