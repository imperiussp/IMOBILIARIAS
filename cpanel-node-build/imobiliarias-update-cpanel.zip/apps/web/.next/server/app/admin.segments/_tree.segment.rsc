:HL["/_next/static/css/d61a10ebe8f22b3d.css","style"]
:HL["/_next/static/css/2b2c6612b55d0e37.css","style"]
:HL["/_next/static/css/d926ff7c08b8d745.css","style"]
:HL["/lenoy-imobiliarias-logo-20260826.png","image"]
0:{"tree":{"name":"","param":null,"prefetchHints":4112,"slots":{"children":{"name":"admin","param":null,"prefetchHints":4160,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":4256,"slots":null}}}}},"staleTime":300,"buildId":"k8n8Q2FR3AEscY-B08fuD"}
