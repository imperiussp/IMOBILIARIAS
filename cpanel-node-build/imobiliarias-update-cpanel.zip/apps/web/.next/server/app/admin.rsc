1:"$Sreact.fragment"
2:I[87147,[],""]
3:I[45815,[],""]
4:I[63075,["2099","static/chunks/9e43655a-b2fa3409b88f33d1.js","6424","static/chunks/6424-d1b373fb508f5573.js","7177","static/chunks/app/layout-cfaf2956bcf07422.js"],"default"]
5:I[87524,["2099","static/chunks/9e43655a-b2fa3409b88f33d1.js","6424","static/chunks/6424-d1b373fb508f5573.js","7177","static/chunks/app/layout-cfaf2956bcf07422.js"],"default"]
6:I[19297,["2099","static/chunks/9e43655a-b2fa3409b88f33d1.js","6424","static/chunks/6424-d1b373fb508f5573.js","7177","static/chunks/app/layout-cfaf2956bcf07422.js"],"default"]
7:I[76365,["2099","static/chunks/9e43655a-b2fa3409b88f33d1.js","6424","static/chunks/6424-d1b373fb508f5573.js","7177","static/chunks/app/layout-cfaf2956bcf07422.js"],"default"]
8:I[832,["2099","static/chunks/9e43655a-b2fa3409b88f33d1.js","6424","static/chunks/6424-d1b373fb508f5573.js","7177","static/chunks/app/layout-cfaf2956bcf07422.js"],"default"]
9:I[48971,["2099","static/chunks/9e43655a-b2fa3409b88f33d1.js","6424","static/chunks/6424-d1b373fb508f5573.js","7177","static/chunks/app/layout-cfaf2956bcf07422.js"],"default"]
a:I[65986,["2099","static/chunks/9e43655a-b2fa3409b88f33d1.js","6424","static/chunks/6424-d1b373fb508f5573.js","7177","static/chunks/app/layout-cfaf2956bcf07422.js"],"default"]
b:I[42038,["2099","static/chunks/9e43655a-b2fa3409b88f33d1.js","6424","static/chunks/6424-d1b373fb508f5573.js","7177","static/chunks/app/layout-cfaf2956bcf07422.js"],"default"]
c:I[69464,["2099","static/chunks/9e43655a-b2fa3409b88f33d1.js","6424","static/chunks/6424-d1b373fb508f5573.js","7177","static/chunks/app/layout-cfaf2956bcf07422.js"],"default"]
d:I[93510,["2099","static/chunks/9e43655a-b2fa3409b88f33d1.js","6424","static/chunks/6424-d1b373fb508f5573.js","7177","static/chunks/app/layout-cfaf2956bcf07422.js"],"default"]
e:I[98995,["2099","static/chunks/9e43655a-b2fa3409b88f33d1.js","6424","static/chunks/6424-d1b373fb508f5573.js","7177","static/chunks/app/layout-cfaf2956bcf07422.js"],"default"]
f:I[40580,["2099","static/chunks/9e43655a-b2fa3409b88f33d1.js","6424","static/chunks/6424-d1b373fb508f5573.js","7177","static/chunks/app/layout-cfaf2956bcf07422.js"],"default"]
10:I[21285,["2099","static/chunks/9e43655a-b2fa3409b88f33d1.js","6424","static/chunks/6424-d1b373fb508f5573.js","7177","static/chunks/app/layout-cfaf2956bcf07422.js"],"default"]
11:I[15335,["2099","static/chunks/9e43655a-b2fa3409b88f33d1.js","6424","static/chunks/6424-d1b373fb508f5573.js","7177","static/chunks/app/layout-cfaf2956bcf07422.js"],"default"]
12:I[72784,["2099","static/chunks/9e43655a-b2fa3409b88f33d1.js","6424","static/chunks/6424-d1b373fb508f5573.js","7177","static/chunks/app/layout-cfaf2956bcf07422.js"],"default"]
13:I[41242,["2099","static/chunks/9e43655a-b2fa3409b88f33d1.js","6424","static/chunks/6424-d1b373fb508f5573.js","7177","static/chunks/app/layout-cfaf2956bcf07422.js"],"default"]
14:I[31887,["2099","static/chunks/9e43655a-b2fa3409b88f33d1.js","6424","static/chunks/6424-d1b373fb508f5573.js","7177","static/chunks/app/layout-cfaf2956bcf07422.js"],"default"]
15:I[22293,["2099","static/chunks/9e43655a-b2fa3409b88f33d1.js","6424","static/chunks/6424-d1b373fb508f5573.js","7177","static/chunks/app/layout-cfaf2956bcf07422.js"],"default"]
16:I[3780,["2099","static/chunks/9e43655a-b2fa3409b88f33d1.js","6424","static/chunks/6424-d1b373fb508f5573.js","7177","static/chunks/app/layout-cfaf2956bcf07422.js"],"default"]
17:I[50620,["2099","static/chunks/9e43655a-b2fa3409b88f33d1.js","6424","static/chunks/6424-d1b373fb508f5573.js","7177","static/chunks/app/layout-cfaf2956bcf07422.js"],"default"]
18:I[12924,["2099","static/chunks/9e43655a-b2fa3409b88f33d1.js","6424","static/chunks/6424-d1b373fb508f5573.js","7177","static/chunks/app/layout-cfaf2956bcf07422.js"],"default"]
19:I[80248,["2099","static/chunks/9e43655a-b2fa3409b88f33d1.js","6424","static/chunks/6424-d1b373fb508f5573.js","7177","static/chunks/app/layout-cfaf2956bcf07422.js"],"default"]
1a:I[91039,["2099","static/chunks/9e43655a-b2fa3409b88f33d1.js","6424","static/chunks/6424-d1b373fb508f5573.js","7177","static/chunks/app/layout-cfaf2956bcf07422.js"],"default"]
1b:I[72376,["2099","static/chunks/9e43655a-b2fa3409b88f33d1.js","6424","static/chunks/6424-d1b373fb508f5573.js","7177","static/chunks/app/layout-cfaf2956bcf07422.js"],"default"]
1c:I[58184,["2099","static/chunks/9e43655a-b2fa3409b88f33d1.js","6424","static/chunks/6424-d1b373fb508f5573.js","7111","static/chunks/7111-03fe5f752cc66088.js","3698","static/chunks/app/admin/page-dc7c128f441a2ded.js"],"default"]
23:I[13457,[],"default",1]
:HL["/_next/static/css/3a3177d525086632.css","style"]
:HL["/_next/static/css/2583ac8338333e88.css","style"]
:HL["/_next/static/css/3e1cffbc5183d123.css","style"]
:HL["/_next/static/css/f5c66b7ad61822d5.css","style"]
1d:T2a51,
  .adminPage.adminWorkspaceRefresh {
    --workspace-navy: #071725;
    --workspace-navy-2: #0b2237;
    --workspace-gold: #e9b94f;
    --workspace-text: #132238;
    --workspace-muted: #66758a;
    --workspace-line: #e5eaf0;
    --workspace-surface: #ffffff;
    --workspace-bg: #f4f7fb;
    min-height: 100vh;
    background: var(--workspace-bg);
    color: var(--workspace-text);
  }

  .adminPage.adminWorkspaceRefresh .adminTopbar {
    position: sticky;
    top: 0;
    z-index: 80;
    border-bottom: 1px solid rgba(255,255,255,.08);
    background: rgba(7,23,37,.97);
    box-shadow: 0 10px 30px rgba(4,18,34,.08);
    backdrop-filter: blur(16px);
  }

  .adminPage.adminWorkspaceRefresh .adminNav {
    min-height: 72px;
  }

  .adminPage.adminWorkspaceRefresh .adminShell {
    display: grid;
    grid-template-columns: 228px minmax(0,1fr);
    gap: 28px;
    align-items: start;
    padding-top: 28px;
    padding-bottom: 70px;
  }

  .adminPage.adminWorkspaceRefresh .adminSidebar.adminSidebarCompact {
    position: sticky;
    top: 98px;
    display: flex;
    flex-direction: column;
    gap: 5px;
    padding: 18px 14px;
    border: 0;
    border-radius: 20px;
    background: linear-gradient(180deg, #071725 0%, #0b2237 100%);
    box-shadow: 0 18px 42px rgba(7,23,37,.16);
  }

  .adminPage.adminWorkspaceRefresh .adminSidebar strong {
    padding: 4px 10px 12px;
    color: rgba(255,255,255,.54);
    font-size: 11px;
    letter-spacing: .14em;
    text-transform: uppercase;
  }

  .adminPage.adminWorkspaceRefresh .adminSidebar a {
    display: flex;
    align-items: center;
    gap: 9px;
    min-height: 42px;
    padding: 0 11px;
    border: 1px solid transparent;
    border-radius: 11px;
    color: rgba(255,255,255,.76);
    font-size: 13px;
    font-weight: 700;
    text-decoration: none;
    transition: background .16s ease, color .16s ease, border-color .16s ease, transform .16s ease;
  }

  .adminPage.adminWorkspaceRefresh .adminSidebar a:hover,
  .adminPage.adminWorkspaceRefresh .adminSidebar a.active {
    border-color: rgba(233,185,79,.18);
    background: rgba(233,185,79,.11);
    color: #fff;
    transform: translateX(2px);
  }

  .adminPage.adminWorkspaceRefresh .adminContent {
    min-width: 0;
  }

  .adminPage.adminWorkspaceRefresh .adminHeading {
    gap: 22px;
    margin-bottom: 22px;
    padding: 30px 32px;
    border: 1px solid #dfe6ee;
    border-radius: 22px;
    background:
      radial-gradient(circle at 92% 18%, rgba(233,185,79,.14), transparent 30%),
      linear-gradient(135deg, #ffffff 0%, #f9fbfd 100%);
    box-shadow: 0 14px 34px rgba(27,44,64,.07);
  }

  .adminPage.adminWorkspaceRefresh .adminHeading h1 {
    margin: 5px 0 8px;
    color: var(--workspace-navy);
    font-size: clamp(28px, 3vw, 40px);
    line-height: 1.03;
    letter-spacing: -.035em;
  }

  .adminPage.adminWorkspaceRefresh .adminHeading p {
    max-width: 720px;
    margin: 0;
    color: var(--workspace-muted);
    line-height: 1.55;
  }

  .adminPage.adminWorkspaceRefresh .adminQuickActions {
    display: flex;
    flex-wrap: wrap;
    gap: 9px;
    margin: -4px 0 24px;
  }

  .adminPage.adminWorkspaceRefresh .adminQuickActions a {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    min-height: 40px;
    padding: 0 14px;
    border: 1px solid #dce3eb;
    border-radius: 11px;
    background: #fff;
    color: #203249;
    font-size: 13px;
    font-weight: 800;
    text-decoration: none;
    box-shadow: 0 5px 15px rgba(27,44,64,.04);
  }

  .adminPage.adminWorkspaceRefresh .adminQuickActions a:first-child {
    border-color: #e2b247;
    background: #efc45f;
    color: #071725;
  }

  .adminPage.adminWorkspaceRefresh .adminMetrics {
    gap: 14px;
    margin-bottom: 24px;
  }

  .adminPage.adminWorkspaceRefresh .adminMetrics article {
    min-width: 0;
    border: 1px solid #e1e7ee;
    border-radius: 17px;
    background: #fff;
    box-shadow: 0 8px 24px rgba(27,44,64,.055);
  }

  .adminPage.adminWorkspaceRefresh .adminModulesSection {
    margin: 28px 0 34px;
  }

  .adminPage.adminWorkspaceRefresh .adminModulesHeading {
    align-items: end;
    margin-bottom: 16px;
  }

  .adminPage.adminWorkspaceRefresh .adminModulesHeading h2 {
    margin-bottom: 2px;
    color: var(--workspace-navy);
  }

  .adminPage.adminWorkspaceRefresh .adminAccessGroups {
    display: grid;
    gap: 18px;
  }

  .adminPage.adminWorkspaceRefresh .adminAccessGroup {
    scroll-margin-top: 96px;
    padding: 22px;
    border: 1px solid #e1e7ee;
    border-radius: 20px;
    background: rgba(255,255,255,.92);
    box-shadow: 0 10px 28px rgba(27,44,64,.045);
  }

  .adminPage.adminWorkspaceRefresh .adminAccessGroupHeader {
    display: flex;
    align-items: flex-start;
    justify-content: space-between;
    gap: 16px;
    margin-bottom: 15px;
  }

  .adminPage.adminWorkspaceRefresh .adminAccessGroupHeader h3 {
    margin: 0 0 4px;
    color: var(--workspace-navy);
    font-size: 17px;
  }

  .adminPage.adminWorkspaceRefresh .adminAccessGroupHeader p {
    margin: 0;
    color: var(--workspace-muted);
    font-size: 13px;
  }

  .adminPage.adminWorkspaceRefresh .adminAccessGroupTag {
    flex: 0 0 auto;
    padding: 6px 9px;
    border-radius: 999px;
    background: #f4f7fa;
    color: #758398;
    font-size: 10px;
    font-weight: 900;
    letter-spacing: .08em;
    text-transform: uppercase;
  }

  .adminPage.adminWorkspaceRefresh .adminModuleGrid {
    display: grid;
    grid-template-columns: repeat(3, minmax(0,1fr));
    gap: 10px;
  }

  .adminPage.adminWorkspaceRefresh .adminModuleCard {
    position: relative;
    display: grid;
    grid-template-columns: 42px minmax(0,1fr) 22px;
    align-items: center;
    gap: 12px;
    min-width: 0;
    min-height: 84px;
    padding: 13px 13px;
    border: 1px solid #e4e9ef;
    border-radius: 15px;
    background: #fff;
    color: var(--workspace-text);
    text-decoration: none;
    box-shadow: none;
    transition: transform .16s ease, border-color .16s ease, box-shadow .16s ease;
  }

  .adminPage.adminWorkspaceRefresh .adminModuleCard:hover {
    transform: translateY(-2px);
    border-color: rgba(203,151,41,.42);
    box-shadow: 0 12px 24px rgba(27,44,64,.08);
  }

  .adminPage.adminWorkspaceRefresh .adminModuleIcon {
    width: 42px;
    height: 42px;
    display: grid;
    place-items: center;
    border-radius: 12px;
    background: #f5f7fa;
    color: #956c12;
    font-size: 18px;
    font-weight: 900;
  }

  .adminPage.adminWorkspaceRefresh .adminModuleCopy {
    min-width: 0;
  }

  .adminPage.adminWorkspaceRefresh .adminModuleCopy strong {
    display: block;
    overflow: hidden;
    color: #18283d;
    font-size: 13px;
    line-height: 1.25;
    text-overflow: ellipsis;
  }

  .adminPage.adminWorkspaceRefresh .adminModuleCopy small {
    display: block;
    margin-top: 4px;
    overflow: hidden;
    color: #7a8798;
    font-size: 11px;
    line-height: 1.25;
    text-overflow: ellipsis;
  }

  .adminPage.adminWorkspaceRefresh .adminModuleArrow {
    color: #9aa5b4;
    font-size: 15px;
    transition: transform .16s ease, color .16s ease;
  }

  .adminPage.adminWorkspaceRefresh .adminModuleCard:hover .adminModuleArrow {
    transform: translateX(2px);
    color: #956c12;
  }

  .adminPage.adminWorkspaceRefresh .adminPanel {
    scroll-margin-top: 96px;
    border: 1px solid #e1e7ee;
    border-radius: 19px;
    background: #fff;
    box-shadow: 0 8px 24px rgba(27,44,64,.045);
  }

  .adminPage.adminWorkspaceRefresh .adminPanel + .adminPanel {
    margin-top: 18px;
  }

  .adminPage.adminWorkspaceRefresh .adminPanelHeader h2 {
    color: var(--workspace-navy);
  }

  .adminPage.adminWorkspaceRefresh .adminTableWrap {
    border-color: #e5eaf0;
    border-radius: 14px;
  }

  @media (max-width: 1180px) {
    .adminPage.adminWorkspaceRefresh .adminModuleGrid {
      grid-template-columns: repeat(2, minmax(0,1fr));
    }
  }

  @media (max-width: 980px) {
    .adminPage.adminWorkspaceRefresh .adminShell {
      grid-template-columns: 1fr;
      gap: 16px;
      padding-top: 18px;
    }
    .adminPage.adminWorkspaceRefresh .adminSidebar.adminSidebarCompact {
      position: sticky;
      top: 76px;
      z-index: 45;
      flex-direction: row;
      gap: 5px;
      padding: 9px;
      overflow-x: auto;
      border-radius: 14px;
      scrollbar-width: none;
    }
    .adminPage.adminWorkspaceRefresh .adminSidebar::-webkit-scrollbar { display: none; }
    .adminPage.adminWorkspaceRefresh .adminSidebar strong { display: none; }
    .adminPage.adminWorkspaceRefresh .adminSidebar a {
      flex: 0 0 auto;
      min-height: 38px;
      white-space: nowrap;
    }
    .adminPage.adminWorkspaceRefresh .adminSidebar a:hover,
    .adminPage.adminWorkspaceRefresh .adminSidebar a.active { transform: none; }
  }

  @media (max-width: 700px) {
    .adminPage.adminWorkspaceRefresh .adminHeading {
      padding: 22px 18px;
      border-radius: 18px;
    }
    .adminPage.adminWorkspaceRefresh .adminHeadingActions {
      width: 100%;
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 8px;
    }
    .adminPage.adminWorkspaceRefresh .adminHeadingActions .button {
      width: 100%;
      justify-content: center;
    }
    .adminPage.adminWorkspaceRefresh .adminQuickActions {
      display: grid;
      grid-template-columns: 1fr 1fr;
    }
    .adminPage.adminWorkspaceRefresh .adminQuickActions a {
      justify-content: center;
      padding: 0 10px;
      font-size: 12px;
    }
    .adminPage.adminWorkspaceRefresh .adminAccessGroup {
      padding: 16px 12px;
      border-radius: 16px;
    }
    .adminPage.adminWorkspaceRefresh .adminAccessGroupHeader {
      align-items: flex-start;
    }
    .adminPage.adminWorkspaceRefresh .adminAccessGroupTag { display: none; }
    .adminPage.adminWorkspaceRefresh .adminModuleGrid {
      grid-template-columns: 1fr 1fr;
      gap: 8px;
    }
    .adminPage.adminWorkspaceRefresh .adminModuleCard {
      grid-template-columns: 36px minmax(0,1fr);
      gap: 9px;
      min-height: 78px;
      padding: 10px;
      border-radius: 13px;
    }
    .adminPage.adminWorkspaceRefresh .adminModuleIcon {
      width: 36px;
      height: 36px;
      border-radius: 10px;
      font-size: 16px;
    }
    .adminPage.adminWorkspaceRefresh .adminModuleArrow { display: none; }
    .adminPage.adminWorkspaceRefresh .adminModuleCopy strong {
      white-space: normal;
      font-size: 12px;
    }
    .adminPage.adminWorkspaceRefresh .adminModuleCopy small {
      display: none;
    }
  }

  @media (max-width: 420px) {
    .adminPage.adminWorkspaceRefresh .adminQuickActions { grid-template-columns: 1fr; }
    .adminPage.adminWorkspaceRefresh .adminModuleGrid { grid-template-columns: 1fr; }
    .adminPage.adminWorkspaceRefresh .adminModuleCopy small { display: block; }
  }
21:X
0:{"P":null,"c":["","admin"],"q":"","i":false,"f":[[["",{"children":["admin",{"children":["__PAGE__",{},"$undefined","$undefined",4608]},"$undefined","$undefined",4608]},"$undefined","$undefined",4624],[["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/css/3a3177d525086632.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}],["$","link","1",{"rel":"stylesheet","href":"/_next/static/css/2583ac8338333e88.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}],["$","link","2",{"rel":"stylesheet","href":"/_next/static/css/3e1cffbc5183d123.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}],["$","link","3",{"rel":"stylesheet","href":"/_next/static/css/f5c66b7ad61822d5.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}]],["$","html",null,{"lang":"pt-BR","children":["$","body",null,{"children":[["$","style",null,{"dangerouslySetInnerHTML":{"__html":"\n:root{\n  --lenoy-approved-platform-hero:url(\"https://lenoy.com.br/wp-content/uploads/2026/08/banner-imobi.jpg?v=20260830-hd-direct\");\n}\n@media (min-width:701px){\n  html body .platformLanding.platformLanding.platformLanding .platformHero.platformHero.platformHero{\n    background-color:#061322 !important;\n    background-image:var(--lenoy-approved-platform-hero) !important;\n    background-repeat:no-repeat !important;\n    background-position:center center !important;\n    background-size:cover !important;\n  }\n  html body .platformLanding.platformLanding.platformLanding .platformHero.platformHero.platformHero::before,\n  html body .platformLanding.platformLanding.platformLanding .platformHero.platformHero.platformHero::after{\n    content:none !important;\n    display:none !important;\n  }\n}\n@media (min-width:1100px){\n  html body .platformLanding.platformLanding.platformLanding .platformHero.platformHero.platformHero{\n    background-position:center center !important;\n    background-size:cover !important;\n  }\n}"}}],["$","$L2",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L3",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":[[["$","title",null,{"children":"404: This page could not be found."}],["$","div",null,{"style":{"fontFamily":"system-ui,\"Segoe UI\",Roboto,Helvetica,Arial,sans-serif,\"Apple Color Emoji\",\"Segoe UI Emoji\"","height":"100vh","textAlign":"center","display":"flex","flexDirection":"column","alignItems":"center","justifyContent":"center"},"children":["$","div",null,{"children":[["$","style",null,{"dangerouslySetInnerHTML":{"__html":"body{color:#000;background:#fff;margin:0}.next-error-h1{border-right:1px solid rgba(0,0,0,.3)}@media (prefers-color-scheme:dark){body{color:#fff;background:#000}.next-error-h1{border-right:1px solid rgba(255,255,255,.3)}}"}}],["$","h1",null,{"className":"next-error-h1","style":{"display":"inline-block","margin":"0 20px 0 0","padding":"0 23px 0 0","fontSize":24,"fontWeight":500,"verticalAlign":"top","lineHeight":"49px"},"children":404}],["$","div",null,{"style":{"display":"inline-block"},"children":["$","h2",null,{"style":{"fontSize":14,"fontWeight":400,"lineHeight":"49px","margin":0},"children":"This page could not be found."}]}]]}]}]],[]],"forbidden":"$undefined","unauthorized":"$undefined"}],["$","$L4",null,{}],["$","$L5",null,{}],["$","$L6",null,{}],["$","$L7",null,{}],["$","$L8",null,{}],["$","$L9",null,{}],["$","$La",null,{}],["$","$Lb",null,{}],["$","$Lc",null,{}],["$","$Ld",null,{}],["$","$Le",null,{}],["$","$Lf",null,{}],["$","$L10",null,{}],["$","$L11",null,{}],["$","$L12",null,{}],["$","$L13",null,{}],["$","$L14",null,{}],["$","$L15",null,{}],["$","$L16",null,{}],["$","$L17",null,{}],["$","$L18",null,{}],["$","$L19",null,{}],["$","$L1a",null,{}],["$","$L1b",null,{}]]}]}]]}],{"children":[["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L3",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":"$undefined","forbidden":"$undefined","unauthorized":"$undefined"}]]}],{"children":[["$","$1","c",{"children":[["$","$L1c",null,{"children":["$","main",null,{"className":"adminPage adminWorkspaceRefresh","children":[["$","style",null,{"dangerouslySetInnerHTML":{"__html":"$1d"}}],"$L1e","$L1f"]}]}],null,"$L20"]}],{},null,false,null]},null,false,"$21"]},null,false,null],"$L22",false]],"m":"$undefined","G":["$23",[]],"S":true,"h":null,"r":"$undefined","s":"$undefined","a":"$undefined","l":"$undefined","p":"$undefined","d":"$undefined","b":"aZqENKDy75oMrA6KMJNpo"}
24:I[16940,["2099","static/chunks/9e43655a-b2fa3409b88f33d1.js","6424","static/chunks/6424-d1b373fb508f5573.js","7111","static/chunks/7111-03fe5f752cc66088.js","3698","static/chunks/app/admin/page-dc7c128f441a2ded.js"],"default"]
25:I[64883,["2099","static/chunks/9e43655a-b2fa3409b88f33d1.js","6424","static/chunks/6424-d1b373fb508f5573.js","7111","static/chunks/7111-03fe5f752cc66088.js","3698","static/chunks/app/admin/page-dc7c128f441a2ded.js"],"default"]
53:I[92642,[],"OutletBoundary"]
54:"$Sreact.suspense"
56:I[92642,[],"ViewportBoundary"]
58:I[92642,[],"MetadataBoundary"]
:HL["/lenoy-imobiliarias-logo-20260826.png","image"]
1e:["$","header",null,{"className":"adminTopbar","children":["$","div",null,{"className":"container adminNav","children":[["$","a",null,{"className":"brand","href":"../","children":["$","img",null,{"src":"/lenoy-imobiliarias-logo-20260826.png","alt":"LENOY IMOBILIÁRIAS","style":{"width":88,"maxWidth":"24vw","height":"auto","display":"block"}}]}],["$","div",null,{"className":"adminNavActions","children":[["$","$L24",null,{}],["$","a",null,{"className":"button primary small","href":"../","children":"Ver site"}]]}]]}]}]
1f:["$","div",null,{"className":"container adminShell","children":[["$","aside",null,{"className":"adminSidebar adminSidebarCompact","aria-label":"Navegação do painel","children":[["$","strong",null,{"children":"Central de gestão"}],["$","a",null,{"className":"active","href":"#visao-geral","children":"Visão geral"}],["$","a",null,{"href":"#imoveis","children":"Imóveis"}],["$","a",null,{"href":"#acessos-comercial","children":"Comercial"}],["$","a",null,{"href":"#acessos-imoveis","children":"Operação"}],["$","a",null,{"href":"#acessos-equipe","children":"Equipe"}],["$","a",null,{"href":"#acessos-configuracoes","children":"Configurações"}]]}],["$","section",null,{"className":"adminContent","id":"visao-geral","children":[["$","div",null,{"className":"adminHeading","children":[["$","div",null,{"children":[["$","span",null,{"className":"eyebrow","children":"PAINEL DA IMOBILIÁRIA"}],["$","h1",null,{"children":"Central de gestão"}],["$","p",null,{"children":"Imóveis, contatos, agenda, equipe e configurações organizados por área. As funções existentes continuam disponíveis nos mesmos módulos."}]]}],["$","div",null,{"className":"adminHeadingActions","children":[["$","a",null,{"className":"button adminDownloadAppButton","href":"/baixar-app/","aria-label":"Baixar aplicativo LENOY Imobiliárias","children":"Baixar app"}],["$","a",null,{"className":"button primary adminOnly","href":"#novo-imovel","children":"+ Cadastrar imóvel"}]]}]]}],["$","nav",null,{"className":"adminQuickActions","aria-label":"Ações rápidas","children":[["$","a",null,{"href":"#novo-imovel","children":"＋ Novo imóvel"}],["$","a",null,{"href":"#contatos","children":"✉ Contatos"}],["$","a",null,{"href":"#agenda-visitas","children":"▦ Agenda"}],["$","a",null,{"href":"#funil-comercial","children":"◎ Funil comercial"}],["$","a",null,{"href":"#corretores","children":"♟ Corretores"}],["$","a",null,{"href":"#configuracoes","children":"✎ Personalizar"}]]}],["$","$L25",null,{}],["$","section",null,{"className":"adminModulesSection","aria-label":"Áreas do painel","children":[["$","div",null,{"className":"adminModulesHeading","children":[["$","div",null,{"children":[["$","span",null,{"className":"eyebrow","children":"FERRAMENTAS"}],["$","h2",null,{"children":"Acesse por área"}]]}],["$","small",null,{"children":"Menos procura, mais ação."}]]}],["$","div",null,{"className":"adminAccessGroups","children":[["$","section",null,{"className":"adminAccessGroup","id":"acessos-comercial","children":[["$","div",null,{"className":"adminAccessGroupHeader","children":[["$","div",null,{"children":[["$","h3",null,{"children":"Comercial e relacionamento"}],["$","p",null,{"children":"Contatos, funil, oportunidades, agenda e acompanhamentos."}]]}],["$","span",null,{"className":"adminAccessGroupTag","children":"Comercial"}]]}],["$","nav",null,{"className":"adminModuleGrid","children":[["$","a",null,{"className":"adminModuleCard","href":"#contatos","children":[["$","span",null,{"className":"adminModuleIcon","aria-hidden":"true","children":"✉"}],["$","span",null,{"className":"adminModuleCopy","children":[["$","strong",null,{"children":"Contatos recebidos"}],["$","small",null,{"children":"Leads e mensagens"}]]}],null,["$","span",null,{"className":"adminModuleArrow","aria-hidden":"true","children":"→"}]]}],["$","a",null,{"className":"adminModuleCard","href":"#alertas-operacionais","children":[["$","span",null,{"className":"adminModuleIcon","aria-hidden":"true","children":"!"}],["$","span",null,{"className":"adminModuleCopy","children":[["$","strong",null,{"children":"Alertas operacionais"}],["$","small",null,{"children":"Pendências e avisos"}]]}],null,["$","span",null,{"className":"adminModuleArrow","aria-hidden":"true","children":"→"}]]}],["$","a",null,{"className":"adminModuleCard","href":"#funil-comercial","children":[["$","span",null,{"className":"adminModuleIcon","aria-hidden":"true","children":"◎"}],["$","span",null,{"className":"adminModuleCopy","children":[["$","strong",null,{"children":"Funil comercial"}],["$","small",null,{"children":"Negociações e etapas"}]]}],null,["$","span",null,{"className":"adminModuleArrow","aria-hidden":"true","children":"→"}]]}],["$","a",null,{"className":"adminModuleCard","href":"#tempo-resposta","children":[["$","span",null,{"className":"adminModuleIcon","aria-hidden":"true","children":"◷"}],["$","span",null,{"className":"adminModuleCopy","children":[["$","strong",null,{"children":"Tempo de resposta"}],["$","small",null,{"children":"Velocidade de atendimento"}]]}],null,["$","span",null,{"className":"adminModuleArrow","aria-hidden":"true","children":"→"}]]}],["$","a",null,{"className":"adminModuleCard","href":"#qualificacao-contatos","children":["$L26","$L27",null,"$L28"]}],"$L29","$L2a","$L2b","$L2c","$L2d","$L2e","$L2f","$L30"]}]]}],"$L31","$L32","$L33"]}]]}],"$L34","$L35","$L36","$L37","$L38","$L39","$L3a","$L3b","$L3c","$L3d","$L3e","$L3f","$L40","$L41","$L42","$L43","$L44","$L45","$L46","$L47","$L48","$L49","$L4a","$L4b","$L4c","$L4d","$L4e","$L4f","$L50","$L51","$L52"]}]]}]
20:["$","$L53",null,{"children":["$","$54",null,{"name":"Next.MetadataOutlet","children":"$@55"}]}]
22:["$","$1","h",{"children":[null,["$","$L56",null,{"children":"$L57"}],["$","div",null,{"hidden":true,"children":["$","$L58",null,{"children":["$","$54",null,{"name":"Next.Metadata","children":"$L59"}]}]}],null]}]
5a:I[8381,["2099","static/chunks/9e43655a-b2fa3409b88f33d1.js","6424","static/chunks/6424-d1b373fb508f5573.js","7111","static/chunks/7111-03fe5f752cc66088.js","3698","static/chunks/app/admin/page-dc7c128f441a2ded.js"],"default"]
5b:I[59564,["2099","static/chunks/9e43655a-b2fa3409b88f33d1.js","6424","static/chunks/6424-d1b373fb508f5573.js","7111","static/chunks/7111-03fe5f752cc66088.js","3698","static/chunks/app/admin/page-dc7c128f441a2ded.js"],"default"]
5c:I[78778,["2099","static/chunks/9e43655a-b2fa3409b88f33d1.js","6424","static/chunks/6424-d1b373fb508f5573.js","7111","static/chunks/7111-03fe5f752cc66088.js","3698","static/chunks/app/admin/page-dc7c128f441a2ded.js"],"default"]
5d:I[46795,["2099","static/chunks/9e43655a-b2fa3409b88f33d1.js","6424","static/chunks/6424-d1b373fb508f5573.js","7111","static/chunks/7111-03fe5f752cc66088.js","3698","static/chunks/app/admin/page-dc7c128f441a2ded.js"],"default"]
5e:I[380,["2099","static/chunks/9e43655a-b2fa3409b88f33d1.js","6424","static/chunks/6424-d1b373fb508f5573.js","7111","static/chunks/7111-03fe5f752cc66088.js","3698","static/chunks/app/admin/page-dc7c128f441a2ded.js"],"default"]
5f:I[364,["2099","static/chunks/9e43655a-b2fa3409b88f33d1.js","6424","static/chunks/6424-d1b373fb508f5573.js","7111","static/chunks/7111-03fe5f752cc66088.js","3698","static/chunks/app/admin/page-dc7c128f441a2ded.js"],"default"]
60:I[63733,["2099","static/chunks/9e43655a-b2fa3409b88f33d1.js","6424","static/chunks/6424-d1b373fb508f5573.js","7111","static/chunks/7111-03fe5f752cc66088.js","3698","static/chunks/app/admin/page-dc7c128f441a2ded.js"],"default"]
61:I[74875,["2099","static/chunks/9e43655a-b2fa3409b88f33d1.js","6424","static/chunks/6424-d1b373fb508f5573.js","7111","static/chunks/7111-03fe5f752cc66088.js","3698","static/chunks/app/admin/page-dc7c128f441a2ded.js"],"default"]
62:I[41479,["2099","static/chunks/9e43655a-b2fa3409b88f33d1.js","6424","static/chunks/6424-d1b373fb508f5573.js","7111","static/chunks/7111-03fe5f752cc66088.js","3698","static/chunks/app/admin/page-dc7c128f441a2ded.js"],"default"]
63:I[7722,["2099","static/chunks/9e43655a-b2fa3409b88f33d1.js","6424","static/chunks/6424-d1b373fb508f5573.js","7111","static/chunks/7111-03fe5f752cc66088.js","3698","static/chunks/app/admin/page-dc7c128f441a2ded.js"],"default"]
64:I[49023,["2099","static/chunks/9e43655a-b2fa3409b88f33d1.js","6424","static/chunks/6424-d1b373fb508f5573.js","7111","static/chunks/7111-03fe5f752cc66088.js","3698","static/chunks/app/admin/page-dc7c128f441a2ded.js"],"default"]
65:I[80366,["2099","static/chunks/9e43655a-b2fa3409b88f33d1.js","6424","static/chunks/6424-d1b373fb508f5573.js","7111","static/chunks/7111-03fe5f752cc66088.js","3698","static/chunks/app/admin/page-dc7c128f441a2ded.js"],"default"]
66:I[47341,["2099","static/chunks/9e43655a-b2fa3409b88f33d1.js","6424","static/chunks/6424-d1b373fb508f5573.js","7111","static/chunks/7111-03fe5f752cc66088.js","3698","static/chunks/app/admin/page-dc7c128f441a2ded.js"],"default"]
67:I[94916,["2099","static/chunks/9e43655a-b2fa3409b88f33d1.js","6424","static/chunks/6424-d1b373fb508f5573.js","7111","static/chunks/7111-03fe5f752cc66088.js","3698","static/chunks/app/admin/page-dc7c128f441a2ded.js"],"default"]
68:I[57905,["2099","static/chunks/9e43655a-b2fa3409b88f33d1.js","6424","static/chunks/6424-d1b373fb508f5573.js","7111","static/chunks/7111-03fe5f752cc66088.js","3698","static/chunks/app/admin/page-dc7c128f441a2ded.js"],"default"]
69:I[4790,["2099","static/chunks/9e43655a-b2fa3409b88f33d1.js","6424","static/chunks/6424-d1b373fb508f5573.js","7111","static/chunks/7111-03fe5f752cc66088.js","3698","static/chunks/app/admin/page-dc7c128f441a2ded.js"],"default"]
6a:I[99637,["2099","static/chunks/9e43655a-b2fa3409b88f33d1.js","6424","static/chunks/6424-d1b373fb508f5573.js","7111","static/chunks/7111-03fe5f752cc66088.js","3698","static/chunks/app/admin/page-dc7c128f441a2ded.js"],"default"]
6b:I[27787,["2099","static/chunks/9e43655a-b2fa3409b88f33d1.js","6424","static/chunks/6424-d1b373fb508f5573.js","7111","static/chunks/7111-03fe5f752cc66088.js","3698","static/chunks/app/admin/page-dc7c128f441a2ded.js"],"default"]
6c:I[23971,["2099","static/chunks/9e43655a-b2fa3409b88f33d1.js","6424","static/chunks/6424-d1b373fb508f5573.js","7111","static/chunks/7111-03fe5f752cc66088.js","3698","static/chunks/app/admin/page-dc7c128f441a2ded.js"],"default"]
6d:I[31030,["2099","static/chunks/9e43655a-b2fa3409b88f33d1.js","6424","static/chunks/6424-d1b373fb508f5573.js","7111","static/chunks/7111-03fe5f752cc66088.js","3698","static/chunks/app/admin/page-dc7c128f441a2ded.js"],"default"]
6e:I[50404,["2099","static/chunks/9e43655a-b2fa3409b88f33d1.js","6424","static/chunks/6424-d1b373fb508f5573.js","7111","static/chunks/7111-03fe5f752cc66088.js","3698","static/chunks/app/admin/page-dc7c128f441a2ded.js"],"default"]
6f:I[8576,["2099","static/chunks/9e43655a-b2fa3409b88f33d1.js","6424","static/chunks/6424-d1b373fb508f5573.js","7111","static/chunks/7111-03fe5f752cc66088.js","3698","static/chunks/app/admin/page-dc7c128f441a2ded.js"],"default"]
70:I[48326,["2099","static/chunks/9e43655a-b2fa3409b88f33d1.js","6424","static/chunks/6424-d1b373fb508f5573.js","7111","static/chunks/7111-03fe5f752cc66088.js","3698","static/chunks/app/admin/page-dc7c128f441a2ded.js"],"default"]
71:I[20842,["2099","static/chunks/9e43655a-b2fa3409b88f33d1.js","6424","static/chunks/6424-d1b373fb508f5573.js","7111","static/chunks/7111-03fe5f752cc66088.js","3698","static/chunks/app/admin/page-dc7c128f441a2ded.js"],"default"]
72:I[33672,["2099","static/chunks/9e43655a-b2fa3409b88f33d1.js","6424","static/chunks/6424-d1b373fb508f5573.js","7111","static/chunks/7111-03fe5f752cc66088.js","3698","static/chunks/app/admin/page-dc7c128f441a2ded.js"],"default"]
73:I[51589,["2099","static/chunks/9e43655a-b2fa3409b88f33d1.js","6424","static/chunks/6424-d1b373fb508f5573.js","7111","static/chunks/7111-03fe5f752cc66088.js","3698","static/chunks/app/admin/page-dc7c128f441a2ded.js"],"default"]
74:I[73827,["2099","static/chunks/9e43655a-b2fa3409b88f33d1.js","6424","static/chunks/6424-d1b373fb508f5573.js","7111","static/chunks/7111-03fe5f752cc66088.js","3698","static/chunks/app/admin/page-dc7c128f441a2ded.js"],"default"]
75:I[8460,["2099","static/chunks/9e43655a-b2fa3409b88f33d1.js","6424","static/chunks/6424-d1b373fb508f5573.js","7111","static/chunks/7111-03fe5f752cc66088.js","3698","static/chunks/app/admin/page-dc7c128f441a2ded.js"],"default"]
76:I[62400,["2099","static/chunks/9e43655a-b2fa3409b88f33d1.js","6424","static/chunks/6424-d1b373fb508f5573.js","7111","static/chunks/7111-03fe5f752cc66088.js","3698","static/chunks/app/admin/page-dc7c128f441a2ded.js"],"default"]
77:I[24161,["2099","static/chunks/9e43655a-b2fa3409b88f33d1.js","6424","static/chunks/6424-d1b373fb508f5573.js","7111","static/chunks/7111-03fe5f752cc66088.js","3698","static/chunks/app/admin/page-dc7c128f441a2ded.js"],"default"]
78:I[7349,["2099","static/chunks/9e43655a-b2fa3409b88f33d1.js","6424","static/chunks/6424-d1b373fb508f5573.js","7111","static/chunks/7111-03fe5f752cc66088.js","3698","static/chunks/app/admin/page-dc7c128f441a2ded.js"],"default"]
79:I[43258,["2099","static/chunks/9e43655a-b2fa3409b88f33d1.js","6424","static/chunks/6424-d1b373fb508f5573.js","7111","static/chunks/7111-03fe5f752cc66088.js","3698","static/chunks/app/admin/page-dc7c128f441a2ded.js"],"default"]
7a:I[52131,["2099","static/chunks/9e43655a-b2fa3409b88f33d1.js","6424","static/chunks/6424-d1b373fb508f5573.js","7111","static/chunks/7111-03fe5f752cc66088.js","3698","static/chunks/app/admin/page-dc7c128f441a2ded.js"],"default"]
7b:I[35200,["2099","static/chunks/9e43655a-b2fa3409b88f33d1.js","6424","static/chunks/6424-d1b373fb508f5573.js","7111","static/chunks/7111-03fe5f752cc66088.js","3698","static/chunks/app/admin/page-dc7c128f441a2ded.js"],"default"]
7c:I[35984,["2099","static/chunks/9e43655a-b2fa3409b88f33d1.js","6424","static/chunks/6424-d1b373fb508f5573.js","7111","static/chunks/7111-03fe5f752cc66088.js","3698","static/chunks/app/admin/page-dc7c128f441a2ded.js"],"default"]
7d:I[21316,["2099","static/chunks/9e43655a-b2fa3409b88f33d1.js","6424","static/chunks/6424-d1b373fb508f5573.js","7111","static/chunks/7111-03fe5f752cc66088.js","3698","static/chunks/app/admin/page-dc7c128f441a2ded.js"],"default"]
7e:I[10519,["2099","static/chunks/9e43655a-b2fa3409b88f33d1.js","6424","static/chunks/6424-d1b373fb508f5573.js","7111","static/chunks/7111-03fe5f752cc66088.js","3698","static/chunks/app/admin/page-dc7c128f441a2ded.js"],"default"]
21:C
26:["$","span",null,{"className":"adminModuleIcon","aria-hidden":"true","children":"★"}]
27:["$","span",null,{"className":"adminModuleCopy","children":[["$","strong",null,{"children":"Classificação de contatos"}],["$","small",null,{"children":"Prioridade e perfil"}]]}]
28:["$","span",null,{"className":"adminModuleArrow","aria-hidden":"true","children":"→"}]
29:["$","a",null,{"className":"adminModuleCard","href":"#perfil-compra","children":[["$","span",null,{"className":"adminModuleIcon","aria-hidden":"true","children":"⌂"}],["$","span",null,{"className":"adminModuleCopy","children":[["$","strong",null,{"children":"Perfil de compra"}],["$","small",null,{"children":"Preferências dos compradores"}]]}],null,["$","span",null,{"className":"adminModuleArrow","aria-hidden":"true","children":"→"}]]}]
2a:["$","a",null,{"className":"adminModuleCard","href":"#consentimento-compradores","children":[["$","span",null,{"className":"adminModuleIcon","aria-hidden":"true","children":"✓"}],["$","span",null,{"className":"adminModuleCopy","children":[["$","strong",null,{"children":"Permissões e consentimentos"}],["$","small",null,{"children":"Consentimento dos compradores"}]]}],null,["$","span",null,{"className":"adminModuleArrow","aria-hidden":"true","children":"→"}]]}]
2b:["$","a",null,{"className":"adminModuleCard","href":"#oportunidades-ia","children":[["$","span",null,{"className":"adminModuleIcon","aria-hidden":"true","children":"✦"}],["$","span",null,{"className":"adminModuleCopy","children":[["$","strong",null,{"children":"Oportunidades automáticas"}],["$","small",null,{"children":"Matches para compradores"}]]}],null,["$","span",null,{"className":"adminModuleArrow","aria-hidden":"true","children":"→"}]]}]
2c:["$","a",null,{"className":"adminModuleCard","href":"#entregas-oportunidades","children":[["$","span",null,{"className":"adminModuleIcon","aria-hidden":"true","children":"↗"}],["$","span",null,{"className":"adminModuleCopy","children":[["$","strong",null,{"children":"Entregas automáticas"}],["$","small",null,{"children":"Envios de oportunidades"}]]}],null,["$","span",null,{"className":"adminModuleArrow","aria-hidden":"true","children":"→"}]]}]
2d:["$","a",null,{"className":"adminModuleCard","href":"#respostas-oportunidades","children":[["$","span",null,{"className":"adminModuleIcon","aria-hidden":"true","children":"↩"}],["$","span",null,{"className":"adminModuleCopy","children":[["$","strong",null,{"children":"Respostas IA"}],["$","small",null,{"children":"Retornos dos compradores"}]]}],null,["$","span",null,{"className":"adminModuleArrow","aria-hidden":"true","children":"→"}]]}]
2e:["$","a",null,{"className":"adminModuleCard","href":"#agenda-visitas","children":[["$","span",null,{"className":"adminModuleIcon","aria-hidden":"true","children":"▦"}],["$","span",null,{"className":"adminModuleCopy","children":[["$","strong",null,{"children":"Agenda de visitas"}],["$","small",null,{"children":"Visitas e compromissos"}]]}],null,["$","span",null,{"className":"adminModuleArrow","aria-hidden":"true","children":"→"}]]}]
2f:["$","a",null,{"className":"adminModuleCard","href":"#acompanhamentos","children":[["$","span",null,{"className":"adminModuleIcon","aria-hidden":"true","children":"↻"}],["$","span",null,{"className":"adminModuleCopy","children":[["$","strong",null,{"children":"Acompanhamentos"}],["$","small",null,{"children":"Follow-ups comerciais"}]]}],null,["$","span",null,{"className":"adminModuleArrow","aria-hidden":"true","children":"→"}]]}]
30:["$","a",null,{"className":"adminModuleCard","href":"#historico-contato","children":[["$","span",null,{"className":"adminModuleIcon","aria-hidden":"true","children":"≡"}],["$","span",null,{"className":"adminModuleCopy","children":[["$","strong",null,{"children":"Histórico dos contatos"}],["$","small",null,{"children":"Linha do tempo comercial"}]]}],null,["$","span",null,{"className":"adminModuleArrow","aria-hidden":"true","children":"→"}]]}]
31:["$","section",null,{"className":"adminAccessGroup","id":"acessos-imoveis","children":[["$","div",null,{"className":"adminAccessGroupHeader","children":[["$","div",null,{"children":[["$","h3",null,{"children":"Imóveis e operação"}],["$","p",null,{"children":"Cadastro, qualidade, desempenho e documentação do catálogo."}]]}],["$","span",null,{"className":"adminAccessGroupTag","children":"Operação"}]]}],["$","nav",null,{"className":"adminModuleGrid","children":[["$","a",null,{"className":"adminModuleCard","href":"#novo-imovel","children":[["$","span",null,{"className":"adminModuleIcon","aria-hidden":"true","children":"＋"}],["$","span",null,{"className":"adminModuleCopy","children":[["$","strong",null,{"children":"Novo imóvel"}],["$","small",null,{"children":"Cadastro + descrição com IA"}]]}],null,["$","span",null,{"className":"adminModuleArrow","aria-hidden":"true","children":"→"}]]}],["$","a",null,{"className":"adminModuleCard","href":"#desempenho-imoveis","children":[["$","span",null,{"className":"adminModuleIcon","aria-hidden":"true","children":"↗"}],["$","span",null,{"className":"adminModuleCopy","children":[["$","strong",null,{"children":"Desempenho dos imóveis"}],["$","small",null,{"children":"Acessos e resultados"}]]}],null,["$","span",null,{"className":"adminModuleArrow","aria-hidden":"true","children":"→"}]]}],["$","a",null,{"className":"adminModuleCard","href":"#qualidade-imoveis","children":[["$","span",null,{"className":"adminModuleIcon","aria-hidden":"true","children":"★"}],["$","span",null,{"className":"adminModuleCopy","children":[["$","strong",null,{"children":"Qualidade dos anúncios"}],["$","small",null,{"children":"Completude e melhorias"}]]}],null,["$","span",null,{"className":"adminModuleArrow","aria-hidden":"true","children":"→"}]]}],["$","a",null,{"className":"adminModuleCard","href":"#documentacao-imovel","children":[["$","span",null,{"className":"adminModuleIcon","aria-hidden":"true","children":"☑"}],["$","span",null,{"className":"adminModuleCopy","children":[["$","strong",null,{"children":"Checklist documental"}],["$","small",null,{"children":"Documentos aprovados e pendentes"}]]}],null,["$","span",null,{"className":"adminModuleArrow","aria-hidden":"true","children":"→"}]]}],["$","a",null,{"className":"adminModuleCard","href":"#catalogo-config","children":[["$","span",null,{"className":"adminModuleIcon","aria-hidden":"true","children":"▤"}],["$","span",null,{"className":"adminModuleCopy","children":[["$","strong",null,{"children":"Tipos e características"}],["$","small",null,{"children":"Organização do catálogo"}]]}],null,["$","span",null,{"className":"adminModuleArrow","aria-hidden":"true","children":"→"}]]}],["$","a",null,{"className":"adminModuleCard","href":"#documentos","children":[["$","span",null,{"className":"adminModuleIcon","aria-hidden":"true","children":"▣"}],["$","span",null,{"className":"adminModuleCopy","children":[["$","strong",null,{"children":"Central de documentos"}],["$","small",null,{"children":"Documentos da imobiliária"}]]}],null,["$","span",null,{"className":"adminModuleArrow","aria-hidden":"true","children":"→"}]]}],["$","a",null,{"className":"adminModuleCard","href":"#arquivos-documentos","children":[["$","span",null,{"className":"adminModuleIcon","aria-hidden":"true","children":"⇧"}],["$","span",null,{"className":"adminModuleCopy","children":[["$","strong",null,{"children":"Documentos enviados"}],["$","small",null,{"children":"Arquivos e consumo do plano"}]]}],null,["$","span",null,{"className":"adminModuleArrow","aria-hidden":"true","children":"→"}]]}],["$","a",null,{"className":"adminModuleCard","href":"#uso-documentos","children":[["$","span",null,{"className":"adminModuleIcon","aria-hidden":"true","children":"◫"}],["$","span",null,{"className":"adminModuleCopy","children":[["$","strong",null,{"children":"Uso de documentos"}],["$","small",null,{"children":"Consumo e disponibilidade"}]]}],null,["$","span",null,{"className":"adminModuleArrow","aria-hidden":"true","children":"→"}]]}]]}]]}]
32:["$","section",null,{"className":"adminAccessGroup","id":"acessos-equipe","children":[["$","div",null,{"className":"adminAccessGroupHeader","children":[["$","div",null,{"children":[["$","h3",null,{"children":"Equipe e acessos"}],["$","p",null,{"children":"Corretores, metas, usuários e permissões."}]]}],["$","span",null,{"className":"adminAccessGroupTag","children":"Equipe"}]]}],["$","nav",null,{"className":"adminModuleGrid","children":[["$","a",null,{"className":"adminModuleCard","href":"#corretores","children":[["$","span",null,{"className":"adminModuleIcon","aria-hidden":"true","children":"♟"}],["$","span",null,{"className":"adminModuleCopy","children":[["$","strong",null,{"children":"Corretores"}],["$","small",null,{"children":"Equipe de corretores"}]]}],null,["$","span",null,{"className":"adminModuleArrow","aria-hidden":"true","children":"→"}]]}],["$","a",null,{"className":"adminModuleCard","href":"#desempenho-corretores","children":[["$","span",null,{"className":"adminModuleIcon","aria-hidden":"true","children":"↗"}],["$","span",null,{"className":"adminModuleCopy","children":[["$","strong",null,{"children":"Desempenho dos corretores"}],["$","small",null,{"children":"Resultados da equipe"}]]}],null,["$","span",null,{"className":"adminModuleArrow","aria-hidden":"true","children":"→"}]]}],["$","a",null,{"className":"adminModuleCard","href":"#metas-corretores","children":[["$","span",null,{"className":"adminModuleIcon","aria-hidden":"true","children":"◎"}],["$","span",null,{"className":"adminModuleCopy","children":[["$","strong",null,{"children":"Metas dos corretores"}],["$","small",null,{"children":"Objetivos da equipe"}]]}],null,["$","span",null,{"className":"adminModuleArrow","aria-hidden":"true","children":"→"}]]}],["$","a",null,{"className":"adminModuleCard","href":"#usuarios","children":[["$","span",null,{"className":"adminModuleIcon","aria-hidden":"true","children":"♙"}],["$","span",null,{"className":"adminModuleCopy","children":[["$","strong",null,{"children":"Usuários e permissões"}],["$","small",null,{"children":"Acessos da equipe"}]]}],null,["$","span",null,{"className":"adminModuleArrow","aria-hidden":"true","children":"→"}]]}],["$","a",null,{"className":"adminModuleCard","href":"#convites","children":[["$","span",null,{"className":"adminModuleIcon","aria-hidden":"true","children":"＋"}],["$","span",null,{"className":"adminModuleCopy","children":[["$","strong",null,{"children":"Convites de acesso"}],["$","small",null,{"children":"Novos membros"}]]}],null,["$","span",null,{"className":"adminModuleArrow","aria-hidden":"true","children":"→"}]]}],["$","a",null,{"className":"adminModuleCard","href":"#emails-profissionais","children":[["$","span",null,{"className":"adminModuleIcon","aria-hidden":"true","children":"@"}],["$","span",null,{"className":"adminModuleCopy","children":[["$","strong",null,{"children":"E-mails profissionais"}],["$","small",null,{"children":"Contas do plano"}]]}],null,["$","span",null,{"className":"adminModuleArrow","aria-hidden":"true","children":"→"}]]}]]}]]}]
33:["$","section",null,{"className":"adminAccessGroup","id":"acessos-configuracoes","children":[["$","div",null,{"className":"adminAccessGroupHeader","children":[["$","div",null,{"children":[["$","h3",null,{"children":"Conta e personalização"}],["$","p",null,{"children":"Plano, identidade, domínio e segurança dos dados."}]]}],["$","span",null,{"className":"adminAccessGroupTag","children":"Configurações"}]]}],["$","nav",null,{"className":"adminModuleGrid","children":[["$","a",null,{"className":"adminModuleCard","href":"#meu-plano","children":[["$","span",null,{"className":"adminModuleIcon","aria-hidden":"true","children":"◆"}],["$","span",null,{"className":"adminModuleCopy","children":[["$","strong",null,{"children":"Meu plano"}],["$","small",null,{"children":"Plano atual, renovação e upgrade"}]]}],null,["$","span",null,{"className":"adminModuleArrow","aria-hidden":"true","children":"→"}]]}],["$","a",null,{"className":"adminModuleCard","href":"#configuracoes","children":[["$","span",null,{"className":"adminModuleIcon","aria-hidden":"true","children":"✎"}],["$","span",null,{"className":"adminModuleCopy","children":[["$","strong",null,{"children":"Personalizar"}],["$","small",null,{"children":"Marca no site e aplicativo"}]]}],null,["$","span",null,{"className":"adminModuleArrow","aria-hidden":"true","children":"→"}]]}],["$","a",null,{"className":"adminModuleCard","href":"#dominios","children":[["$","span",null,{"className":"adminModuleIcon","aria-hidden":"true","children":"⌘"}],["$","span",null,{"className":"adminModuleCopy","children":[["$","strong",null,{"children":"Domínios"}],["$","small",null,{"children":"Endereços da imobiliária"}]]}],null,["$","span",null,{"className":"adminModuleArrow","aria-hidden":"true","children":"→"}]]}],["$","a",null,{"className":"adminModuleCard","href":"#exportacoes","children":[["$","span",null,{"className":"adminModuleIcon","aria-hidden":"true","children":"⇩"}],["$","span",null,{"className":"adminModuleCopy","children":[["$","strong",null,{"children":"Exportações e cópia"}],["$","small",null,{"children":"Cópia dos dados"}]]}],null,["$","span",null,{"className":"adminModuleArrow","aria-hidden":"true","children":"→"}]]}]]}]]}]
34:["$","$L5a",null,{}]
35:["$","$L5b",null,{}]
36:["$","$L5c",null,{}]
37:["$","$L5d",null,{}]
38:["$","$L5e",null,{}]
39:["$","$L5f",null,{}]
3a:["$","$L60",null,{}]
3b:["$","$L61",null,{}]
3c:["$","$L62",null,{}]
3d:["$","$L63",null,{}]
3e:["$","$L64",null,{}]
3f:["$","$L65",null,{}]
40:["$","$L66",null,{}]
41:["$","$L67",null,{}]
42:["$","$L68",null,{}]
43:["$","$L69",null,{}]
44:["$","$L6a",null,{}]
45:["$","$L6b",null,{}]
46:["$","div",null,{"className":"adminPanel adminOnly","id":"novo-imovel","children":[["$","div",null,{"className":"adminPanelHeader","children":["$","div",null,{"children":[["$","span",null,{"className":"eyebrow","children":"CADASTRO REAL"}],["$","h2",null,{"children":"Novo imóvel"}],["$","p",null,{"children":"Cadastre o imóvel e use a descrição com IA no mesmo fluxo."}]]}]}],["$","$L6c",null,{}],["$","$L6d",null,{}]]}]
47:["$","$L6e",null,{}]
48:["$","$L6f",null,{}]
49:["$","$L70",null,{}]
4a:["$","$L71",null,{}]
4b:["$","$L72",null,{}]
4c:["$","$L73",null,{}]
4d:["$","$L74",null,{}]
4e:["$","$L75",null,{}]
4f:["$","$L76",null,{}]
50:["$","$L77",null,{}]
51:["$","$L78",null,{}]
52:["$","div",null,{"className":"adminInternalHidden","aria-hidden":"true","children":[["$","$L79",null,{}],["$","$L7a",null,{}],["$","$L7b",null,{}],["$","$L7c",null,{}],["$","$L7d",null,{}],["$","$L7e",null,{}]]}]
57:[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]
7f:I[22183,[],"IconMark"]
55:null
59:[["$","title","0",{"children":"LENOY IMOBILIÁRIAS | Plataforma para imobiliárias"}],["$","meta","1",{"name":"description","content":"Plataforma SaaS para imobiliárias com site próprio, catálogo de imóveis, corretores, leads, domínio personalizado e recursos de inteligência artificial."}],["$","meta","2",{"name":"keywords","content":"imobiliária,site para imobiliária,sistema imobiliário,imóveis,corretores,leads,SaaS imobiliário"}],["$","meta","3",{"name":"robots","content":"index, follow"}],["$","link","4",{"rel":"canonical","href":"https://imoveis.lenoy.com.br"}],["$","meta","5",{"property":"og:title","content":"LENOY IMOBILIÁRIAS"}],["$","meta","6",{"property":"og:description","content":"Plataforma completa para imobiliárias criarem seu site, publicarem imóveis e gerenciarem equipe e contatos."}],["$","meta","7",{"property":"og:url","content":"https://imoveis.lenoy.com.br"}],["$","meta","8",{"property":"og:locale","content":"pt_BR"}],["$","meta","9",{"property":"og:image","content":"https://lenoy.com.br/wp-content/uploads/2026/08/hh.png"}],["$","meta","10",{"property":"og:image:width","content":"512"}],["$","meta","11",{"property":"og:image:height","content":"512"}],["$","meta","12",{"property":"og:image:alt","content":"LENOY IMOBILIÁRIAS"}],["$","meta","13",{"property":"og:type","content":"website"}],["$","meta","14",{"name":"twitter:card","content":"summary_large_image"}],["$","meta","15",{"name":"twitter:title","content":"LENOY IMOBILIÁRIAS"}],["$","meta","16",{"name":"twitter:description","content":"Plataforma completa para imobiliárias criarem seu site, publicarem imóveis e gerenciarem equipe e contatos."}],["$","meta","17",{"name":"twitter:image","content":"https://lenoy.com.br/wp-content/uploads/2026/08/hh.png"}],["$","meta","18",{"name":"twitter:image:alt","content":"LENOY IMOBILIÁRIAS"}],["$","meta","19",{"name":"twitter:image:width","content":"512"}],["$","meta","20",{"name":"twitter:image:height","content":"512"}],["$","link","21",{"rel":"shortcut icon","href":"https://lenoy.com.br/wp-content/uploads/2026/08/hh.png","type":"image/png"}],["$","link","22",{"rel":"icon","href":"https://lenoy.com.br/wp-content/uploads/2026/08/hh.png","type":"image/png"}],["$","link","23",{"rel":"apple-touch-icon","href":"https://lenoy.com.br/wp-content/uploads/2026/08/hh.png"}],["$","$L7f","24",{}]]
