:HL["/_next/static/css/36ec8291e48c2b16.css","style"]
:HL["/_next/static/css/09450e63557adb07.css","style"]
:HL["/_next/static/css/99a5aa8332ae5a4c.css","style"]
:HL["/_next/static/css/972a15ecde8cf09d.css","style"]
:HL["/_next/static/css/bc3c14dbe68a79e0.css","style"]
0:{"tree":{"name":"","param":null,"prefetchHints":4112,"slots":{"children":{"name":"imovel","param":null,"prefetchHints":4160,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":4256,"slots":null}}}}},"staleTime":300,"buildId":"Ew-Iw6JiubSEERhZ8bIU8"}
