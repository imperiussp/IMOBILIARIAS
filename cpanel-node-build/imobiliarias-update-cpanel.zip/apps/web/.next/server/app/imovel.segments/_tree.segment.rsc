:HL["/_next/static/css/d61a10ebe8f22b3d.css","style"]
:HL["/_next/static/css/2b2c6612b55d0e37.css","style"]
:HL["/_next/static/css/99a5aa8332ae5a4c.css","style"]
:HL["/_next/static/css/b8d43550eedacc19.css","style"]
0:{"tree":{"name":"","param":null,"prefetchHints":4112,"slots":{"children":{"name":"imovel","param":null,"prefetchHints":4160,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":4256,"slots":null}}}}},"staleTime":300,"buildId":"1pR3lLAILiE7BxK2Mxo9C"}
