:HL["/_next/static/css/36ec8291e48c2b16.css","style"]
:HL["/_next/static/css/09450e63557adb07.css","style"]
:HL["/_next/static/css/99a5aa8332ae5a4c.css","style"]
:HL["/_next/static/css/f5c66b7ad61822d5.css","style"]
0:{"tree":{"name":"","param":null,"prefetchHints":4112,"slots":{"children":{"name":"app","param":null,"prefetchHints":4160,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":4256,"slots":null}}}}},"staleTime":300,"buildId":"9EIdK4YYkckL0GsbqEBqF"}
