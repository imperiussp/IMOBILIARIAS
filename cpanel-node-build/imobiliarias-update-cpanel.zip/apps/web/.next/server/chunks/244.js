exports.id=244,exports.ids=[244],exports.modules={16928:(a,b,c)=>{"use strict";c.d(b,{default:()=>e});var d=c(68903);function e(){return(0,d.jsx)("style",{children:`
      @media (min-width: 1101px) {
        html body .platformCommercialPage.platformCommercialPage .commercialClientsPanel .commercialClientGrid {
          display: grid !important;
          grid-template-columns: repeat(2, minmax(0, 1fr)) !important;
          gap: 16px !important;
        }

        html body .platformCommercialPage.platformCommercialPage .commercialClientsPanel .commercialClientCard.isEditing {
          grid-column: 1 / -1 !important;
        }
      }

      @media (max-width: 1100px) {
        html body .platformCommercialPage.platformCommercialPage .commercialClientsPanel .commercialClientGrid {
          grid-template-columns: 1fr !important;
        }

        html body .platformCommercialPage.platformCommercialPage .commercialClientsPanel .commercialClientCard.isEditing {
          grid-column: auto !important;
        }
      }

      html body .platformCommercialPage.platformCommercialPage .commercialClientHeader .commercialClientIdentityVisual {
        position: relative !important;
        min-height: 50px !important;
        padding-left: 62px !important;
        align-content: center !important;
      }

      html body .platformCommercialPage.platformCommercialPage .commercialClientHeader .commercialClientIdentityVisual::before {
        content: "" !important;
        position: absolute !important;
        left: 0 !important;
        top: 0 !important;
        width: 48px !important;
        height: 48px !important;
        border-radius: 999px !important;
        background-color: #102a45 !important;
        background-image: var(--platform-client-avatar) !important;
        background-position: center !important;
        background-repeat: no-repeat !important;
        background-size: cover !important;
        border: 2px solid #fff !important;
        box-shadow: 0 0 0 1px #d9e2e9, 0 4px 12px rgba(16, 42, 69, .12) !important;
      }
    `})}c(67730),c(6040)},25078:(a,b,c)=>{"use strict";c.d(b,{default:()=>g});var d=c(68903),e=c(67730);c(49006);var f=c(6040);function g({children:a}){let[b,c]=(0,e.useState)("checking");async function h(){f.L&&await f.L.auth.signOut(),window.location.href="../login/"}return"checking"===b?(0,d.jsx)("main",{className:"loginPage",children:(0,d.jsx)("div",{className:"loginShell",children:(0,d.jsx)("div",{className:"loginCard",children:(0,d.jsx)("strong",{children:"Verificando administra\xe7\xe3o da plataforma..."})})})}):"wrong_backend"===b?(0,d.jsx)("main",{className:"loginPage",children:(0,d.jsx)("div",{className:"loginShell",children:(0,d.jsxs)("div",{className:"loginCard",children:[(0,d.jsx)("span",{className:"eyebrow",children:"PROTE\xc7\xc3O DE PROJETO"}),(0,d.jsx)("h1",{children:"Conex\xe3o bloqueada"}),(0,d.jsx)("p",{children:"O backend configurado n\xe3o pertence ao projeto IMOBILIARIAS."}),(0,d.jsx)("a",{className:"backLink",href:"../",children:"← Voltar"})]})})}):"blocked"===b?(0,d.jsx)("main",{className:"loginPage",children:(0,d.jsx)("div",{className:"loginShell",children:(0,d.jsxs)("div",{className:"loginCard",children:[(0,d.jsx)("span",{className:"eyebrow",children:"ADMINISTRA\xc7\xc3O LENOY"}),(0,d.jsx)("h1",{children:"Acesso n\xe3o autorizado"}),(0,d.jsx)("p",{children:"Esta \xe1rea \xe9 exclusiva da administra\xe7\xe3o global da plataforma."}),(0,d.jsx)("a",{className:"button primary full",href:"../admin/",children:"Ir para o painel da imobili\xe1ria"}),(0,d.jsx)("button",{className:"button secondary full",onClick:()=>void h(),children:"Sair"})]})})}):(0,d.jsxs)("div",{"data-platform-admin":"true",children:["demo"===b?(0,d.jsx)("div",{className:"demoAdminBanner",children:"Pr\xe9via da administra\xe7\xe3o global. O Supabase ainda n\xe3o est\xe1 conectado neste ambiente."}):(0,d.jsxs)("div",{className:"sessionBar",children:[(0,d.jsxs)("span",{children:[(0,d.jsx)("strong",{children:"LENOY IM\xd3VEIS"})," \xb7 Administra\xe7\xe3o da plataforma"]}),(0,d.jsx)("button",{onClick:()=>void h(),children:"Sair"})]}),a]})}},31588:(a,b,c)=>{"use strict";c.d(b,{default:()=>d});let d=(0,c(88013).registerClientReference)(function(){throw Error("Attempted to call the default export of \"/home/runner/work/IMOBILIARIAS/IMOBILIARIAS/apps/web/components/PlatformAdminGate.tsx\" from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"/home/runner/work/IMOBILIARIAS/IMOBILIARIAS/apps/web/components/PlatformAdminGate.tsx","default")},39215:(a,b,c)=>{"use strict";c.d(b,{default:()=>i});var d=c(68903),e=c(67730),f=c(6040);function g(a){return a.normalize("NFD").replace(/[\u0300-\u036f]/g,"").toLowerCase().replace(/[^a-z0-9]+/g,"-").replace(/^-+|-+$/g,"").replace(/-+/g,"-").slice(0,48)}function h(a){return a?.message||"N\xe3o foi poss\xedvel concluir a opera\xe7\xe3o."}function i(){let[a,b]=(0,e.useState)([]),[c,i]=(0,e.useState)([]),[j,k]=(0,e.useState)(null),[l,m]=(0,e.useState)(null),[n,o]=(0,e.useState)(!1),[p,q]=(0,e.useState)(""),[r,s]=(0,e.useState)(""),[t,u]=(0,e.useState)(""),[v,w]=(0,e.useState)(!1),[x,y]=(0,e.useState)(""),[z,A]=(0,e.useState)(""),[B,C]=(0,e.useState)(""),[D,E]=(0,e.useState)("monthly"),[F,G]=(0,e.useState)("pending_payment"),[H,I]=(0,e.useState)("none"),[J,K]=(0,e.useState)("pending");async function L(a){if(a.preventDefault(),!f.L)return;o(!0),q("");let b=await f.L.functions.invoke("manage-platform-client",{body:{action:"create",name:r.trim(),email:x.trim(),slug:g(t),whatsapp:z.trim(),plan_id:B||null,billing_cycle:D,agency_status:F,subscription_status:H,implementation_status:J}});if(o(!1),b.error)return q(h(b.error));q("Imobili\xe1ria criada. O convite de acesso foi enviado ao e-mail do propriet\xe1rio."),window.setTimeout(()=>window.location.reload(),900)}async function M(a){if(a.preventDefault(),!f.L||!l)return;o(!0),q("");let b=await f.L.functions.invoke("manage-platform-client",{body:{action:"update_identity",agency_id:l.id,name:r.trim(),email:x.trim(),slug:g(t),whatsapp:z.trim()}});if(o(!1),b.error)return q(h(b.error));q("Cadastro atualizado."),window.setTimeout(()=>window.location.reload(),700)}return(0,e.useMemo)(()=>new Map(a.map(a=>[a.slug,a])),[a]),(0,d.jsxs)(d.Fragment,{children:[(0,d.jsx)("style",{children:`
        .platformCommercialPage .platformNewAgencyButton{
          margin-left:auto!important;min-height:42px!important;padding:0 17px!important;border:1px solid #d4a43d!important;border-radius:11px!important;background:#d9aa42!important;color:#11283d!important;font-size:13px!important;font-weight:900!important;cursor:pointer!important;white-space:nowrap!important
        }
        .platformCommercialPage .platformClientIdentityButton,
        .platformCommercialPage .platformClientAccessButton{
          display:flex!important;align-items:center!important;justify-content:center!important;width:190px!important;min-height:40px!important;margin:8px 0 0 auto!important;padding:0 16px!important;border-radius:11px!important;font-size:12px!important;font-weight:850!important;cursor:pointer!important
        }
        .platformCommercialPage .platformClientIdentityButton{border:1px solid #c9d4dd!important;background:#f7f9fb!important;color:#183149!important}
        .platformCommercialPage .platformClientAccessButton.isBlock{border:1px solid #e5c3a3!important;background:#fff9f1!important;color:#9a5b20!important}
        .platformCommercialPage .platformClientAccessButton.isRelease{border:1px solid #aad7bb!important;background:#f2fbf5!important;color:#247247!important}
        .platformClientAdminModal{position:fixed;inset:0;z-index:2147483100;display:grid;place-items:center;padding:20px;background:rgba(5,17,29,.72);backdrop-filter:blur(6px)}
        .platformClientAdminModal__card{width:min(94vw,720px);max-height:92vh;overflow:auto;box-sizing:border-box;padding:28px;border:1px solid #dfe6eb;border-radius:20px;background:#fff;box-shadow:0 28px 80px rgba(6,21,37,.28);color:#14293d}
        .platformClientAdminModal__head{display:flex;align-items:flex-start;justify-content:space-between;gap:18px;margin-bottom:20px}
        .platformClientAdminModal__head h3{margin:5px 0 0;font-size:25px}
        .platformClientAdminModal__eyebrow{color:#a77b25;font-size:11px;font-weight:900;letter-spacing:.1em}
        .platformClientAdminModal__close{width:38px;height:38px;border:1px solid #d7e0e7;border-radius:999px;background:#f7f9fa;color:#183149;font-size:22px;cursor:pointer}
        .platformClientAdminModal form{display:grid;gap:14px}
        .platformClientAdminModal__grid{display:grid;grid-template-columns:1fr 1fr;gap:14px}
        .platformClientAdminModal__grid.three{grid-template-columns:repeat(3,1fr)}
        .platformClientAdminModal label{display:grid;gap:7px;color:#405467;font-size:12px;font-weight:800}
        .platformClientAdminModal input,.platformClientAdminModal select{width:100%;min-height:44px;box-sizing:border-box;padding:9px 11px;border:1px solid #cdd7df;border-radius:10px;background:#fff;color:#13293d;font:inherit}
        .platformClientAdminModal__address{margin:-4px 0 4px;color:#71808d;font-size:12px}
        .platformClientAdminModal__actions{display:flex;justify-content:flex-end;gap:10px;margin-top:8px}
        .platformClientAdminModal__actions button{min-height:43px;padding:0 17px;border-radius:10px;font-weight:850;cursor:pointer}
        .platformClientAdminModal__cancel{border:1px solid #ccd6de;background:#f7f9fa;color:#22384d}
        .platformClientAdminModal__save{border:1px solid #d5a33b;background:#d9aa42;color:#10263d}
        .platformClientAdminModal__message{padding:11px 13px;border-radius:10px;background:#f3f7fa;color:#334b60;font-size:13px;font-weight:700}
        @media(max-width:720px){
          .platformCommercialPage .platformNewAgencyButton{width:100%;margin-left:0!important}
          .platformCommercialPage .platformClientIdentityButton,.platformCommercialPage .platformClientAccessButton{width:100%!important;margin-left:0!important}
          .platformClientAdminModal{padding:10px}
          .platformClientAdminModal__card{padding:20px}
          .platformClientAdminModal__grid,.platformClientAdminModal__grid.three{grid-template-columns:1fr}
          .platformClientAdminModal__actions{flex-direction:column-reverse}
          .platformClientAdminModal__actions button{width:100%}
        }
      `}),j?(0,d.jsx)("div",{className:"platformClientAdminModal",role:"dialog","aria-modal":"true",children:(0,d.jsxs)("div",{className:"platformClientAdminModal__card",children:[(0,d.jsxs)("div",{className:"platformClientAdminModal__head",children:[(0,d.jsxs)("div",{children:[(0,d.jsx)("span",{className:"platformClientAdminModal__eyebrow",children:"create"===j?"NOVO CLIENTE":"IDENTIFICA\xc7\xc3O DA IMOBILI\xc1RIA"}),(0,d.jsx)("h3",{children:"create"===j?"Cadastrar nova imobili\xe1ria":"Editar cadastro"})]}),(0,d.jsx)("button",{className:"platformClientAdminModal__close",type:"button",disabled:n,onClick:()=>k(null),children:"\xd7"})]}),(0,d.jsxs)("form",{onSubmit:"create"===j?L:M,children:[(0,d.jsxs)("div",{className:"platformClientAdminModal__grid",children:[(0,d.jsxs)("label",{children:["Nome da imobili\xe1ria",(0,d.jsx)("input",{required:!0,maxLength:160,value:r,onChange:a=>s(a.target.value)})]}),(0,d.jsxs)("label",{children:["E-mail do propriet\xe1rio",(0,d.jsx)("input",{required:!0,type:"email",maxLength:254,value:x,onChange:a=>y(a.target.value)})]})]}),(0,d.jsxs)("div",{className:"platformClientAdminModal__grid",children:[(0,d.jsxs)("label",{children:["Endere\xe7o / slug",(0,d.jsx)("input",{required:!0,maxLength:48,value:t,onChange:a=>{w(!0),u(a.target.value)}})]}),(0,d.jsxs)("label",{children:["WhatsApp",(0,d.jsx)("input",{maxLength:40,inputMode:"tel",value:z,onChange:a=>A(a.target.value)})]})]}),(0,d.jsxs)("div",{className:"platformClientAdminModal__address",children:[g(t)||"nova-imobiliaria",".imoveis.lenoy.com.br"]}),"create"===j?(0,d.jsxs)(d.Fragment,{children:[(0,d.jsxs)("div",{className:"platformClientAdminModal__grid three",children:[(0,d.jsxs)("label",{children:["Plano",(0,d.jsxs)("select",{value:B,onChange:a=>C(a.target.value),children:[(0,d.jsx)("option",{value:"",children:"Sem plano"}),c.map(a=>(0,d.jsx)("option",{value:a.id,children:a.name},a.id))]})]}),(0,d.jsxs)("label",{children:["Cobran\xe7a",(0,d.jsxs)("select",{value:D,onChange:a=>E(a.target.value),children:[(0,d.jsx)("option",{value:"monthly",children:"Mensal"}),(0,d.jsx)("option",{value:"annual",children:"Anual"})]})]}),(0,d.jsxs)("label",{children:["Implanta\xe7\xe3o",(0,d.jsxs)("select",{value:J,onChange:a=>K(a.target.value),children:[(0,d.jsx)("option",{value:"pending",children:"Pendente"}),(0,d.jsx)("option",{value:"paid",children:"Paga"}),(0,d.jsx)("option",{value:"waived",children:"Gr\xe1tis / dispensada"})]})]})]}),(0,d.jsxs)("div",{className:"platformClientAdminModal__grid",children:[(0,d.jsxs)("label",{children:["Acesso inicial",(0,d.jsxs)("select",{value:F,onChange:a=>G(a.target.value),children:[(0,d.jsx)("option",{value:"pending_payment",children:"Aguardando pagamento"}),(0,d.jsx)("option",{value:"active",children:"Liberado"}),(0,d.jsx)("option",{value:"trial",children:"Conta interna / teste"}),(0,d.jsx)("option",{value:"suspended",children:"Suspenso"})]})]}),(0,d.jsxs)("label",{children:["Assinatura",(0,d.jsxs)("select",{value:H,onChange:a=>I(a.target.value),children:[(0,d.jsx)("option",{value:"none",children:"Sem assinatura"}),(0,d.jsx)("option",{value:"active",children:"Ativa"}),(0,d.jsx)("option",{value:"trial",children:"Conta interna / teste"}),(0,d.jsx)("option",{value:"past_due",children:"Pagamento atrasado"})]})]})]}),(0,d.jsx)("div",{className:"platformClientAdminModal__message",children:"Ao salvar, o propriet\xe1rio receber\xe1 um convite no e-mail informado para acessar a nova imobili\xe1ria."})]}):(0,d.jsx)("div",{className:"platformClientAdminModal__message",children:"Plano, cobran\xe7a, vencimento e status continuam sendo editados pelo bot\xe3o “Editar cliente” que j\xe1 existe no card."}),p?(0,d.jsx)("div",{className:"platformClientAdminModal__message",children:p}):null,(0,d.jsxs)("div",{className:"platformClientAdminModal__actions",children:[(0,d.jsx)("button",{className:"platformClientAdminModal__cancel",type:"button",disabled:n,onClick:()=>k(null),children:"Cancelar"}),(0,d.jsx)("button",{className:"platformClientAdminModal__save",type:"submit",disabled:n,children:n?"Salvando...":"create"===j?"Criar imobili\xe1ria e enviar convite":"Salvar cadastro"})]})]})]})}):null]})}},45765:(a,b,c)=>{"use strict";c.d(b,{default:()=>g});var d=c(68903),e=c(67730),f=c(6040);function g(){let[a,b]=(0,e.useState)([]),[c,g]=(0,e.useState)(null),[h,i]=(0,e.useState)(""),[j,k]=(0,e.useState)(!1),[l,m]=(0,e.useState)("");async function n(){if(!c||!f.L||h.trim()!==c.name.trim())return;k(!0),m("");let a=await f.L.functions.invoke("delete-platform-client",{body:{agency_id:c.id,confirmation:h.trim()}});if(a.error){let b=a.error.message||"N\xe3o foi poss\xedvel excluir o usu\xe1rio.",c=a.error.context;if(c)try{let a=await c.clone().json();a?.error==="current_admin_account_protected"||a?.error==="platform_admin_account_protected"?b="Este usu\xe1rio est\xe1 protegido porque pertence \xe0 administra\xe7\xe3o da plataforma.":a?.error==="confirmation_mismatch"?b="O nome digitado n\xe3o confere com o cliente.":a?.detail&&(b=String(a.detail))}catch{}m(b),k(!1);return}k(!1),g(null),window.location.reload()}return(0,e.useMemo)(()=>new Map(a.map(a=>[a.slug,a])),[a]),(0,d.jsxs)(d.Fragment,{children:[(0,d.jsx)("style",{children:`
        .platformCommercialPage .commercialDeleteClientButton {
          display: flex !important;
          align-items: center !important;
          justify-content: center !important;
          width: 190px !important;
          min-height: 40px !important;
          margin: 8px 0 0 auto !important;
          padding: 0 16px !important;
          border: 1px solid #e5b4b0 !important;
          border-radius: 11px !important;
          background: #fff8f7 !important;
          color: #a63f38 !important;
          font-size: 12px !important;
          font-weight: 850 !important;
          cursor: pointer !important;
        }
        .platformCommercialPage .commercialDeleteClientButton:hover {
          border-color: #b84239 !important;
          background: #b84239 !important;
          color: #fff !important;
        }
        .platformDeleteModal {
          position: fixed;
          inset: 0;
          z-index: 2147483000;
          display: grid;
          place-items: center;
          padding: 20px;
          background: rgba(5, 17, 29, .72);
          backdrop-filter: blur(6px);
          -webkit-backdrop-filter: blur(6px);
        }
        .platformDeleteModal__card {
          width: min(92vw, 520px);
          padding: 28px;
          border: 1px solid #e4e9ed;
          border-radius: 20px;
          background: #fff;
          box-shadow: 0 28px 80px rgba(6, 21, 37, .28);
          color: #14293d;
        }
        .platformDeleteModal__eyebrow {
          color: #b84239;
          font-size: 11px;
          font-weight: 900;
          letter-spacing: .1em;
        }
        .platformDeleteModal__card h3 {
          margin: 7px 0 10px;
          font-size: 24px;
          line-height: 1.15;
        }
        .platformDeleteModal__card p {
          margin: 0 0 14px;
          color: #657586;
          font-size: 14px;
          line-height: 1.5;
        }
        .platformDeleteModal__warning {
          padding: 12px 14px;
          border: 1px solid #efd0cc;
          border-radius: 11px;
          background: #fff7f6;
          color: #8f3933 !important;
        }
        .platformDeleteModal__card label {
          display: grid;
          gap: 7px;
          margin-top: 18px;
          color: #405467;
          font-size: 12px;
          font-weight: 800;
        }
        .platformDeleteModal__card input {
          width: 100%;
          min-height: 44px;
          box-sizing: border-box;
          padding: 9px 11px;
          border: 1px solid #cdd7df;
          border-radius: 10px;
          background: #fff;
          color: #13293d;
          font-size: 14px;
        }
        .platformDeleteModal__message {
          margin-top: 12px !important;
          color: #a63f38 !important;
          font-weight: 700;
        }
        .platformDeleteModal__actions {
          display: flex;
          justify-content: flex-end;
          gap: 10px;
          margin-top: 22px;
        }
        .platformDeleteModal__actions button {
          min-height: 42px;
          padding: 0 16px;
          border-radius: 10px;
          font-size: 13px;
          font-weight: 850;
          cursor: pointer;
        }
        .platformDeleteModal__cancel {
          border: 1px solid #ccd6de;
          background: #f7f9fa;
          color: #22384d;
        }
        .platformDeleteModal__confirm {
          border: 1px solid #b84239;
          background: #b84239;
          color: #fff;
        }
        .platformDeleteModal__confirm:disabled {
          cursor: not-allowed;
          opacity: .45;
        }
        @media(max-width:720px){
          .platformCommercialPage .commercialDeleteClientButton { width: 100% !important; margin-left: 0 !important; }
          .platformDeleteModal__card { padding: 22px; }
          .platformDeleteModal__actions { flex-direction: column-reverse; }
          .platformDeleteModal__actions button { width: 100%; }
        }
      `}),c?(0,d.jsx)("div",{className:"platformDeleteModal",role:"dialog","aria-modal":"true","aria-labelledby":"platform-delete-title",children:(0,d.jsxs)("div",{className:"platformDeleteModal__card",children:[(0,d.jsx)("span",{className:"platformDeleteModal__eyebrow",children:"EXCLUS\xc3O PERMANENTE"}),(0,d.jsxs)("h3",{id:"platform-delete-title",children:["Excluir ",c.name,"?"]}),(0,d.jsx)("p",{className:"platformDeleteModal__warning",children:"Esta a\xe7\xe3o remove o cliente da plataforma, seus dados vinculados e os usu\xe1rios que n\xe3o perten\xe7am a outra imobili\xe1ria. N\xe3o pode ser desfeita."}),(0,d.jsx)("p",{children:"Para confirmar, digite exatamente o nome abaixo:"}),(0,d.jsx)("strong",{children:c.name}),(0,d.jsxs)("label",{children:["Confirma\xe7\xe3o",(0,d.jsx)("input",{autoFocus:!0,value:h,onChange:a=>i(a.target.value),disabled:j})]}),l?(0,d.jsx)("p",{className:"platformDeleteModal__message",children:l}):null,(0,d.jsxs)("div",{className:"platformDeleteModal__actions",children:[(0,d.jsx)("button",{className:"platformDeleteModal__cancel",type:"button",disabled:j,onClick:()=>g(null),children:"Cancelar"}),(0,d.jsx)("button",{className:"platformDeleteModal__confirm",type:"button",disabled:j||h.trim()!==c.name.trim(),onClick:()=>void n(),children:j?"Excluindo...":"Excluir definitivamente"})]})]})}):null]})}},75909:(a,b,c)=>{"use strict";c.d(b,{default:()=>d});let d=(0,c(88013).registerClientReference)(function(){throw Error("Attempted to call the default export of \"/home/runner/work/IMOBILIARIAS/IMOBILIARIAS/apps/web/components/PlatformClientAdminActions.tsx\" from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"/home/runner/work/IMOBILIARIAS/IMOBILIARIAS/apps/web/components/PlatformClientAdminActions.tsx","default")},78083:(a,b,c)=>{Promise.resolve().then(c.bind(c,39215)),Promise.resolve().then(c.bind(c,45765)),Promise.resolve().then(c.bind(c,16928))},78783:(a,b,c)=>{"use strict";c.d(b,{default:()=>d});let d=(0,c(88013).registerClientReference)(function(){throw Error("Attempted to call the default export of \"/home/runner/work/IMOBILIARIAS/IMOBILIARIAS/apps/web/components/PlatformClientDeleteControl.tsx\" from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"/home/runner/work/IMOBILIARIAS/IMOBILIARIAS/apps/web/components/PlatformClientDeleteControl.tsx","default")},90736:(a,b,c)=>{Promise.resolve().then(c.bind(c,75909)),Promise.resolve().then(c.bind(c,78783)),Promise.resolve().then(c.bind(c,97850))},96424:(a,b,c)=>{"use strict";c.r(b),c.d(b,{default:()=>h});var d=c(47033),e=c(97850),f=c(78783),g=c(75909);function h({children:a}){return(0,d.jsxs)(d.Fragment,{children:[a,(0,d.jsx)(e.default,{}),(0,d.jsx)(f.default,{}),(0,d.jsx)(g.default,{})]})}},97850:(a,b,c)=>{"use strict";c.d(b,{default:()=>d});let d=(0,c(88013).registerClientReference)(function(){throw Error("Attempted to call the default export of \"/home/runner/work/IMOBILIARIAS/IMOBILIARIAS/apps/web/components/PlatformClientVisualFix.tsx\" from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"/home/runner/work/IMOBILIARIAS/IMOBILIARIAS/apps/web/components/PlatformClientVisualFix.tsx","default")}};