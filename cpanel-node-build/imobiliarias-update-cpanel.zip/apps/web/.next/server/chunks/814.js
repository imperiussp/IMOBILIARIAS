exports.id=814,exports.ids=[814],exports.modules={6938:(a,b,c)=>{Promise.resolve().then(c.bind(c,19167)),Promise.resolve().then(c.bind(c,63418))},8502:(a,b,c)=>{"use strict";c.d(b,{default:()=>g});var d=c(14007),e=c(64898);c(89422);var f=c(22744);function g({children:a}){let[b,c]=(0,e.useState)("checking");async function h(){f.L&&await f.L.auth.signOut(),window.location.href="../login/"}return"checking"===b?(0,d.jsx)("main",{className:"loginPage",children:(0,d.jsx)("div",{className:"loginShell",children:(0,d.jsx)("div",{className:"loginCard",children:(0,d.jsx)("strong",{children:"Verificando administra\xe7\xe3o da plataforma..."})})})}):"wrong_backend"===b?(0,d.jsx)("main",{className:"loginPage",children:(0,d.jsx)("div",{className:"loginShell",children:(0,d.jsxs)("div",{className:"loginCard",children:[(0,d.jsx)("span",{className:"eyebrow",children:"PROTE\xc7\xc3O DE PROJETO"}),(0,d.jsx)("h1",{children:"Conex\xe3o bloqueada"}),(0,d.jsx)("p",{children:"O backend configurado n\xe3o pertence ao projeto IMOBILIARIAS."}),(0,d.jsx)("a",{className:"backLink",href:"../",children:"← Voltar"})]})})}):"blocked"===b?(0,d.jsx)("main",{className:"loginPage",children:(0,d.jsx)("div",{className:"loginShell",children:(0,d.jsxs)("div",{className:"loginCard",children:[(0,d.jsx)("span",{className:"eyebrow",children:"ADMINISTRA\xc7\xc3O LENOY"}),(0,d.jsx)("h1",{children:"Acesso n\xe3o autorizado"}),(0,d.jsx)("p",{children:"Esta \xe1rea \xe9 exclusiva da administra\xe7\xe3o global da plataforma."}),(0,d.jsx)("a",{className:"button primary full",href:"../admin/",children:"Ir para o painel da imobili\xe1ria"}),(0,d.jsx)("button",{className:"button secondary full",onClick:()=>void h(),children:"Sair"})]})})}):(0,d.jsxs)("div",{"data-platform-admin":"true",children:["demo"===b?(0,d.jsx)("div",{className:"demoAdminBanner",children:"Pr\xe9via da administra\xe7\xe3o global. O Supabase ainda n\xe3o est\xe1 conectado neste ambiente."}):(0,d.jsxs)("div",{className:"sessionBar",children:[(0,d.jsxs)("span",{children:[(0,d.jsx)("strong",{children:"LENOY IM\xd3VEIS"})," \xb7 Administra\xe7\xe3o da plataforma"]}),(0,d.jsx)("button",{onClick:()=>void h(),children:"Sair"})]}),a]})}},19167:(a,b,c)=>{"use strict";c.d(b,{default:()=>d});let d=(0,c(93661).registerClientReference)(function(){throw Error("Attempted to call the default export of \"/home/runner/work/IMOBILIARIAS/IMOBILIARIAS/apps/web/components/PlatformClientDeleteControl.tsx\" from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"/home/runner/work/IMOBILIARIAS/IMOBILIARIAS/apps/web/components/PlatformClientDeleteControl.tsx","default")},25381:(a,b,c)=>{"use strict";c.d(b,{default:()=>g});var d=c(14007),e=c(64898),f=c(22744);function g(){let[a,b]=(0,e.useState)([]),[c,g]=(0,e.useState)(null),[h,i]=(0,e.useState)(""),[j,k]=(0,e.useState)(!1),[l,m]=(0,e.useState)("");async function n(){if(!c||!f.L||h.trim()!==c.name.trim())return;k(!0),m("");let a=await f.L.functions.invoke("delete-platform-client",{body:{agency_id:c.id,confirmation:h.trim()}});if(a.error){let b=a.error.message||"N\xe3o foi poss\xedvel excluir o usu\xe1rio.",c=a.error.context;if(c)try{let a=await c.clone().json();a?.error==="current_admin_account_protected"||a?.error==="platform_admin_account_protected"?b="Este usu\xe1rio est\xe1 protegido porque pertence \xe0 administra\xe7\xe3o da plataforma.":a?.error==="confirmation_mismatch"?b="O nome digitado n\xe3o confere com o cliente.":a?.detail&&(b=String(a.detail))}catch{}m(b),k(!1);return}k(!1),g(null),window.location.reload()}return(0,e.useMemo)(()=>new Map(a.map(a=>[a.slug,a])),[a]),(0,d.jsxs)(d.Fragment,{children:[(0,d.jsx)("style",{children:`
        .platformCommercialPage .commercialDeleteClientButton {
          display: flex !important;
          align-items: center !important;
          justify-content: center !important;
          width: 190px !important;
          min-height: 40px !important;
          margin: 8px 0 0 auto !important;
          padding: 0 16px !important;
          border: 1px solid #e5b4b0 !important;
          border-radius: 11px !important;
          background: #fff8f7 !important;
          color: #a63f38 !important;
          font-size: 12px !important;
          font-weight: 850 !important;
          cursor: pointer !important;
        }
        .platformCommercialPage .commercialDeleteClientButton:hover {
          border-color: #b84239 !important;
          background: #b84239 !important;
          color: #fff !important;
        }
        .platformDeleteModal {
          position: fixed;
          inset: 0;
          z-index: 2147483000;
          display: grid;
          place-items: center;
          padding: 20px;
          background: rgba(5, 17, 29, .72);
          backdrop-filter: blur(6px);
          -webkit-backdrop-filter: blur(6px);
        }
        .platformDeleteModal__card {
          width: min(92vw, 520px);
          padding: 28px;
          border: 1px solid #e4e9ed;
          border-radius: 20px;
          background: #fff;
          box-shadow: 0 28px 80px rgba(6, 21, 37, .28);
          color: #14293d;
        }
        .platformDeleteModal__eyebrow {
          color: #b84239;
          font-size: 11px;
          font-weight: 900;
          letter-spacing: .1em;
        }
        .platformDeleteModal__card h3 {
          margin: 7px 0 10px;
          font-size: 24px;
          line-height: 1.15;
        }
        .platformDeleteModal__card p {
          margin: 0 0 14px;
          color: #657586;
          font-size: 14px;
          line-height: 1.5;
        }
        .platformDeleteModal__warning {
          padding: 12px 14px;
          border: 1px solid #efd0cc;
          border-radius: 11px;
          background: #fff7f6;
          color: #8f3933 !important;
        }
        .platformDeleteModal__card label {
          display: grid;
          gap: 7px;
          margin-top: 18px;
          color: #405467;
          font-size: 12px;
          font-weight: 800;
        }
        .platformDeleteModal__card input {
          width: 100%;
          min-height: 44px;
          box-sizing: border-box;
          padding: 9px 11px;
          border: 1px solid #cdd7df;
          border-radius: 10px;
          background: #fff;
          color: #13293d;
          font-size: 14px;
        }
        .platformDeleteModal__message {
          margin-top: 12px !important;
          color: #a63f38 !important;
          font-weight: 700;
        }
        .platformDeleteModal__actions {
          display: flex;
          justify-content: flex-end;
          gap: 10px;
          margin-top: 22px;
        }
        .platformDeleteModal__actions button {
          min-height: 42px;
          padding: 0 16px;
          border-radius: 10px;
          font-size: 13px;
          font-weight: 850;
          cursor: pointer;
        }
        .platformDeleteModal__cancel {
          border: 1px solid #ccd6de;
          background: #f7f9fa;
          color: #22384d;
        }
        .platformDeleteModal__confirm {
          border: 1px solid #b84239;
          background: #b84239;
          color: #fff;
        }
        .platformDeleteModal__confirm:disabled {
          cursor: not-allowed;
          opacity: .45;
        }
        @media(max-width:720px){
          .platformCommercialPage .commercialDeleteClientButton { width: 100% !important; margin-left: 0 !important; }
          .platformDeleteModal__card { padding: 22px; }
          .platformDeleteModal__actions { flex-direction: column-reverse; }
          .platformDeleteModal__actions button { width: 100%; }
        }
      `}),c?(0,d.jsx)("div",{className:"platformDeleteModal",role:"dialog","aria-modal":"true","aria-labelledby":"platform-delete-title",children:(0,d.jsxs)("div",{className:"platformDeleteModal__card",children:[(0,d.jsx)("span",{className:"platformDeleteModal__eyebrow",children:"EXCLUS\xc3O PERMANENTE"}),(0,d.jsxs)("h3",{id:"platform-delete-title",children:["Excluir ",c.name,"?"]}),(0,d.jsx)("p",{className:"platformDeleteModal__warning",children:"Esta a\xe7\xe3o remove o cliente da plataforma, seus dados vinculados e os usu\xe1rios que n\xe3o perten\xe7am a outra imobili\xe1ria. N\xe3o pode ser desfeita."}),(0,d.jsx)("p",{children:"Para confirmar, digite exatamente o nome abaixo:"}),(0,d.jsx)("strong",{children:c.name}),(0,d.jsxs)("label",{children:["Confirma\xe7\xe3o",(0,d.jsx)("input",{autoFocus:!0,value:h,onChange:a=>i(a.target.value),disabled:j})]}),l?(0,d.jsx)("p",{className:"platformDeleteModal__message",children:l}):null,(0,d.jsxs)("div",{className:"platformDeleteModal__actions",children:[(0,d.jsx)("button",{className:"platformDeleteModal__cancel",type:"button",disabled:j,onClick:()=>g(null),children:"Cancelar"}),(0,d.jsx)("button",{className:"platformDeleteModal__confirm",type:"button",disabled:j||h.trim()!==c.name.trim(),onClick:()=>void n(),children:j?"Excluindo...":"Excluir definitivamente"})]})]})}):null]})}},42152:(a,b,c)=>{"use strict";c.r(b),c.d(b,{default:()=>g});var d=c(89385),e=c(63418),f=c(19167);function g({children:a}){return(0,d.jsxs)(d.Fragment,{children:[a,(0,d.jsx)(e.default,{}),(0,d.jsx)(f.default,{})]})}},47106:(a,b,c)=>{Promise.resolve().then(c.bind(c,25381)),Promise.resolve().then(c.bind(c,72288))},50020:(a,b,c)=>{"use strict";c.d(b,{default:()=>d});let d=(0,c(93661).registerClientReference)(function(){throw Error("Attempted to call the default export of \"/home/runner/work/IMOBILIARIAS/IMOBILIARIAS/apps/web/components/PlatformAdminGate.tsx\" from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"/home/runner/work/IMOBILIARIAS/IMOBILIARIAS/apps/web/components/PlatformAdminGate.tsx","default")},63418:(a,b,c)=>{"use strict";c.d(b,{default:()=>d});let d=(0,c(93661).registerClientReference)(function(){throw Error("Attempted to call the default export of \"/home/runner/work/IMOBILIARIAS/IMOBILIARIAS/apps/web/components/PlatformClientVisualFix.tsx\" from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"/home/runner/work/IMOBILIARIAS/IMOBILIARIAS/apps/web/components/PlatformClientVisualFix.tsx","default")},72288:(a,b,c)=>{"use strict";c.d(b,{default:()=>e});var d=c(14007);function e(){return(0,d.jsx)("style",{children:`
      @media (min-width: 1101px) {
        html body .platformCommercialPage.platformCommercialPage .commercialClientsPanel .commercialClientGrid {
          display: grid !important;
          grid-template-columns: repeat(2, minmax(0, 1fr)) !important;
          gap: 16px !important;
        }

        html body .platformCommercialPage.platformCommercialPage .commercialClientsPanel .commercialClientCard.isEditing {
          grid-column: 1 / -1 !important;
        }
      }

      @media (max-width: 1100px) {
        html body .platformCommercialPage.platformCommercialPage .commercialClientsPanel .commercialClientGrid {
          grid-template-columns: 1fr !important;
        }

        html body .platformCommercialPage.platformCommercialPage .commercialClientsPanel .commercialClientCard.isEditing {
          grid-column: auto !important;
        }
      }

      html body .platformCommercialPage.platformCommercialPage .commercialClientHeader .commercialClientIdentityVisual {
        position: relative !important;
        min-height: 50px !important;
        padding-left: 62px !important;
        align-content: center !important;
      }

      html body .platformCommercialPage.platformCommercialPage .commercialClientHeader .commercialClientIdentityVisual::before {
        content: "" !important;
        position: absolute !important;
        left: 0 !important;
        top: 0 !important;
        width: 48px !important;
        height: 48px !important;
        border-radius: 999px !important;
        background-color: #102a45 !important;
        background-image: var(--platform-client-avatar) !important;
        background-position: center !important;
        background-repeat: no-repeat !important;
        background-size: cover !important;
        border: 2px solid #fff !important;
        box-shadow: 0 0 0 1px #d9e2e9, 0 4px 12px rgba(16, 42, 69, .12) !important;
      }
    `})}c(64898),c(22744)}};