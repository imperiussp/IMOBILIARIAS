(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[8829],{455:(e,t,r)=>{Promise.resolve().then(r.bind(r,2749)),Promise.resolve().then(r.bind(r,49096))},2749:(e,t,r)=>{"use strict";r.d(t,{default:()=>l});var a=r(50810),o=r(7442),i=r(47776);function l(){let[e,t]=(0,o.useState)([]),[r,l]=(0,o.useState)(null),[n,m]=(0,o.useState)(""),[d,c]=(0,o.useState)(!1),[p,s]=(0,o.useState)(""),f=(0,o.useMemo)(()=>new Map(e.map(e=>[e.slug,e])),[e]);async function u(){if(!r||!i.L||n.trim()!==r.name.trim())return;c(!0),s("");let e=await i.L.functions.invoke("delete-platform-client",{body:{agency_id:r.id,confirmation:n.trim()}});if(e.error){let t=e.error.message||"N\xe3o foi poss\xedvel excluir o usu\xe1rio.",r=e.error.context;if(r)try{let e=await r.clone().json();e?.error==="current_admin_account_protected"||e?.error==="platform_admin_account_protected"?t="Este usu\xe1rio est\xe1 protegido porque pertence \xe0 administra\xe7\xe3o da plataforma.":e?.error==="confirmation_mismatch"?t="O nome digitado n\xe3o confere com o cliente.":e?.detail&&(t=String(e.detail))}catch{}s(t),c(!1);return}c(!1),l(null),window.location.reload()}return(0,o.useEffect)(()=>{"/plataforma"!==window.location.pathname||i.L&&i.$&&(async()=>{let e=await i.L.from("agencies").select("id,name,slug").order("created_at",{ascending:!1});e.error||t(e.data||[])})()},[]),(0,o.useEffect)(()=>{if("/plataforma"!==window.location.pathname)return;let e=()=>{Array.from(document.querySelectorAll(".platformCommercialPage .commercialClientCard")).forEach(e=>{if(e.querySelector(".commercialDeleteClientButton"))return;let t=e.querySelector(".commercialClientHeader small")?.textContent?.trim()||"",r=t.split(".")[0]?.trim()||"",a=f.get(r);if(!a)return;let o=e.querySelector(".commercialEditClientButton");if(!o)return;let i=document.createElement("button");i.type="button",i.className="commercialDeleteClientButton",i.textContent="Excluir usu\xe1rio",i.addEventListener("click",()=>{s(""),m(""),l(a)}),o.insertAdjacentElement("afterend",i)})};e();let t=new MutationObserver(e);return t.observe(document.body,{childList:!0,subtree:!0}),()=>t.disconnect()},[f]),(0,o.useEffect)(()=>{if(!r)return;let e=document.body.style.overflow;document.body.style.overflow="hidden";let t=e=>{"Escape"!==e.key||d||l(null)};return window.addEventListener("keydown",t),()=>{document.body.style.overflow=e,window.removeEventListener("keydown",t)}},[r,d]),(0,a.jsxs)(a.Fragment,{children:[(0,a.jsx)("style",{children:`
        .platformCommercialPage .commercialDeleteClientButton {
          display: flex !important;
          align-items: center !important;
          justify-content: center !important;
          width: 190px !important;
          min-height: 40px !important;
          margin: 8px 0 0 auto !important;
          padding: 0 16px !important;
          border: 1px solid #e5b4b0 !important;
          border-radius: 11px !important;
          background: #fff8f7 !important;
          color: #a63f38 !important;
          font-size: 12px !important;
          font-weight: 850 !important;
          cursor: pointer !important;
        }
        .platformCommercialPage .commercialDeleteClientButton:hover {
          border-color: #b84239 !important;
          background: #b84239 !important;
          color: #fff !important;
        }
        .platformDeleteModal {
          position: fixed;
          inset: 0;
          z-index: 2147483000;
          display: grid;
          place-items: center;
          padding: 20px;
          background: rgba(5, 17, 29, .72);
          backdrop-filter: blur(6px);
          -webkit-backdrop-filter: blur(6px);
        }
        .platformDeleteModal__card {
          width: min(92vw, 520px);
          padding: 28px;
          border: 1px solid #e4e9ed;
          border-radius: 20px;
          background: #fff;
          box-shadow: 0 28px 80px rgba(6, 21, 37, .28);
          color: #14293d;
        }
        .platformDeleteModal__eyebrow {
          color: #b84239;
          font-size: 11px;
          font-weight: 900;
          letter-spacing: .1em;
        }
        .platformDeleteModal__card h3 {
          margin: 7px 0 10px;
          font-size: 24px;
          line-height: 1.15;
        }
        .platformDeleteModal__card p {
          margin: 0 0 14px;
          color: #657586;
          font-size: 14px;
          line-height: 1.5;
        }
        .platformDeleteModal__warning {
          padding: 12px 14px;
          border: 1px solid #efd0cc;
          border-radius: 11px;
          background: #fff7f6;
          color: #8f3933 !important;
        }
        .platformDeleteModal__card label {
          display: grid;
          gap: 7px;
          margin-top: 18px;
          color: #405467;
          font-size: 12px;
          font-weight: 800;
        }
        .platformDeleteModal__card input {
          width: 100%;
          min-height: 44px;
          box-sizing: border-box;
          padding: 9px 11px;
          border: 1px solid #cdd7df;
          border-radius: 10px;
          background: #fff;
          color: #13293d;
          font-size: 14px;
        }
        .platformDeleteModal__message {
          margin-top: 12px !important;
          color: #a63f38 !important;
          font-weight: 700;
        }
        .platformDeleteModal__actions {
          display: flex;
          justify-content: flex-end;
          gap: 10px;
          margin-top: 22px;
        }
        .platformDeleteModal__actions button {
          min-height: 42px;
          padding: 0 16px;
          border-radius: 10px;
          font-size: 13px;
          font-weight: 850;
          cursor: pointer;
        }
        .platformDeleteModal__cancel {
          border: 1px solid #ccd6de;
          background: #f7f9fa;
          color: #22384d;
        }
        .platformDeleteModal__confirm {
          border: 1px solid #b84239;
          background: #b84239;
          color: #fff;
        }
        .platformDeleteModal__confirm:disabled {
          cursor: not-allowed;
          opacity: .45;
        }
        @media(max-width:720px){
          .platformCommercialPage .commercialDeleteClientButton { width: 100% !important; margin-left: 0 !important; }
          .platformDeleteModal__card { padding: 22px; }
          .platformDeleteModal__actions { flex-direction: column-reverse; }
          .platformDeleteModal__actions button { width: 100%; }
        }
      `}),r?(0,a.jsx)("div",{className:"platformDeleteModal",role:"dialog","aria-modal":"true","aria-labelledby":"platform-delete-title",children:(0,a.jsxs)("div",{className:"platformDeleteModal__card",children:[(0,a.jsx)("span",{className:"platformDeleteModal__eyebrow",children:"EXCLUS\xc3O PERMANENTE"}),(0,a.jsxs)("h3",{id:"platform-delete-title",children:["Excluir ",r.name,"?"]}),(0,a.jsx)("p",{className:"platformDeleteModal__warning",children:"Esta a\xe7\xe3o remove o cliente da plataforma, seus dados vinculados e os usu\xe1rios que n\xe3o perten\xe7am a outra imobili\xe1ria. N\xe3o pode ser desfeita."}),(0,a.jsx)("p",{children:"Para confirmar, digite exatamente o nome abaixo:"}),(0,a.jsx)("strong",{children:r.name}),(0,a.jsxs)("label",{children:["Confirma\xe7\xe3o",(0,a.jsx)("input",{autoFocus:!0,value:n,onChange:e=>m(e.target.value),disabled:d})]}),p?(0,a.jsx)("p",{className:"platformDeleteModal__message",children:p}):null,(0,a.jsxs)("div",{className:"platformDeleteModal__actions",children:[(0,a.jsx)("button",{className:"platformDeleteModal__cancel",type:"button",disabled:d,onClick:()=>l(null),children:"Cancelar"}),(0,a.jsx)("button",{className:"platformDeleteModal__confirm",type:"button",disabled:d||n.trim()!==r.name.trim(),onClick:()=>void u(),children:d?"Excluindo...":"Excluir definitivamente"})]})]})}):null]})}},47776:(e,t,r)=>{"use strict";r.d(t,{$:()=>l,L:()=>n});var a=r(26998);let o="https://rvjsonspplqelktzwusu.supabase.co",i="sb_publishable_jhqdOH3X4FPkxjKTY-EnUQ_37mUhy4z",l=!!(o&&i),n=l?(0,a.UU)(o,i):null},49096:(e,t,r)=>{"use strict";r.d(t,{default:()=>l});var a=r(50810),o=r(7442),i=r(47776);function l(){return(0,o.useEffect)(()=>{if("/plataforma"!==window.location.pathname)return;let e=!1,t=new Map,r=new Map,a=()=>{e||Array.from(document.querySelectorAll(".platformCommercialPage .commercialClientCard")).forEach(e=>{let a,o,i=e.querySelector(".commercialClientHeader"),l=i?.querySelector(":scope > div");if(!l)return;let n=l.querySelector("strong")?.textContent?.trim()||"Cliente",m=l.querySelector("small")?.textContent?.trim()||"",d=m.split(".")[0]?.trim()||"",c=d?t.get(d):void 0,p=c?.logo_url?.trim()||(c?r.get(c.id):void 0)||(a=(n.trim().split(/\s+/).filter(Boolean).slice(0,2).map(e=>e[0]?.toUpperCase()||"").join("")||"CL").replace(/[<>&"']/g,""),o=`<svg xmlns="http://www.w3.org/2000/svg" width="96" height="96" viewBox="0 0 96 96"><rect width="96" height="96" rx="48" fill="#102a45"/><circle cx="70" cy="24" r="22" fill="#d4a640" opacity=".22"/><text x="48" y="57" text-anchor="middle" font-family="Arial,sans-serif" font-size="31" font-weight="700" fill="#ffffff">${a}</text></svg>`,`data:image/svg+xml;charset=UTF-8,${encodeURIComponent(o)}`);l.classList.add("commercialClientIdentityVisual"),l.style.setProperty("--platform-client-avatar",`url("${p.replace(/\\/g,"\\\\").replace(/"/g,'\\"')}")`)})};a();let o=new MutationObserver(()=>a());return o.observe(document.body,{childList:!0,subtree:!0}),(async()=>{if(!i.L||!i.$)return;let e=await i.L.from("agencies").select("id,slug,name,logo_url");!e.error&&e.data&&(t=new Map(e.data.map(e=>[e.slug,e])));let o=await i.L.from("brokers").select("agency_id,photo_url,active").not("photo_url","is",null);if(!o.error&&o.data){let e=new Map;o.data.sort((e,t)=>Number(!!t.active)-Number(!!e.active)).forEach(t=>{!t.agency_id||!t.photo_url?.trim()||e.has(t.agency_id)||e.set(t.agency_id,t.photo_url.trim())}),r=e}a()})(),()=>{e=!0,o.disconnect()}},[]),(0,a.jsx)("style",{children:`
      @media (min-width: 1101px) {
        html body .platformCommercialPage.platformCommercialPage .commercialClientsPanel .commercialClientGrid {
          display: grid !important;
          grid-template-columns: repeat(2, minmax(0, 1fr)) !important;
          gap: 16px !important;
        }

        html body .platformCommercialPage.platformCommercialPage .commercialClientsPanel .commercialClientCard.isEditing {
          grid-column: 1 / -1 !important;
        }
      }

      @media (max-width: 1100px) {
        html body .platformCommercialPage.platformCommercialPage .commercialClientsPanel .commercialClientGrid {
          grid-template-columns: 1fr !important;
        }

        html body .platformCommercialPage.platformCommercialPage .commercialClientsPanel .commercialClientCard.isEditing {
          grid-column: auto !important;
        }
      }

      html body .platformCommercialPage.platformCommercialPage .commercialClientHeader .commercialClientIdentityVisual {
        position: relative !important;
        min-height: 50px !important;
        padding-left: 62px !important;
        align-content: center !important;
      }

      html body .platformCommercialPage.platformCommercialPage .commercialClientHeader .commercialClientIdentityVisual::before {
        content: "" !important;
        position: absolute !important;
        left: 0 !important;
        top: 0 !important;
        width: 48px !important;
        height: 48px !important;
        border-radius: 999px !important;
        background-color: #102a45 !important;
        background-image: var(--platform-client-avatar) !important;
        background-position: center !important;
        background-repeat: no-repeat !important;
        background-size: cover !important;
        border: 2px solid #fff !important;
        box-shadow: 0 0 0 1px #d9e2e9, 0 4px 12px rgba(16, 42, 69, .12) !important;
      }
    `})}}},e=>{e.O(0,[2099,1082,2232,6660,7358],()=>e(e.s=455)),_N_E=e.O()}]);