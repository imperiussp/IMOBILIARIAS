(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[8829],{5066:(t,e,a)=>{"use strict";a.d(e,{default:()=>l});var r=a(5293),i=a(1017),o=a(5522);function l(){return(0,i.useEffect)(()=>{if("/plataforma"!==window.location.pathname)return;let t=!1,e=new Map,a=new Map,r=()=>{t||Array.from(document.querySelectorAll(".platformCommercialPage .commercialClientCard")).forEach(t=>{let r,i,o=t.querySelector(".commercialClientHeader"),l=o?.querySelector(":scope > div");if(!l)return;let m=l.querySelector("strong")?.textContent?.trim()||"Cliente",n=l.querySelector("small")?.textContent?.trim()||"",c=n.split(".")[0]?.trim()||"",p=c?e.get(c):void 0,s=p?.logo_url?.trim()||(p?a.get(p.id):void 0)||(r=(m.trim().split(/\s+/).filter(Boolean).slice(0,2).map(t=>t[0]?.toUpperCase()||"").join("")||"CL").replace(/[<>&"']/g,""),i=`<svg xmlns="http://www.w3.org/2000/svg" width="96" height="96" viewBox="0 0 96 96"><rect width="96" height="96" rx="48" fill="#102a45"/><circle cx="70" cy="24" r="22" fill="#d4a640" opacity=".22"/><text x="48" y="57" text-anchor="middle" font-family="Arial,sans-serif" font-size="31" font-weight="700" fill="#ffffff">${r}</text></svg>`,`data:image/svg+xml;charset=UTF-8,${encodeURIComponent(i)}`);l.classList.add("commercialClientIdentityVisual"),l.style.setProperty("--platform-client-avatar",`url("${s.replace(/\\/g,"\\\\").replace(/"/g,'\\"')}")`)})};r();let i=new MutationObserver(()=>r());return i.observe(document.body,{childList:!0,subtree:!0}),(async()=>{if(!o.L||!o.$)return;let t=await o.L.from("agencies").select("id,slug,name,logo_url");!t.error&&t.data&&(e=new Map(t.data.map(t=>[t.slug,t])));let i=await o.L.from("brokers").select("agency_id,photo_url,active").not("photo_url","is",null);if(!i.error&&i.data){let t=new Map;i.data.sort((t,e)=>Number(!!e.active)-Number(!!t.active)).forEach(e=>{!e.agency_id||!e.photo_url?.trim()||t.has(e.agency_id)||t.set(e.agency_id,e.photo_url.trim())}),a=t}r()})(),()=>{t=!0,i.disconnect()}},[]),(0,r.jsx)("style",{children:`
      @media (min-width: 1101px) {
        html body .platformCommercialPage.platformCommercialPage .commercialClientsPanel .commercialClientGrid {
          display: grid !important;
          grid-template-columns: repeat(2, minmax(0, 1fr)) !important;
          gap: 16px !important;
        }

        html body .platformCommercialPage.platformCommercialPage .commercialClientsPanel .commercialClientCard.isEditing {
          grid-column: 1 / -1 !important;
        }
      }

      @media (max-width: 1100px) {
        html body .platformCommercialPage.platformCommercialPage .commercialClientsPanel .commercialClientGrid {
          grid-template-columns: 1fr !important;
        }

        html body .platformCommercialPage.platformCommercialPage .commercialClientsPanel .commercialClientCard.isEditing {
          grid-column: auto !important;
        }
      }

      html body .platformCommercialPage.platformCommercialPage .commercialClientHeader .commercialClientIdentityVisual {
        position: relative !important;
        min-height: 50px !important;
        padding-left: 62px !important;
        align-content: center !important;
      }

      html body .platformCommercialPage.platformCommercialPage .commercialClientHeader .commercialClientIdentityVisual::before {
        content: "" !important;
        position: absolute !important;
        left: 0 !important;
        top: 0 !important;
        width: 48px !important;
        height: 48px !important;
        border-radius: 999px !important;
        background-color: #102a45 !important;
        background-image: var(--platform-client-avatar) !important;
        background-position: center !important;
        background-repeat: no-repeat !important;
        background-size: cover !important;
        border: 2px solid #fff !important;
        box-shadow: 0 0 0 1px #d9e2e9, 0 4px 12px rgba(16, 42, 69, .12) !important;
      }
    `})}},5522:(t,e,a)=>{"use strict";a.d(e,{$:()=>l,L:()=>m});var r=a(8932);let i="https://rvjsonspplqelktzwusu.supabase.co",o="sb_publishable_jhqdOH3X4FPkxjKTY-EnUQ_37mUhy4z",l=!!(i&&o),m=l?(0,r.UU)(i,o):null},7830:(t,e,a)=>{Promise.resolve().then(a.bind(a,5066))}},t=>{t.O(0,[2099,6424,5408,7810,7358],()=>t(t.s=7830)),_N_E=t.O()}]);