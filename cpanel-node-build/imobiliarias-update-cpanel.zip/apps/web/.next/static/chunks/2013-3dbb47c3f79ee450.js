"use strict";(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[2013],{20994:(e,t,a)=>{a.d(t,{$:()=>i,L:()=>l});var o=a(53462);let n="https://rvjsonspplqelktzwusu.supabase.co",r="sb_publishable_jhqdOH3X4FPkxjKTY-EnUQ_37mUhy4z",i=!!(n&&r),l=i?(0,o.UU)(n,r):null},36103:(e,t,a)=>{a.d(t,{default:()=>d});var o=a(87277),n=a(85529),r=a(20994);function i(e){return e.normalize("NFD").replace(/[\u0300-\u036f]/g,"").toLowerCase().replace(/[^a-z0-9]+/g,"-").replace(/^-+|-+$/g,"").replace(/-+/g,"-").slice(0,48)}function l(e){return e?.message||"N\xe3o foi poss\xedvel concluir a opera\xe7\xe3o."}function d(){let[e,t]=(0,n.useState)([]),[a,d]=(0,n.useState)([]),[s,m]=(0,n.useState)(null),[c,p]=(0,n.useState)(null),[u,f]=(0,n.useState)(!1),[x,g]=(0,n.useState)(""),[b,h]=(0,n.useState)(""),[_,v]=(0,n.useState)(""),[C,w]=(0,n.useState)(!1),[y,j]=(0,n.useState)(""),[M,A]=(0,n.useState)(""),[E,k]=(0,n.useState)(""),[N,S]=(0,n.useState)("monthly"),[D,L]=(0,n.useState)("pending_payment"),[B,P]=(0,n.useState)("none"),[z,q]=(0,n.useState)("pending"),I=(0,n.useMemo)(()=>new Map(e.map(e=>[e.slug,e])),[e]);async function O(){if(!r.L||!r.$)return;let[e,a]=await Promise.all([r.L.from("agencies").select("id,name,slug,email,whatsapp,status").order("created_at",{ascending:!1}),r.L.from("subscription_plans").select("id,name,code,active").eq("active",!0).order("display_order")]);e.error||t(e.data||[]),a.error||d((a.data||[]).filter(e=>"homologacao"!==e.code))}function F(){p(null),h(""),v(""),w(!1),j(""),A(""),k(""),S("monthly"),L("pending_payment"),P("none"),q("pending"),g(""),m("create")}async function $(e){if(e.preventDefault(),!r.L)return;f(!0),g("");let t=await r.L.functions.invoke("manage-platform-client",{body:{action:"create",name:b.trim(),email:y.trim(),slug:i(_),whatsapp:M.trim(),plan_id:E||null,billing_cycle:N,agency_status:D,subscription_status:B,implementation_status:z}});if(f(!1),t.error)return g(l(t.error));g("Imobili\xe1ria criada. O convite de acesso foi enviado ao e-mail do propriet\xe1rio."),window.setTimeout(()=>window.location.reload(),900)}async function T(e){if(e.preventDefault(),!r.L||!c)return;f(!0),g("");let t=await r.L.functions.invoke("manage-platform-client",{body:{action:"update_identity",agency_id:c.id,name:b.trim(),email:y.trim(),slug:i(_),whatsapp:M.trim()}});if(f(!1),t.error)return g(l(t.error));g("Cadastro atualizado."),window.setTimeout(()=>window.location.reload(),700)}return(0,n.useEffect)(()=>{"/plataforma"===window.location.pathname&&O()},[]),(0,n.useEffect)(()=>{if(!s)return;let e=document.body.style.overflow,t=e=>{"Escape"!==e.key||u||m(null)};return document.body.style.overflow="hidden",window.addEventListener("keydown",t),()=>{document.body.style.overflow=e,window.removeEventListener("keydown",t)}},[s,u]),(0,n.useEffect)(()=>{"create"!==s||C||v(i(b))},[b,C,s]),(0,n.useEffect)(()=>{if("/plataforma"!==window.location.pathname)return;let e=()=>{let e=document.querySelector(".platformCommercialPage .commercialClientsPanel .adminPanelHeader");if(e&&!e.querySelector(".platformNewAgencyButton")){let t=document.createElement("button");t.type="button",t.className="platformNewAgencyButton",t.textContent="+ Nova imobili\xe1ria",t.addEventListener("click",F),e.appendChild(t)}Array.from(document.querySelectorAll(".platformCommercialPage .commercialClientCard")).forEach(e=>{if(e.querySelector(".platformClientIdentityButton"))return;let t=e.querySelector(".commercialClientHeader small")?.textContent?.trim()||"",a=t.split(".")[0]?.trim()||"",o=I.get(a);if(!o)return;let n=e.querySelector(".commercialEditClientButton");if(!n)return;let i=document.createElement("button");i.type="button",i.className="platformClientIdentityButton",i.textContent="Editar cadastro",i.addEventListener("click",()=>{p(o),h(o.name),v(o.slug),w(!0),j(o.email||""),A(o.whatsapp||""),g(""),m("edit")}),n.insertAdjacentElement("afterend",i);let l=document.createElement("button");l.type="button",l.className=`platformClientAccessButton ${"suspended"===o.status||"cancelled"===o.status?"isRelease":"isBlock"}`,l.textContent="suspended"===o.status||"cancelled"===o.status?"Liberar acesso":"Bloquear acesso",l.addEventListener("click",async()=>{if(!r.L)return;let e="suspended"===o.status||"cancelled"===o.status?"active":"suspended";if(!window.confirm("suspended"===e?`Bloquear o acesso de ${o.name}?`:`Liberar novamente o acesso de ${o.name}?`))return;l.disabled=!0;let t=await r.L.rpc("platform_set_agency_status",{p_agency_id:o.id,p_status:e});if(t.error){window.alert(t.error.message),l.disabled=!1;return}window.location.reload()}),i.insertAdjacentElement("afterend",l)})};e();let t=new MutationObserver(e);return t.observe(document.body,{childList:!0,subtree:!0}),()=>t.disconnect()},[I]),(0,o.jsxs)(o.Fragment,{children:[(0,o.jsx)("style",{children:`
        .platformCommercialPage .platformNewAgencyButton{
          margin-left:auto!important;min-height:42px!important;padding:0 17px!important;border:1px solid #d4a43d!important;border-radius:11px!important;background:#d9aa42!important;color:#11283d!important;font-size:13px!important;font-weight:900!important;cursor:pointer!important;white-space:nowrap!important
        }
        .platformCommercialPage .platformClientIdentityButton,
        .platformCommercialPage .platformClientAccessButton{
          display:flex!important;align-items:center!important;justify-content:center!important;width:190px!important;min-height:40px!important;margin:8px 0 0 auto!important;padding:0 16px!important;border-radius:11px!important;font-size:12px!important;font-weight:850!important;cursor:pointer!important
        }
        .platformCommercialPage .platformClientIdentityButton{border:1px solid #c9d4dd!important;background:#f7f9fb!important;color:#183149!important}
        .platformCommercialPage .platformClientAccessButton.isBlock{border:1px solid #e5c3a3!important;background:#fff9f1!important;color:#9a5b20!important}
        .platformCommercialPage .platformClientAccessButton.isRelease{border:1px solid #aad7bb!important;background:#f2fbf5!important;color:#247247!important}
        .platformClientAdminModal{position:fixed;inset:0;z-index:2147483100;display:grid;place-items:center;padding:20px;background:rgba(5,17,29,.72);backdrop-filter:blur(6px)}
        .platformClientAdminModal__card{width:min(94vw,720px);max-height:92vh;overflow:auto;box-sizing:border-box;padding:28px;border:1px solid #dfe6eb;border-radius:20px;background:#fff;box-shadow:0 28px 80px rgba(6,21,37,.28);color:#14293d}
        .platformClientAdminModal__head{display:flex;align-items:flex-start;justify-content:space-between;gap:18px;margin-bottom:20px}
        .platformClientAdminModal__head h3{margin:5px 0 0;font-size:25px}
        .platformClientAdminModal__eyebrow{color:#a77b25;font-size:11px;font-weight:900;letter-spacing:.1em}
        .platformClientAdminModal__close{width:38px;height:38px;border:1px solid #d7e0e7;border-radius:999px;background:#f7f9fa;color:#183149;font-size:22px;cursor:pointer}
        .platformClientAdminModal form{display:grid;gap:14px}
        .platformClientAdminModal__grid{display:grid;grid-template-columns:1fr 1fr;gap:14px}
        .platformClientAdminModal__grid.three{grid-template-columns:repeat(3,1fr)}
        .platformClientAdminModal label{display:grid;gap:7px;color:#405467;font-size:12px;font-weight:800}
        .platformClientAdminModal input,.platformClientAdminModal select{width:100%;min-height:44px;box-sizing:border-box;padding:9px 11px;border:1px solid #cdd7df;border-radius:10px;background:#fff;color:#13293d;font:inherit}
        .platformClientAdminModal__address{margin:-4px 0 4px;color:#71808d;font-size:12px}
        .platformClientAdminModal__actions{display:flex;justify-content:flex-end;gap:10px;margin-top:8px}
        .platformClientAdminModal__actions button{min-height:43px;padding:0 17px;border-radius:10px;font-weight:850;cursor:pointer}
        .platformClientAdminModal__cancel{border:1px solid #ccd6de;background:#f7f9fa;color:#22384d}
        .platformClientAdminModal__save{border:1px solid #d5a33b;background:#d9aa42;color:#10263d}
        .platformClientAdminModal__message{padding:11px 13px;border-radius:10px;background:#f3f7fa;color:#334b60;font-size:13px;font-weight:700}
        @media(max-width:720px){
          .platformCommercialPage .platformNewAgencyButton{width:100%;margin-left:0!important}
          .platformCommercialPage .platformClientIdentityButton,.platformCommercialPage .platformClientAccessButton{width:100%!important;margin-left:0!important}
          .platformClientAdminModal{padding:10px}
          .platformClientAdminModal__card{padding:20px}
          .platformClientAdminModal__grid,.platformClientAdminModal__grid.three{grid-template-columns:1fr}
          .platformClientAdminModal__actions{flex-direction:column-reverse}
          .platformClientAdminModal__actions button{width:100%}
        }
      `}),s?(0,o.jsx)("div",{className:"platformClientAdminModal",role:"dialog","aria-modal":"true",children:(0,o.jsxs)("div",{className:"platformClientAdminModal__card",children:[(0,o.jsxs)("div",{className:"platformClientAdminModal__head",children:[(0,o.jsxs)("div",{children:[(0,o.jsx)("span",{className:"platformClientAdminModal__eyebrow",children:"create"===s?"NOVO CLIENTE":"IDENTIFICA\xc7\xc3O DA IMOBILI\xc1RIA"}),(0,o.jsx)("h3",{children:"create"===s?"Cadastrar nova imobili\xe1ria":"Editar cadastro"})]}),(0,o.jsx)("button",{className:"platformClientAdminModal__close",type:"button",disabled:u,onClick:()=>m(null),children:"\xd7"})]}),(0,o.jsxs)("form",{onSubmit:"create"===s?$:T,children:[(0,o.jsxs)("div",{className:"platformClientAdminModal__grid",children:[(0,o.jsxs)("label",{children:["Nome da imobili\xe1ria",(0,o.jsx)("input",{required:!0,maxLength:160,value:b,onChange:e=>h(e.target.value)})]}),(0,o.jsxs)("label",{children:["E-mail do propriet\xe1rio",(0,o.jsx)("input",{required:!0,type:"email",maxLength:254,value:y,onChange:e=>j(e.target.value)})]})]}),(0,o.jsxs)("div",{className:"platformClientAdminModal__grid",children:[(0,o.jsxs)("label",{children:["Endere\xe7o / slug",(0,o.jsx)("input",{required:!0,maxLength:48,value:_,onChange:e=>{w(!0),v(e.target.value)}})]}),(0,o.jsxs)("label",{children:["WhatsApp",(0,o.jsx)("input",{maxLength:40,inputMode:"tel",value:M,onChange:e=>A(e.target.value)})]})]}),(0,o.jsxs)("div",{className:"platformClientAdminModal__address",children:[i(_)||"nova-imobiliaria",".imoveis.lenoy.com.br"]}),"create"===s?(0,o.jsxs)(o.Fragment,{children:[(0,o.jsxs)("div",{className:"platformClientAdminModal__grid three",children:[(0,o.jsxs)("label",{children:["Plano",(0,o.jsxs)("select",{value:E,onChange:e=>k(e.target.value),children:[(0,o.jsx)("option",{value:"",children:"Sem plano"}),a.map(e=>(0,o.jsx)("option",{value:e.id,children:e.name},e.id))]})]}),(0,o.jsxs)("label",{children:["Cobran\xe7a",(0,o.jsxs)("select",{value:N,onChange:e=>S(e.target.value),children:[(0,o.jsx)("option",{value:"monthly",children:"Mensal"}),(0,o.jsx)("option",{value:"annual",children:"Anual"})]})]}),(0,o.jsxs)("label",{children:["Implanta\xe7\xe3o",(0,o.jsxs)("select",{value:z,onChange:e=>q(e.target.value),children:[(0,o.jsx)("option",{value:"pending",children:"Pendente"}),(0,o.jsx)("option",{value:"paid",children:"Paga"}),(0,o.jsx)("option",{value:"waived",children:"Gr\xe1tis / dispensada"})]})]})]}),(0,o.jsxs)("div",{className:"platformClientAdminModal__grid",children:[(0,o.jsxs)("label",{children:["Acesso inicial",(0,o.jsxs)("select",{value:D,onChange:e=>L(e.target.value),children:[(0,o.jsx)("option",{value:"pending_payment",children:"Aguardando pagamento"}),(0,o.jsx)("option",{value:"active",children:"Liberado"}),(0,o.jsx)("option",{value:"trial",children:"Conta interna / teste"}),(0,o.jsx)("option",{value:"suspended",children:"Suspenso"})]})]}),(0,o.jsxs)("label",{children:["Assinatura",(0,o.jsxs)("select",{value:B,onChange:e=>P(e.target.value),children:[(0,o.jsx)("option",{value:"none",children:"Sem assinatura"}),(0,o.jsx)("option",{value:"active",children:"Ativa"}),(0,o.jsx)("option",{value:"trial",children:"Conta interna / teste"}),(0,o.jsx)("option",{value:"past_due",children:"Pagamento atrasado"})]})]})]}),(0,o.jsx)("div",{className:"platformClientAdminModal__message",children:"Ao salvar, o propriet\xe1rio receber\xe1 um convite no e-mail informado para acessar a nova imobili\xe1ria."})]}):(0,o.jsx)("div",{className:"platformClientAdminModal__message",children:"Plano, cobran\xe7a, vencimento e status continuam sendo editados pelo bot\xe3o “Editar cliente” que j\xe1 existe no card."}),x?(0,o.jsx)("div",{className:"platformClientAdminModal__message",children:x}):null,(0,o.jsxs)("div",{className:"platformClientAdminModal__actions",children:[(0,o.jsx)("button",{className:"platformClientAdminModal__cancel",type:"button",disabled:u,onClick:()=>m(null),children:"Cancelar"}),(0,o.jsx)("button",{className:"platformClientAdminModal__save",type:"submit",disabled:u,children:u?"Salvando...":"create"===s?"Criar imobili\xe1ria e enviar convite":"Salvar cadastro"})]})]})]})}):null]})}},51831:(e,t,a)=>{a.d(t,{default:()=>i});var o=a(87277),n=a(85529),r=a(20994);function i(){let[e,t]=(0,n.useState)([]),[a,i]=(0,n.useState)(null),[l,d]=(0,n.useState)(""),[s,m]=(0,n.useState)(!1),[c,p]=(0,n.useState)(""),u=(0,n.useMemo)(()=>new Map(e.map(e=>[e.slug,e])),[e]);async function f(){if(!a||!r.L||l.trim()!==a.name.trim())return;m(!0),p("");let e=await r.L.functions.invoke("delete-platform-client",{body:{agency_id:a.id,confirmation:l.trim()}});if(e.error){let t=e.error.message||"N\xe3o foi poss\xedvel excluir o usu\xe1rio.",a=e.error.context;if(a)try{let e=await a.clone().json();e?.error==="current_admin_account_protected"||e?.error==="platform_admin_account_protected"?t="Este usu\xe1rio est\xe1 protegido porque pertence \xe0 administra\xe7\xe3o da plataforma.":e?.error==="confirmation_mismatch"?t="O nome digitado n\xe3o confere com o cliente.":e?.detail&&(t=String(e.detail))}catch{}p(t),m(!1);return}m(!1),i(null),window.location.reload()}return(0,n.useEffect)(()=>{"/plataforma"!==window.location.pathname||r.L&&r.$&&(async()=>{let e=await r.L.from("agencies").select("id,name,slug").order("created_at",{ascending:!1});e.error||t(e.data||[])})()},[]),(0,n.useEffect)(()=>{if("/plataforma"!==window.location.pathname)return;let e=()=>{Array.from(document.querySelectorAll(".platformCommercialPage .commercialClientCard")).forEach(e=>{if(e.querySelector(".commercialDeleteClientButton"))return;let t=e.querySelector(".commercialClientHeader small")?.textContent?.trim()||"",a=t.split(".")[0]?.trim()||"",o=u.get(a);if(!o)return;let n=e.querySelector(".commercialEditClientButton");if(!n)return;let r=document.createElement("button");r.type="button",r.className="commercialDeleteClientButton",r.textContent="Excluir usu\xe1rio",r.addEventListener("click",()=>{p(""),d(""),i(o)}),n.insertAdjacentElement("afterend",r)})};e();let t=new MutationObserver(e);return t.observe(document.body,{childList:!0,subtree:!0}),()=>t.disconnect()},[u]),(0,n.useEffect)(()=>{if(!a)return;let e=document.body.style.overflow;document.body.style.overflow="hidden";let t=e=>{"Escape"!==e.key||s||i(null)};return window.addEventListener("keydown",t),()=>{document.body.style.overflow=e,window.removeEventListener("keydown",t)}},[a,s]),(0,o.jsxs)(o.Fragment,{children:[(0,o.jsx)("style",{children:`
        .platformCommercialPage .commercialDeleteClientButton {
          display: flex !important;
          align-items: center !important;
          justify-content: center !important;
          width: 190px !important;
          min-height: 40px !important;
          margin: 8px 0 0 auto !important;
          padding: 0 16px !important;
          border: 1px solid #e5b4b0 !important;
          border-radius: 11px !important;
          background: #fff8f7 !important;
          color: #a63f38 !important;
          font-size: 12px !important;
          font-weight: 850 !important;
          cursor: pointer !important;
        }
        .platformCommercialPage .commercialDeleteClientButton:hover {
          border-color: #b84239 !important;
          background: #b84239 !important;
          color: #fff !important;
        }
        .platformDeleteModal {
          position: fixed;
          inset: 0;
          z-index: 2147483000;
          display: grid;
          place-items: center;
          padding: 20px;
          background: rgba(5, 17, 29, .72);
          backdrop-filter: blur(6px);
          -webkit-backdrop-filter: blur(6px);
        }
        .platformDeleteModal__card {
          width: min(92vw, 520px);
          padding: 28px;
          border: 1px solid #e4e9ed;
          border-radius: 20px;
          background: #fff;
          box-shadow: 0 28px 80px rgba(6, 21, 37, .28);
          color: #14293d;
        }
        .platformDeleteModal__eyebrow {
          color: #b84239;
          font-size: 11px;
          font-weight: 900;
          letter-spacing: .1em;
        }
        .platformDeleteModal__card h3 {
          margin: 7px 0 10px;
          font-size: 24px;
          line-height: 1.15;
        }
        .platformDeleteModal__card p {
          margin: 0 0 14px;
          color: #657586;
          font-size: 14px;
          line-height: 1.5;
        }
        .platformDeleteModal__warning {
          padding: 12px 14px;
          border: 1px solid #efd0cc;
          border-radius: 11px;
          background: #fff7f6;
          color: #8f3933 !important;
        }
        .platformDeleteModal__card label {
          display: grid;
          gap: 7px;
          margin-top: 18px;
          color: #405467;
          font-size: 12px;
          font-weight: 800;
        }
        .platformDeleteModal__card input {
          width: 100%;
          min-height: 44px;
          box-sizing: border-box;
          padding: 9px 11px;
          border: 1px solid #cdd7df;
          border-radius: 10px;
          background: #fff;
          color: #13293d;
          font-size: 14px;
        }
        .platformDeleteModal__message {
          margin-top: 12px !important;
          color: #a63f38 !important;
          font-weight: 700;
        }
        .platformDeleteModal__actions {
          display: flex;
          justify-content: flex-end;
          gap: 10px;
          margin-top: 22px;
        }
        .platformDeleteModal__actions button {
          min-height: 42px;
          padding: 0 16px;
          border-radius: 10px;
          font-size: 13px;
          font-weight: 850;
          cursor: pointer;
        }
        .platformDeleteModal__cancel {
          border: 1px solid #ccd6de;
          background: #f7f9fa;
          color: #22384d;
        }
        .platformDeleteModal__confirm {
          border: 1px solid #b84239;
          background: #b84239;
          color: #fff;
        }
        .platformDeleteModal__confirm:disabled {
          cursor: not-allowed;
          opacity: .45;
        }
        @media(max-width:720px){
          .platformCommercialPage .commercialDeleteClientButton { width: 100% !important; margin-left: 0 !important; }
          .platformDeleteModal__card { padding: 22px; }
          .platformDeleteModal__actions { flex-direction: column-reverse; }
          .platformDeleteModal__actions button { width: 100%; }
        }
      `}),a?(0,o.jsx)("div",{className:"platformDeleteModal",role:"dialog","aria-modal":"true","aria-labelledby":"platform-delete-title",children:(0,o.jsxs)("div",{className:"platformDeleteModal__card",children:[(0,o.jsx)("span",{className:"platformDeleteModal__eyebrow",children:"EXCLUS\xc3O PERMANENTE"}),(0,o.jsxs)("h3",{id:"platform-delete-title",children:["Excluir ",a.name,"?"]}),(0,o.jsx)("p",{className:"platformDeleteModal__warning",children:"Esta a\xe7\xe3o remove o cliente da plataforma, seus dados vinculados e os usu\xe1rios que n\xe3o perten\xe7am a outra imobili\xe1ria. N\xe3o pode ser desfeita."}),(0,o.jsx)("p",{children:"Para confirmar, digite exatamente o nome abaixo:"}),(0,o.jsx)("strong",{children:a.name}),(0,o.jsxs)("label",{children:["Confirma\xe7\xe3o",(0,o.jsx)("input",{autoFocus:!0,value:l,onChange:e=>d(e.target.value),disabled:s})]}),c?(0,o.jsx)("p",{className:"platformDeleteModal__message",children:c}):null,(0,o.jsxs)("div",{className:"platformDeleteModal__actions",children:[(0,o.jsx)("button",{className:"platformDeleteModal__cancel",type:"button",disabled:s,onClick:()=>i(null),children:"Cancelar"}),(0,o.jsx)("button",{className:"platformDeleteModal__confirm",type:"button",disabled:s||l.trim()!==a.name.trim(),onClick:()=>void f(),children:s?"Excluindo...":"Excluir definitivamente"})]})]})}):null]})}}}]);