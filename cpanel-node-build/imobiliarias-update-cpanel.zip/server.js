process.chdir(__dirname + '/apps/web');
require('./apps/web/server.js');
